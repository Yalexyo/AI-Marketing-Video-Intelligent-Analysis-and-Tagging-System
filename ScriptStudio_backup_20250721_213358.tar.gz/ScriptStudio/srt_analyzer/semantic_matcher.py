#!/usr/bin/env python3
"""
语义匹配器 - Semantic Matcher
确保切片画面内容与字幕内容在语义上匹配
"""

import logging
import json
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)

@dataclass
class MatchResult:
    """匹配结果数据结构"""
    semantic_score: float      # 语义相似度 (0.0-1.0)
    brand_match_score: float   # 品牌元素匹配度 (0.0-1.0)
    emotion_consistency: float # 情绪一致性 (0.0-1.0)
    final_score: float         # 综合得分 (0.0-1.0)
    match_details: Dict        # 详细匹配信息
    is_valid_match: bool       # 是否有效匹配

@dataclass
class SliceInfo:
    """切片信息数据结构"""
    file_path: str            # 切片文件路径
    video_name: str           # 源视频名称
    duration: float           # 切片时长
    tags: Dict                # 标签信息 {object, scene, emotion, brand_elements}
    file_size_mb: float       # 文件大小(MB)

class SemanticMatcher:
    """语义匹配器"""
    
    # 情绪映射关系
    EMOTION_MAPPING = {
        '好奇': ['疑问', '询问', '探索', '想知道'],
        '温馨': ['温暖', '幸福', '安心', '满足'],
        '专业': ['严肃', '权威', '科学', '可信'],
        '开心': ['快乐', '满意', '高兴', '愉快'],
        '关爱': ['爱护', '保护', '关心', '呵护'],
        '惊讶': ['惊奇', '意外', '发现', '震惊']
    }
    
    # 品牌关键词映射
    BRAND_KEYWORDS = {
        '启赋': ['启赋', 'wyeth', '惠氏'],
        'HMO': ['HMO', '母乳低聚糖', '低聚糖'],
        'A2': ['A2', 'A-2', 'A二', 'A 2'],
        '蕴淳': ['蕴淳', '蕴醇'],
        '水奶': ['水奶', '液体奶', '即饮'],
        '配方': ['配方', '成分', '营养']
    }
    
    # 语义词汇库
    SEMANTIC_VOCABULARY = {
        '产品介绍': {
            'keywords': ['产品', '奶粉', '配方', '成分', '营养', '品牌', '奶源'],
            'visual_concepts': ['产品包装', '奶粉罐', '品牌标识', '配方表', '营养标签'],
            'actions': ['展示', '介绍', '说明', '解释']
        },
        '使用效果': {
            'keywords': ['效果', '反应', '表现', '改善', '健康', '成长'],
            'visual_concepts': ['宝宝状态', '健康表现', '成长变化', '使用场景'],
            'actions': ['使用', '喝', '食用', '体验']
        },
        '钩子吸引': {
            'keywords': ['知道', '发现', '秘密', '真相', '惊讶', '竟然'],
            'visual_concepts': ['疑问表情', '好奇状态', '思考姿态', '惊讶表情'],
            'actions': ['思考', '疑问', '发现', '惊讶']
        },
        '促销推荐': {
            'keywords': ['推荐', '选择', '购买', '优惠', '值得', '建议'],
            'visual_concepts': ['推荐手势', '选择动作', '满意表情', '决定状态'],
            'actions': ['推荐', '选择', '决定', '建议']
        }
    }
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def match_content_with_subtitle(self, slice_tags: Dict, subtitle_content: str, 
                                   module_type: str = None) -> MatchResult:
        """
        匹配切片画面内容与字幕内容
        
        Args:
            slice_tags: 切片标签信息 {object, scene, emotion, brand_elements}
            subtitle_content: 字幕文本内容
            module_type: 模块类型 (可选)
            
        Returns:
            MatchResult对象
        """
        try:
            # 1. 计算语义相似度
            semantic_score = self._calculate_semantic_similarity(slice_tags, subtitle_content)
            
            # 2. 计算品牌元素匹配度
            brand_match_score = self._calculate_brand_match(slice_tags, subtitle_content)
            
            # 3. 计算情绪一致性
            emotion_consistency = self._calculate_emotion_consistency(slice_tags, subtitle_content)
            
            # 4. 如果提供了模块类型，进行模块特定匹配
            module_bonus = 0.0
            if module_type:
                module_bonus = self._calculate_module_specific_match(slice_tags, subtitle_content, module_type)
            
            # 5. 计算综合得分
            final_score = self._calculate_final_score(
                semantic_score, brand_match_score, emotion_consistency, module_bonus
            )
            
            # 6. 生成详细匹配信息
            match_details = {
                'semantic_keywords': self._extract_semantic_keywords(subtitle_content),
                'visual_concepts': self._extract_visual_concepts(slice_tags),
                'brand_elements_found': self._find_brand_elements(subtitle_content),
                'emotion_mapping': self._map_emotions(slice_tags.get('emotion', ''), subtitle_content),
                'module_specific_features': self._extract_module_features(subtitle_content, module_type) if module_type else {}
            }
            
            # 7. 判断是否为有效匹配
            is_valid_match = final_score >= 0.6  # 阈值可调整
            
            return MatchResult(
                semantic_score=semantic_score,
                brand_match_score=brand_match_score,
                emotion_consistency=emotion_consistency,
                final_score=final_score,
                match_details=match_details,
                is_valid_match=is_valid_match
            )
            
        except Exception as e:
            self.logger.error(f"语义匹配失败: {e}")
            return MatchResult(0.0, 0.0, 0.0, 0.0, {}, False)
    
    def _calculate_semantic_similarity(self, slice_tags: Dict, subtitle_content: str) -> float:
        """计算语义相似度"""
        object_desc = slice_tags.get('object', '')
        scene_desc = slice_tags.get('scene', '')
        
        # 提取字幕关键词
        subtitle_keywords = self._extract_keywords(subtitle_content)
        
        # 提取视觉概念
        visual_keywords = self._extract_keywords(f"{object_desc} {scene_desc}")
        
        # 计算关键词重叠度
        if not subtitle_keywords and not visual_keywords:
            return 0.5  # 默认中等相似度
        
        common_keywords = set(subtitle_keywords) & set(visual_keywords)
        total_keywords = set(subtitle_keywords) | set(visual_keywords)
        
        if total_keywords:
            overlap_score = len(common_keywords) / len(total_keywords)
        else:
            overlap_score = 0.0
        
        # 语义主题匹配
        theme_score = self._calculate_theme_similarity(slice_tags, subtitle_content)
        
        # 综合评分
        final_score = (overlap_score * 0.4 + theme_score * 0.6)
        return min(final_score, 1.0)
    
    def _calculate_brand_match(self, slice_tags: Dict, subtitle_content: str) -> float:
        """计算品牌元素匹配度"""
        brand_elements = slice_tags.get('brand_elements', '')
        
        if not brand_elements and not self._contains_brand_keywords(subtitle_content):
            return 1.0  # 都没有品牌元素，认为匹配
        
        # 检查品牌元素是否在字幕中出现
        brand_score = 0.0
        brand_count = 0
        
        for brand, keywords in self.BRAND_KEYWORDS.items():
            if brand in brand_elements:
                brand_count += 1
                if any(keyword in subtitle_content for keyword in keywords):
                    brand_score += 1
        
        if brand_count > 0:
            return brand_score / brand_count
        
        # 检查字幕中的品牌关键词是否在视觉标签中
        subtitle_brands = self._extract_brand_keywords(subtitle_content)
        if subtitle_brands:
            visual_brand_score = 0.0
            for brand in subtitle_brands:
                if brand in brand_elements:
                    visual_brand_score += 1
            return visual_brand_score / len(subtitle_brands)
        
        return 0.8  # 默认较高匹配度
    
    def _calculate_emotion_consistency(self, slice_tags: Dict, subtitle_content: str) -> float:
        """计算情绪一致性"""
        visual_emotion = slice_tags.get('emotion', '')
        
        if not visual_emotion:
            return 0.7  # 无情绪标签时的默认值
        
        # 分析字幕情绪
        subtitle_emotions = self._analyze_subtitle_emotion(subtitle_content)
        
        # 检查情绪映射
        for emotion, related_emotions in self.EMOTION_MAPPING.items():
            if emotion == visual_emotion:
                if any(related in subtitle_content for related in related_emotions):
                    return 1.0
                if any(emotion_word in subtitle_emotions for emotion_word in related_emotions):
                    return 0.9
        
        # 直接匹配
        if visual_emotion in subtitle_content:
            return 1.0
        
        # 情绪类别匹配
        emotion_category_score = self._match_emotion_categories(visual_emotion, subtitle_emotions)
        
        return emotion_category_score
    
    def _calculate_module_specific_match(self, slice_tags: Dict, subtitle_content: str, module_type: str) -> float:
        """计算模块特定匹配度"""
        module_name = module_type.replace('🪝', '').replace('🍼', '').replace('🌟', '').replace('🎁', '')
        
        if module_name == '钩子':
            return self._calculate_hook_match(slice_tags, subtitle_content)
        elif module_name == '产品介绍':
            return self._calculate_product_match(slice_tags, subtitle_content)
        elif module_name == '使用效果':
            return self._calculate_effect_match(slice_tags, subtitle_content)
        elif module_name == '促销机制':
            return self._calculate_promotion_match(slice_tags, subtitle_content)
        
        return 0.0
    
    def _calculate_hook_match(self, slice_tags: Dict, subtitle_content: str) -> float:
        """计算钩子模块匹配度"""
        hook_indicators = ['你知道', '竟然', '没想到', '原来', '发现', '？', '吗']
        visual_emotion = slice_tags.get('emotion', '')
        
        score = 0.0
        
        # 检查钩子关键词
        for indicator in hook_indicators:
            if indicator in subtitle_content:
                score += 0.3
        
        # 检查情绪匹配
        if visual_emotion in ['好奇', '惊讶', '疑问']:
            score += 0.4
        
        return min(score, 1.0)
    
    def _calculate_product_match(self, slice_tags: Dict, subtitle_content: str) -> float:
        """计算产品介绍模块匹配度"""
        product_keywords = ['启赋', '蕴淳', '水奶', '配方', 'HMO', 'A2', '奶源', '品牌']
        brand_elements = slice_tags.get('brand_elements', '')
        
        score = 0.0
        
        # 检查产品关键词
        keyword_count = sum(1 for keyword in product_keywords if keyword in subtitle_content)
        score += min(keyword_count * 0.2, 0.6)
        
        # 检查品牌元素
        if brand_elements and any(brand in subtitle_content for brand in brand_elements.split()):
            score += 0.4
        
        return min(score, 1.0)
    
    def _calculate_effect_match(self, slice_tags: Dict, subtitle_content: str) -> float:
        """计算使用效果模块匹配度"""
        effect_keywords = ['效果', '宝宝', '健康', '成长', '消化', '吸收', '反应']
        visual_object = slice_tags.get('object', '')
        
        score = 0.0
        
        # 检查效果关键词
        keyword_count = sum(1 for keyword in effect_keywords if keyword in subtitle_content)
        score += min(keyword_count * 0.25, 0.75)
        
        # 检查视觉对象是否包含宝宝
        if '宝宝' in visual_object or '婴儿' in visual_object:
            score += 0.25
        
        return min(score, 1.0)
    
    def _calculate_promotion_match(self, slice_tags: Dict, subtitle_content: str) -> float:
        """计算促销机制模块匹配度"""
        promotion_keywords = ['推荐', '选择', '购买', '值得', '建议', '入手']
        visual_emotion = slice_tags.get('emotion', '')
        
        score = 0.0
        
        # 检查促销关键词
        keyword_count = sum(1 for keyword in promotion_keywords if keyword in subtitle_content)
        score += min(keyword_count * 0.3, 0.6)
        
        # 检查情绪匹配
        if visual_emotion in ['开心', '满意', '推荐']:
            score += 0.4
        
        return min(score, 1.0)
    
    def _calculate_final_score(self, semantic_score: float, brand_match_score: float, 
                             emotion_consistency: float, module_bonus: float) -> float:
        """计算最终综合得分"""
        # 权重设置
        weights = {
            'semantic': 0.4,
            'brand': 0.3,
            'emotion': 0.2,
            'module': 0.1
        }
        
        final_score = (
            semantic_score * weights['semantic'] +
            brand_match_score * weights['brand'] +
            emotion_consistency * weights['emotion'] +
            module_bonus * weights['module']
        )
        
        return min(final_score, 1.0)
    
    def _extract_keywords(self, text: str) -> List[str]:
        """提取文本关键词"""
        # 简化版关键词提取
        words = re.findall(r'\b\w+\b', text)
        # 过滤停用词
        stop_words = {'的', '了', '在', '是', '我', '有', '和', '就', '不', '都', '到', '也', '会', '这', '那'}
        keywords = [word for word in words if word not in stop_words and len(word) > 1]
        return keywords[:10]  # 限制关键词数量
    
    def _extract_semantic_keywords(self, subtitle_content: str) -> List[str]:
        """提取语义关键词"""
        keywords = []
        
        for category, vocab in self.SEMANTIC_VOCABULARY.items():
            for keyword in vocab['keywords']:
                if keyword in subtitle_content:
                    keywords.append(keyword)
        
        return keywords
    
    def _extract_visual_concepts(self, slice_tags: Dict) -> List[str]:
        """提取视觉概念"""
        concepts = []
        
        object_desc = slice_tags.get('object', '')
        scene_desc = slice_tags.get('scene', '')
        
        # 分析对象和场景
        for text in [object_desc, scene_desc]:
            if text:
                concepts.extend(self._extract_keywords(text))
        
        return concepts
    
    def _find_brand_elements(self, subtitle_content: str) -> List[str]:
        """查找品牌元素"""
        found_brands = []
        
        for brand, keywords in self.BRAND_KEYWORDS.items():
            if any(keyword in subtitle_content for keyword in keywords):
                found_brands.append(brand)
        
        return found_brands
    
    def _extract_brand_keywords(self, text: str) -> List[str]:
        """提取品牌关键词"""
        brands = []
        for brand, keywords in self.BRAND_KEYWORDS.items():
            if any(keyword in text for keyword in keywords):
                brands.append(brand)
        return brands
    
    def _contains_brand_keywords(self, text: str) -> bool:
        """检查文本是否包含品牌关键词"""
        return len(self._extract_brand_keywords(text)) > 0
    
    def _analyze_subtitle_emotion(self, subtitle_content: str) -> List[str]:
        """分析字幕情绪"""
        emotions = []
        
        # 简化版情绪分析
        emotion_indicators = {
            '好奇': ['？', '吗', '知道', '什么'],
            '开心': ['哈', '嗯', '好', '棒', '不错'],
            '惊讶': ['哇', '天', '没想到', '竟然'],
            '温馨': ['爱', '暖', '幸福', '温暖'],
            '专业': ['研究', '科学', '证明', '数据']
        }
        
        for emotion, indicators in emotion_indicators.items():
            if any(indicator in subtitle_content for indicator in indicators):
                emotions.append(emotion)
        
        return emotions
    
    def _map_emotions(self, visual_emotion: str, subtitle_content: str) -> Dict:
        """映射情绪关系"""
        return {
            'visual_emotion': visual_emotion,
            'subtitle_emotions': self._analyze_subtitle_emotion(subtitle_content),
            'mapping_found': visual_emotion in self.EMOTION_MAPPING,
            'consistency_level': 'high' if visual_emotion in subtitle_content else 'medium'
        }
    
    def _extract_module_features(self, subtitle_content: str, module_type: str) -> Dict:
        """提取模块特征"""
        features = {}
        
        if not module_type:
            return features
        
        module_name = module_type.replace('🪝', '').replace('🍼', '').replace('🌟', '').replace('🎁', '')
        
        if module_name in ['钩子']:
            features['hook_indicators'] = [word for word in ['你知道', '竟然', '没想到'] if word in subtitle_content]
        elif module_name in ['产品介绍']:
            features['product_mentions'] = self._find_brand_elements(subtitle_content)
        elif module_name in ['使用效果']:
            features['effect_keywords'] = [word for word in ['效果', '宝宝', '健康'] if word in subtitle_content]
        elif module_name in ['促销机制']:
            features['promotion_words'] = [word for word in ['推荐', '选择', '建议'] if word in subtitle_content]
        
        return features
    
    def _calculate_theme_similarity(self, slice_tags: Dict, subtitle_content: str) -> float:
        """计算主题相似度"""
        # 简化版主题匹配
        themes = {
            '产品展示': ['产品', '奶粉', '包装', '展示'],
            '使用场景': ['使用', '喝', '宝宝', '场景'],
            '情感表达': ['爱', '关心', '温暖', '幸福'],
            '专业说明': ['配方', '成分', '科学', '研究']
        }
        
        object_desc = slice_tags.get('object', '')
        max_score = 0.0
        
        for theme, keywords in themes.items():
            visual_match = sum(1 for keyword in keywords if keyword in object_desc)
            subtitle_match = sum(1 for keyword in keywords if keyword in subtitle_content)
            
            if visual_match > 0 or subtitle_match > 0:
                theme_score = (visual_match + subtitle_match) / (len(keywords) * 2)
                max_score = max(max_score, theme_score)
        
        return max_score
    
    def _match_emotion_categories(self, visual_emotion: str, subtitle_emotions: List[str]) -> float:
        """匹配情绪类别"""
        if not visual_emotion or not subtitle_emotions:
            return 0.5
        
        # 情绪类别映射
        emotion_categories = {
            'positive': ['开心', '满意', '温馨', '幸福'],
            'curious': ['好奇', '疑问', '惊讶'],
            'professional': ['专业', '严肃', '可信'],
            'caring': ['关爱', '温暖', '保护']
        }
        
        visual_category = None
        subtitle_categories = []
        
        # 查找视觉情绪类别
        for category, emotions in emotion_categories.items():
            if visual_emotion in emotions:
                visual_category = category
                break
        
        # 查找字幕情绪类别
        for emotion in subtitle_emotions:
            for category, emotions in emotion_categories.items():
                if emotion in emotions:
                    subtitle_categories.append(category)
        
        # 计算类别匹配度
        if visual_category and visual_category in subtitle_categories:
            return 0.8
        elif visual_category and subtitle_categories:
            return 0.4
        else:
            return 0.3 