#!/usr/bin/env python3
"""
时间轴解析器 - SRT Timeline Parser
解析SRT字幕文件，提取时间段和内容信息
"""

import re
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)

@dataclass
class TimelineSegment:
    """时间轴片段数据结构"""
    index: int
    start_time: float      # 开始时间(秒)
    end_time: float        # 结束时间(秒)
    duration: float        # 持续时间(秒)
    content: str           # 文本内容
    timestamp: str         # 原始时间戳
    
    def __post_init__(self):
        """计算持续时间"""
        if self.duration == 0:
            self.duration = self.end_time - self.start_time

@dataclass
class TimelineAnalysis:
    """时间轴分析结果"""
    total_duration: float                    # 总时长
    segments: List[TimelineSegment]          # 时间段列表
    full_content: str                        # 完整内容
    segment_count: int                       # 片段数量
    average_segment_duration: float          # 平均片段时长
    analysis_metadata: Dict                  # 分析元数据

class TimelineParser:
    """SRT时间轴解析器"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def parse_srt_file(self, srt_path: Path) -> Optional[TimelineAnalysis]:
        """
        解析SRT文件，提取时间轴信息
        
        Args:
            srt_path: SRT文件路径
            
        Returns:
            TimelineAnalysis对象，失败返回None
        """
        try:
            if not srt_path.exists():
                self.logger.error(f"SRT文件不存在: {srt_path}")
                return None
            
            with open(srt_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 清理内容，移除注释
            clean_content = self._clean_srt_content(content)
            
            # 解析时间轴片段
            segments = self._parse_timeline_segments(clean_content)
            
            if not segments:
                self.logger.error(f"未能解析出有效的时间轴片段: {srt_path}")
                return None
            
            # 生成分析结果
            analysis = self._generate_analysis(segments, srt_path)
            
            self.logger.info(f"成功解析SRT文件: {srt_path.name}")
            self.logger.info(f"  总时长: {analysis.total_duration:.1f}秒")
            self.logger.info(f"  片段数: {analysis.segment_count}")
            self.logger.info(f"  平均片段时长: {analysis.average_segment_duration:.1f}秒")
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"解析SRT文件失败 {srt_path}: {e}")
            return None
    
    def _clean_srt_content(self, content: str) -> str:
        """清理SRT内容，移除注释部分"""
        lines = content.split('\n')
        cleaned_lines = []
        found_srt_start = False
        
        for line in lines:
            line = line.strip()
            
            # 跳过注释行（以 # 开头）
            if line.startswith('#'):
                continue
            
            # 跳过空行，直到找到SRT开始（数字行）
            if not found_srt_start:
                if line and line.isdigit():
                    found_srt_start = True
                    cleaned_lines.append(line)
                elif line and not line.startswith('#'):
                    # 如果遇到非注释、非空行，也开始收集
                    found_srt_start = True
                    cleaned_lines.append(line)
            else:
                # 已经开始收集SRT内容
                cleaned_lines.append(line)
        
        return '\n'.join(cleaned_lines)
    
    def _parse_timeline_segments(self, content: str) -> List[TimelineSegment]:
        """解析时间轴片段"""
        segments = []
        
        # 按空行分割片段
        blocks = re.split(r'\n\s*\n', content.strip())
        
        for block in blocks:
            if not block.strip():
                continue
                
            segment = self._parse_single_segment(block)
            if segment:
                segments.append(segment)
        
        return segments
    
    def _parse_single_segment(self, block: str) -> Optional[TimelineSegment]:
        """解析单个SRT片段"""
        lines = block.strip().split('\n')
        
        if len(lines) < 3:
            return None
        
        try:
            # 第一行：序号
            index = int(lines[0])
            
            # 第二行：时间戳
            timestamp_line = lines[1]
            start_time, end_time = self._parse_timestamp_line(timestamp_line)
            
            # 第三行及以后：文本内容
            content = '\n'.join(lines[2:]).strip()
            
            return TimelineSegment(
                index=index,
                start_time=start_time,
                end_time=end_time,
                duration=end_time - start_time,
                content=content,
                timestamp=timestamp_line
            )
            
        except Exception as e:
            self.logger.warning(f"解析SRT片段失败: {e}")
            return None
    
    def _parse_timestamp_line(self, timestamp_line: str) -> Tuple[float, float]:
        """
        解析时间戳行
        格式: 00:00:00,000 --> 00:00:05,000
        """
        # 匹配时间戳格式
        pattern = r'(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})'
        match = re.match(pattern, timestamp_line)
        
        if not match:
            raise ValueError(f"无效的时间戳格式: {timestamp_line}")
        
        # 解析开始时间
        start_h, start_m, start_s, start_ms = map(int, match.groups()[:4])
        start_time = start_h * 3600 + start_m * 60 + start_s + start_ms / 1000
        
        # 解析结束时间
        end_h, end_m, end_s, end_ms = map(int, match.groups()[4:])
        end_time = end_h * 3600 + end_m * 60 + end_s + end_ms / 1000
        
        return start_time, end_time
    
    def _generate_analysis(self, segments: List[TimelineSegment], srt_path: Path) -> TimelineAnalysis:
        """生成时间轴分析结果"""
        total_duration = max(seg.end_time for seg in segments) if segments else 0
        full_content = '\n'.join(seg.content for seg in segments)
        segment_count = len(segments)
        average_duration = sum(seg.duration for seg in segments) / segment_count if segment_count > 0 else 0
        
        metadata = {
            'source_file': str(srt_path),
            'parsed_at': datetime.now().isoformat(),
            'parsing_method': 'timeline_parser_v2',
            'encoding': 'utf-8',
            'total_content_length': len(full_content),
            'longest_segment': max(seg.duration for seg in segments) if segments else 0,
            'shortest_segment': min(seg.duration for seg in segments) if segments else 0,
        }
        
        return TimelineAnalysis(
            total_duration=total_duration,
            segments=segments,
            full_content=full_content,
            segment_count=segment_count,
            average_segment_duration=average_duration,
            analysis_metadata=metadata
        )
    
    def get_content_by_time_range(self, analysis: TimelineAnalysis, 
                                  start_time: float, end_time: float) -> str:
        """获取指定时间范围内的内容"""
        matching_content = []
        
        for segment in analysis.segments:
            # 检查时间段是否有重叠
            if (segment.start_time < end_time and segment.end_time > start_time):
                matching_content.append(segment.content)
        
        return ' '.join(matching_content)
    
    def get_segments_by_time_range(self, analysis: TimelineAnalysis,
                                   start_time: float, end_time: float) -> List[TimelineSegment]:
        """获取指定时间范围内的片段"""
        matching_segments = []
        
        for segment in analysis.segments:
            # 检查时间段是否有重叠
            if (segment.start_time < end_time and segment.end_time > start_time):
                matching_segments.append(segment)
        
        return matching_segments
    
    def split_by_duration(self, analysis: TimelineAnalysis, 
                          chunk_duration: float) -> List[List[TimelineSegment]]:
        """按指定时长分割时间轴"""
        chunks = []
        current_chunk = []
        current_start = 0
        
        for segment in analysis.segments:
            # 如果当前片段超出了chunk边界
            if segment.start_time >= current_start + chunk_duration:
                if current_chunk:
                    chunks.append(current_chunk)
                    current_chunk = []
                current_start = segment.start_time
            
            current_chunk.append(segment)
        
        # 添加最后一个chunk
        if current_chunk:
            chunks.append(current_chunk)
        
        return chunks
    
    def export_analysis(self, analysis: TimelineAnalysis, export_path: Path) -> bool:
        """导出分析结果到JSON文件"""
        try:
            import json
            
            # 转换为可序列化的格式
            export_data = {
                'metadata': analysis.analysis_metadata,
                'summary': {
                    'total_duration': analysis.total_duration,
                    'segment_count': analysis.segment_count,
                    'average_segment_duration': analysis.average_segment_duration,
                    'full_content_preview': analysis.full_content[:200] + '...' if len(analysis.full_content) > 200 else analysis.full_content
                },
                'segments': [
                    {
                        'index': seg.index,
                        'start_time': seg.start_time,
                        'end_time': seg.end_time,
                        'duration': seg.duration,
                        'content': seg.content,
                        'timestamp': seg.timestamp
                    }
                    for seg in analysis.segments
                ]
            }
            
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"成功导出分析结果到: {export_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"导出分析结果失败: {e}")
            return False 