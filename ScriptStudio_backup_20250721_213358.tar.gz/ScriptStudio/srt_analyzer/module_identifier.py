#!/usr/bin/env python3
"""
模块识别器 - Module Identifier
使用DeepSeek AI分析SRT内容，识别主标签模块占比
"""

import logging
import json
import sys
import os
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import re

# 添加label_to_classifier路径以便导入Claude 4分析器
sys.path.append(str(Path(__file__).parent.parent.parent / "label_to_classifier"))

# 导入Claude 4升级分析器
try:
    from universal_ref_classifier import UniversalRefClassifier
    CLAUDE4_AVAILABLE = True
    logging.info("✅ Claude 4升级分析器可用")
except ImportError as e:
    logging.error(f"❌ 无法导入Claude 4分析器: {e}")
    CLAUDE4_AVAILABLE = False
    raise ImportError("Claude 4分析器是必需的，请确保universal_ref_classifier.py可用")

from .timeline_parser import TimelineAnalysis, TimelineSegment

logger = logging.getLogger(__name__)

@dataclass
class ModuleSegment:
    """模块片段数据结构"""
    module_type: str           # 模块类型: 🪝钩子/🍼产品介绍/🌟使用效果/🎁促销机制
    start_time: float          # 开始时间(秒)
    end_time: float            # 结束时间(秒)
    duration: float            # 持续时间(秒)
    percentage: float          # 占比 (0.0-1.0)
    content: str              # 内容文本
    confidence: float          # 置信度 (0.0-1.0)
    timeline_segments: List[TimelineSegment]  # 对应的时间轴片段
    ai_analysis: Optional[Dict] = None  # AI分析详情

@dataclass
class ModuleAnalysis:
    """模块分析结果"""
    total_duration: float                    # 总时长
    module_segments: List[ModuleSegment]     # 模块片段列表
    module_distribution: Dict[str, float]    # 模块分布 {模块类型: 占比}
    analysis_metadata: Dict                  # 分析元数据
    
    def get_module_by_type(self, module_type: str) -> List[ModuleSegment]:
        """获取指定类型的模块片段"""
        return [seg for seg in self.module_segments if seg.module_type == module_type]

class ModuleIdentifier:
    """模块识别器 - 使用Claude 4进行精确分类"""
    
    # 模块类型定义（用于黄金结构参考）
    MODULE_TYPES = {
        '🪝钩子': {
            'target_percentage': 0.17,  # 17%
            'ideal_duration': 5.0       # 5秒
        },
        '🍼产品介绍': {
            'target_percentage': 0.33,  # 33%
            'ideal_duration': 10.0      # 10秒
        },
        '🌟使用效果': {
            'target_percentage': 0.33,  # 33%
            'ideal_duration': 10.0      # 10秒
        },
        '🎁促销机制': {
            'target_percentage': 0.17,  # 17%
            'ideal_duration': 5.0       # 5秒
        }
    }
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # 初始化Claude 4分析器
        if not CLAUDE4_AVAILABLE:
            raise ImportError("Claude 4分析器是必需的，请确保universal_ref_classifier.py可用")
        
        try:
            self.claude4_classifier = UniversalRefClassifier()
            self.logger.info("🚀 Claude 4分析器初始化成功")
        except Exception as e:
            self.logger.error(f"❌ Claude 4分析器初始化失败: {e}")
            raise
    
    def analyze_modules(self, timeline_analysis: TimelineAnalysis) -> Optional[ModuleAnalysis]:
        """
        分析时间轴，使用Claude 4识别模块占比
        
        Args:
            timeline_analysis: 时间轴分析结果
            
        Returns:
            ModuleAnalysis对象，失败返回None
        """
        try:
            self.logger.info(f"🚀 开始Claude 4模块识别分析，总时长: {timeline_analysis.total_duration:.1f}秒")
            return self._analyze_with_claude4(timeline_analysis)
            
        except Exception as e:
            self.logger.error(f"Claude 4模块识别分析失败: {e}")
            return None
    
    def _analyze_with_claude4(self, timeline_analysis: TimelineAnalysis) -> Optional[ModuleAnalysis]:
        """使用Claude 4分析器进行模块分析"""
        try:
            self.logger.info("🚀 使用Claude 4分析器进行整体模块分析")
            
            # 创建临时SRT内容
            temp_srt_content = self._create_srt_content_from_timeline(timeline_analysis)
            
            # 使用Claude 4分析器分析（需要创建临时文件）
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.srt', encoding='utf-8', delete=False) as temp_file:
                temp_file.write(temp_srt_content)
                temp_srt_path = Path(temp_file.name)
            
            try:
                # 解析和分类
                segments = self.claude4_classifier.parse_srt(temp_srt_path)
                if not segments:
                    raise ValueError("Claude 4 SRT解析失败")
                
                classified_segments = self.claude4_classifier.classify_all(segments)
                stats = self.claude4_classifier.generate_stats(classified_segments)
                
                # 转换为兼容格式
                module_segments = self._convert_claude4_results_to_modules(classified_segments, timeline_analysis)
                module_distribution = {module: stats[module].percentage / 100.0 for module in stats}
                
                # 生成分析结果
                analysis = ModuleAnalysis(
                    total_duration=timeline_analysis.total_duration,
                    module_segments=module_segments,
                    module_distribution=module_distribution,
                    analysis_metadata=self._generate_metadata(timeline_analysis, analyzer="Claude 4")
                )
                
                self._log_analysis_results(analysis)
                return analysis
                
            finally:
                # 清理临时文件
                temp_srt_path.unlink(missing_ok=True)
                
        except Exception as e:
            self.logger.error(f"Claude 4分析失败: {e}")
            raise
    
    def _create_srt_content_from_timeline(self, timeline_analysis: TimelineAnalysis) -> str:
        """从时间轴分析创建SRT内容"""
        srt_lines = []
        for i, segment in enumerate(timeline_analysis.segments, 1):
            start_time = self._seconds_to_srt_time(segment.start_time)
            end_time = self._seconds_to_srt_time(segment.end_time)
            srt_lines.extend([
                str(i),
                f"{start_time} --> {end_time}",
                segment.content,
                ""
            ])
        return "\n".join(srt_lines)
    
    def _seconds_to_srt_time(self, seconds: float) -> str:
        """将秒数转换为SRT时间格式"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"
    
    def _convert_claude4_results_to_modules(self, claude4_segments, timeline_analysis: TimelineAnalysis) -> List[ModuleSegment]:
        """将Claude 4分析结果转换为模块片段格式"""
        module_segments = []
        
        for segment in claude4_segments:
            # 找到对应的时间轴片段
            corresponding_timeline_segments = []
            for tl_seg in timeline_analysis.segments:
                if (tl_seg.start_time <= segment.end_time and tl_seg.end_time >= segment.start_time):
                    corresponding_timeline_segments.append(tl_seg)
            
            module_segment = ModuleSegment(
                module_type=segment.main_category,
                start_time=segment.start_time,
                end_time=segment.end_time,
                duration=segment.duration,
                percentage=segment.duration / timeline_analysis.total_duration,
                content=segment.text,
                confidence=segment.main_confidence,
                timeline_segments=corresponding_timeline_segments,
                ai_analysis={
                    'analyzer': 'Claude 4',
                    'main_confidence': segment.main_confidence,
                    'sub_categories': segment.sub_categories,
                    'mixed_content': len(segment.sub_categories) > 0
                }
            )
            module_segments.append(module_segment)
        
        return module_segments
    
    def _generate_metadata(self, timeline_analysis: TimelineAnalysis, analyzer: str = "Claude 4") -> Dict:
        """生成分析元数据"""
        return {
            'source_timeline': timeline_analysis.analysis_metadata.get('source_file', ''),
            'analyzed_at': datetime.now().isoformat(),
            'analysis_method': 'module_identifier_v2',
            'analyzer': analyzer,
            'module_types': list(self.MODULE_TYPES.keys()),
            'total_segments': len(timeline_analysis.segments),
            'ai_enhanced': self.claude4_classifier is not None,
            'upgrade_used': analyzer == "Claude 4"
        }
    
    def _log_analysis_results(self, analysis: ModuleAnalysis):
        """记录分析结果"""
        self.logger.info(f"模块识别完成，共识别 {len(analysis.module_segments)} 个模块片段")
        
        for module_type, percentage in analysis.module_distribution.items():
            duration = percentage * analysis.total_duration
            self.logger.info(f"  {module_type}: {percentage:.1%} ({duration:.1f}秒)")
    
    def optimize_module_distribution(self, analysis: ModuleAnalysis) -> ModuleAnalysis:
        """优化模块分布，使其更接近黄金结构"""
        try:
            optimized_modules = []
            
            for module_type, config in self.MODULE_TYPES.items():
                current_modules = analysis.get_module_by_type(module_type)
                target_percentage = config['target_percentage']
                target_duration = target_percentage * analysis.total_duration
                
                if current_modules:
                    # 如果当前模块存在，优化其时长
                    optimized_module = self._optimize_module_duration(
                        current_modules[0], target_duration
                    )
                    optimized_modules.append(optimized_module)
                else:
                    # 如果当前模块不存在，创建默认模块
                    self.logger.warning(f"缺少模块: {module_type}，将创建默认模块")
            
            # 重新计算分布
            new_distribution = self._calculate_module_distribution(optimized_modules, analysis.total_duration)
            
            return ModuleAnalysis(
                total_duration=analysis.total_duration,
                module_segments=optimized_modules,
                module_distribution=new_distribution,
                analysis_metadata=analysis.analysis_metadata
            )
            
        except Exception as e:
            self.logger.error(f"优化模块分布失败: {e}")
            return analysis
    
    def _optimize_module_duration(self, module: ModuleSegment, target_duration: float) -> ModuleSegment:
        """优化单个模块的时长"""
        # 简化版本：保持原模块不变
        # 实际实现中可以根据需要调整时长
        return module
    
    def export_analysis(self, analysis: ModuleAnalysis, export_path: Path) -> bool:
        """导出模块分析结果"""
        try:
            # 转换为可序列化的格式
            export_data = {
                'metadata': analysis.analysis_metadata,
                'summary': {
                    'total_duration': analysis.total_duration,
                    'module_count': len(analysis.module_segments),
                    'module_distribution': analysis.module_distribution
                },
                'modules': [
                    {
                        'module_type': module.module_type,
                        'start_time': module.start_time,
                        'end_time': module.end_time,
                        'duration': module.duration,
                        'percentage': module.percentage,
                        'content': module.content,
                        'confidence': module.confidence,
                        'timeline_segment_count': len(module.timeline_segments)
                    }
                    for module in analysis.module_segments
                ],
                'golden_structure_comparison': self._compare_to_golden_structure(analysis)
            }
            
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"成功导出模块分析结果到: {export_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"导出模块分析结果失败: {e}")
            return False
    
    def _compare_to_golden_structure(self, analysis: ModuleAnalysis) -> Dict:
        """与黄金结构对比"""
        comparison = {}
        
        for module_type, config in self.MODULE_TYPES.items():
            target_percentage = config['target_percentage']
            current_percentage = analysis.module_distribution.get(module_type, 0)
            
            comparison[module_type] = {
                'target_percentage': target_percentage,
                'current_percentage': current_percentage,
                'difference': current_percentage - target_percentage,
                'status': 'optimal' if abs(current_percentage - target_percentage) < 0.1 else 'needs_adjustment'
            }
        
        return comparison 