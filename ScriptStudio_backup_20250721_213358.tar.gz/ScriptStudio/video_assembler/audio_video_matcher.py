#!/usr/bin/env python3
"""
🔊 音视频匹配器 - Audio Video Matcher
处理参考音频和切片视频的同步匹配
"""

import logging
import subprocess
import tempfile
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from .composition_config import CompositionConfig
from .segment_selector import SelectionResult
from ..srt_analyzer.timeline_parser import ModuleSegment

logger = logging.getLogger(__name__)

@dataclass 
class VideoSegment:
    """单个视频片段信息"""
    original_video_path: str      # 原始切片视频路径
    processed_video_path: str     # 处理后视频路径 (消音)
    duration: float               # 片段时长
    slice_name: str              # 切片名称
    semantic_score: float        # 语义匹配分数
    visual_features: Dict = None # 视觉特征（用于连贯性判断）

@dataclass 
class ModuleVideoMapping:
    """模块视频映射信息（支持多片段）"""
    module_type: str             # 模块类型
    target_start_time: float     # 目标开始时间
    target_end_time: float       # 目标结束时间
    target_duration: float       # 目标总时长
    video_segments: List[VideoSegment]  # 多个视频片段
    total_duration: float        # 实际总时长
    duration_coverage: float     # 时长覆盖率
    semantic_coherence: float    # 语义连贯性分数

class AudioVideoMatcher:
    """音视频匹配器"""
    
    def __init__(self, config: CompositionConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.temp_files: List[str] = []  # 临时文件列表
    
    def extract_complete_reference_audio(self, ref_video_path: str, temp_dir: str = None) -> str:
        """
        提取参考视频的完整音频轨道
        
        Args:
            ref_video_path: 参考视频路径
            temp_dir: 临时目录
            
        Returns:
            完整音频文件路径
        """
        try:
            if temp_dir is None:
                temp_dir = tempfile.mkdtemp(prefix="audio_extract_")
            
            temp_path = Path(temp_dir)
            temp_path.mkdir(parents=True, exist_ok=True)
            
            self.logger.info(f"🔊 提取参考视频完整音频: {ref_video_path}")
            
            # 提取完整音频轨道
            audio_file = temp_path / f"reference_audio_complete.wav"
            
            cmd = [
                "ffmpeg", "-y",
                "-i", ref_video_path,
                "-vn",  # 不包含视频
                "-acodec", "pcm_s16le",  # 无损音频
                "-ar", "44100",  # 采样率
                "-ac", "2",      # 双声道
                str(audio_file)
            ]
            
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=120
            )
            
            if result.returncode == 0:
                output_file = Path(audio_file)
                if output_file.exists() and output_file.stat().st_size > 0:
                    self.temp_files.append(str(audio_file))
                    self.logger.info(f"✅ 完整音频提取成功: {audio_file}")
                    return str(audio_file)
            
            self.logger.error(f"FFmpeg音频提取失败: {result.stderr}")
            return ""
            
        except Exception as e:
            self.logger.error(f"音频提取失败: {e}")
            return ""
    
    def prepare_timeline_video_segments(self, selection_results: Dict[str, SelectionResult], 
                                       module_segments: List[ModuleSegment],
                                       module_candidates: Dict[str, List] = None,
                                       temp_dir: str = None) -> List[ModuleVideoMapping]:
        """
        根据参考视频时间轴准备多片段拼接（无调速）
        
        Args:
            selection_results: 片段选择结果
            module_segments: 模块时间轴信息（来自参考视频）
            module_candidates: 所有模块候选（用于多片段选择）
            temp_dir: 临时目录
            
        Returns:
            按时间轴排序的模块视频映射列表（支持多片段）
        """
        try:
            if temp_dir is None:
                temp_dir = tempfile.mkdtemp(prefix="video_timeline_")
                
            temp_path = Path(temp_dir)
            temp_path.mkdir(parents=True, exist_ok=True)
            
            self.logger.info("🎬 根据时间轴准备多片段拼接（无调速）")
            
            module_mappings = []
            
            # 按时间轴顺序处理模块
            sorted_modules = sorted(module_segments, key=lambda x: x.start_time)
            
            for i, module in enumerate(sorted_modules):
                module_type = module.module_type
                selection_result = selection_results.get(module_type)
                
                if not selection_result:
                    self.logger.warning(f"⚠️ 模块 {module_type} ({module.start_time:.1f}s-{module.end_time:.1f}s) 没有选择结果")
                    continue
                
                target_duration = module.duration
                self.logger.info(f"📐 {module_type}: 目标时长 {target_duration:.1f}s")
                
                # 为该模块选择和准备多个片段
                module_mapping = self._prepare_module_segments(
                    module=module,
                    selection_result=selection_result,
                    all_candidates=module_candidates.get(module_type, []) if module_candidates else [],
                    temp_path=temp_path,
                    module_index=i
                )
                
                if module_mapping and module_mapping.video_segments:
                    module_mappings.append(module_mapping)
                    self.logger.info(f"✅ {module_type}: 准备了 {len(module_mapping.video_segments)} 个片段 "
                                   f"(总时长: {module_mapping.total_duration:.1f}s, "
                                   f"覆盖率: {module_mapping.duration_coverage:.1%})")
                else:
                    self.logger.error(f"❌ {module_type}: 片段准备失败")
            
            self.logger.info(f"📹 时间轴视频准备完成: {len(module_mappings)} 个模块")
            return module_mappings
            
        except Exception as e:
            self.logger.error(f"时间轴视频准备失败: {e}")
            return []
    
    def _prepare_module_segments(self, module: 'ModuleSegment', selection_result: 'SelectionResult',
                                all_candidates: List, temp_path: Path, module_index: int) -> Optional['ModuleVideoMapping']:
        """
        为单个模块准备多个片段（无调速拼接）
        
        Args:
            module: 模块信息
            selection_result: 选择结果
            all_candidates: 该模块的所有候选片段
            temp_path: 临时目录
            module_index: 模块索引
            
        Returns:
            模块视频映射
        """
        try:
            module_type = module.module_type
            target_duration = module.duration
            
            # 1. 获取所有可用候选（不仅是selected_candidate）
            available_candidates = all_candidates
            if not available_candidates:
                available_candidates = [selection_result.selected_candidate]
            
            # 2. 按语义分数排序候选
            sorted_candidates = sorted(
                available_candidates, 
                key=lambda x: getattr(x, 'similarity_score', 0.5), 
                reverse=True
            )
            
            self.logger.info(f"📊 {module_type}: 可用候选 {len(sorted_candidates)} 个")
            
            # 3. 贪心选择片段组合
            selected_segments = []
            remaining_duration = target_duration
            used_videos = set()  # 避免重复使用同一视频
            
            for candidate in sorted_candidates:
                if remaining_duration <= 0.1:  # 100ms容差
                    break
                
                video_path = candidate.slice_info.file_path
                video_name = candidate.slice_info.video_name
                slice_duration = candidate.slice_info.duration
                
                # 避免重复使用同一个视频文件
                if video_path in used_videos:
                    continue
                
                # 如果这个片段时长超过剩余需求太多，跳过（除非是第一个片段）
                if len(selected_segments) > 0 and slice_duration > remaining_duration * 1.5:
                    continue
                
                # 处理视频（仅消音，不调速）
                safe_name = module_type.replace(' ', '_').replace('/', '_').replace('🪝', 'hook').replace('🍼', 'product').replace('🌟', 'effect').replace('🎁', 'promotion')
                processed_video = temp_path / f"module_{module_index:02d}_{safe_name}_seg_{len(selected_segments):02d}.mp4"
                
                success = self._remove_audio_only(video_path, str(processed_video))
                
                if success:
                    # 创建视频片段对象
                    video_segment = VideoSegment(
                        original_video_path=video_path,
                        processed_video_path=str(processed_video),
                        duration=slice_duration,
                        slice_name=candidate.slice_info.slice_name,
                        semantic_score=getattr(candidate, 'similarity_score', 0.5),
                        visual_features=self._extract_visual_features(video_path)  # 简化版
                    )
                    
                    selected_segments.append(video_segment)
                    self.temp_files.append(str(processed_video))
                    used_videos.add(video_path)
                    remaining_duration -= slice_duration
                    
                    self.logger.info(f"  📹 选择片段: {candidate.slice_info.slice_name} ({slice_duration:.1f}s)")
                else:
                    self.logger.warning(f"  ⚠️ 片段处理失败: {video_path}")
            
            if not selected_segments:
                self.logger.error(f"❌ {module_type}: 没有成功处理的片段")
                return None
            
            # 4. 计算统计信息
            total_duration = sum(seg.duration for seg in selected_segments)
            duration_coverage = min(1.0, total_duration / target_duration)
            
            # 5. 计算语义连贯性
            semantic_coherence = self._calculate_semantic_coherence(selected_segments)
            
            # 6. 创建模块映射
            module_mapping = ModuleVideoMapping(
                module_type=module_type,
                target_start_time=module.start_time,
                target_end_time=module.end_time,
                target_duration=target_duration,
                video_segments=selected_segments,
                total_duration=total_duration,
                duration_coverage=duration_coverage,
                semantic_coherence=semantic_coherence
            )
            
            return module_mapping
            
        except Exception as e:
            self.logger.error(f"模块片段准备失败 {module_type}: {e}")
            return None
    
    def _remove_audio_only(self, video_path: str, output_path: str) -> bool:
        """仅消音，不调速"""
        try:
            cmd = [
                "ffmpeg", "-y",
                "-i", video_path,
                "-c:v", "copy",  # 复制视频流，保持原始速度
                "-an",           # 移除音频
                output_path
            ]
            
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=120
            )
            
            if result.returncode == 0:
                output_file = Path(output_path)
                if output_file.exists() and output_file.stat().st_size > 0:
                    return True
            
            self.logger.error(f"FFmpeg消音失败: {result.stderr}")
            return False
            
        except Exception as e:
            self.logger.error(f"视频消音异常: {e}")
            return False
    
    def _extract_visual_features(self, video_path: str) -> Dict:
        """提取视觉特征（简化版）"""
        # 简化实现：基于文件名和路径提取特征
        # 实际项目中可以使用CLIP或其他视觉模型
        try:
            path_obj = Path(video_path)
            features = {
                'video_name': path_obj.parent.parent.name if path_obj.parent.parent else '',
                'slice_category': path_obj.parent.name if path_obj.parent else '',
                'file_size': path_obj.stat().st_size if path_obj.exists() else 0,
                'scene_type': 'unknown'  # 可以通过视频分析得到
            }
            return features
        except Exception:
            return {}
    
    def _calculate_semantic_coherence(self, segments: List[VideoSegment]) -> float:
        """计算片段间语义连贯性"""
        if len(segments) <= 1:
            return 1.0
        
        try:
            # 1. 语义分数的一致性
            scores = [seg.semantic_score for seg in segments]
            score_variance = sum((s - sum(scores)/len(scores))**2 for s in scores) / len(scores)
            score_coherence = max(0, 1.0 - score_variance)
            
            # 2. 视觉特征的一致性（简化版）
            visual_coherence = 1.0
            if len(segments) > 1:
                same_video_count = 0
                same_category_count = 0
                
                for i in range(len(segments) - 1):
                    f1 = segments[i].visual_features or {}
                    f2 = segments[i + 1].visual_features or {}
                    
                    if f1.get('video_name') == f2.get('video_name'):
                        same_video_count += 1
                    if f1.get('slice_category') == f2.get('slice_category'):
                        same_category_count += 1
                
                visual_coherence = (same_video_count * 0.6 + same_category_count * 0.4) / (len(segments) - 1)
            
            # 3. 综合连贯性分数
            overall_coherence = score_coherence * 0.6 + visual_coherence * 0.4
            
            return max(0.0, min(1.0, overall_coherence))
            
        except Exception as e:
            self.logger.warning(f"语义连贯性计算失败: {e}")
            return 0.5
    
    def create_timeline_composition_plan(self, reference_audio_path: str,
                                        module_mappings: List[ModuleVideoMapping]) -> Dict:
        """
        创建时间轴合成方案（支持多片段）
        
        Args:
            reference_audio_path: 完整参考音频路径
            module_mappings: 按时间轴排序的模块视频映射列表
            
        Returns:
            合成方案字典
        """
        try:
            self.logger.info("🔗 创建时间轴合成方案（多片段支持）")
            
            # 按时间轴排序模块映射
            sorted_mappings = sorted(module_mappings, key=lambda x: x.target_start_time)
            
            # 展开所有视频片段并计算累积时间
            all_video_segments = []
            current_time = 0.0
            
            for module_mapping in sorted_mappings:
                module_start_time = module_mapping.target_start_time
                
                # 为该模块的所有片段分配时间轴位置
                segment_start_time = module_start_time
                
                for i, video_segment in enumerate(module_mapping.video_segments):
                    segment_end_time = segment_start_time + video_segment.duration
                    
                    segment_info = {
                        'segment_index': len(all_video_segments),
                        'module_type': module_mapping.module_type,
                        'module_segment_index': i,  # 在模块内的片段索引
                        'video_file': video_segment.processed_video_path,
                        'start_time': segment_start_time,
                        'end_time': segment_end_time,
                        'duration': video_segment.duration,
                        'slice_name': video_segment.slice_name,
                        'semantic_score': video_segment.semantic_score,
                        'original_video': Path(video_segment.original_video_path).name
                    }
                    
                    all_video_segments.append(segment_info)
                    segment_start_time = segment_end_time
            
            # 验证时间轴连续性
            timeline_gaps = []
            total_expected_duration = sorted_mappings[-1].target_end_time if sorted_mappings else 0
            
            for i, module_mapping in enumerate(sorted_mappings):
                # 检查模块间的间隙
                if i < len(sorted_mappings) - 1:
                    current_module_end = module_mapping.target_start_time + module_mapping.total_duration
                    next_module_start = sorted_mappings[i + 1].target_start_time
                    
                    if next_module_start > current_module_end + 0.1:  # 100ms容差
                        gap_duration = next_module_start - current_module_end
                        timeline_gaps.append({
                            'gap_start': current_module_end,
                            'gap_end': next_module_start,
                            'gap_duration': gap_duration,
                            'after_module': module_mapping.module_type,
                            'before_module': sorted_mappings[i + 1].module_type
                        })
                        self.logger.warning(f"⚠️ 模块间隙: {current_module_end:.1f}s - {next_module_start:.1f}s ({gap_duration:.1f}s)")
                
                # 检查模块内的时长覆盖
                if module_mapping.duration_coverage < 0.9:
                    self.logger.warning(f"⚠️ {module_mapping.module_type}: 时长覆盖不足 ({module_mapping.duration_coverage:.1%})")
            
            # 计算整体统计信息
            total_video_duration = sum(seg['duration'] for seg in all_video_segments)
            coverage_rate = total_video_duration / total_expected_duration if total_expected_duration > 0 else 0
            
            # 计算平均语义连贯性
            avg_semantic_coherence = sum(m.semantic_coherence for m in sorted_mappings) / len(sorted_mappings) if sorted_mappings else 0
            
            composition_plan = {
                'reference_audio': reference_audio_path,
                'video_segments': all_video_segments,
                'module_info': [
                    {
                        'module_type': mapping.module_type,
                        'target_start_time': mapping.target_start_time,
                        'target_end_time': mapping.target_end_time,
                        'target_duration': mapping.target_duration,
                        'actual_duration': mapping.total_duration,
                        'duration_coverage': mapping.duration_coverage,
                        'semantic_coherence': mapping.semantic_coherence,
                        'segment_count': len(mapping.video_segments)
                    }
                    for mapping in sorted_mappings
                ],
                'timeline_info': {
                    'total_duration': total_expected_duration,
                    'total_video_duration': total_video_duration,
                    'module_count': len(sorted_mappings),
                    'total_segment_count': len(all_video_segments),
                    'coverage_rate': coverage_rate,
                    'avg_semantic_coherence': avg_semantic_coherence,
                    'timeline_gaps': timeline_gaps,
                    'has_gaps': len(timeline_gaps) > 0
                },
                'composition_quality': self._calculate_multi_segment_quality(sorted_mappings, timeline_gaps)
            }
            
            self.logger.info(f"📋 多片段合成方案创建完成:")
            self.logger.info(f"   🎵 参考音频: {Path(reference_audio_path).name}")
            self.logger.info(f"   📁 模块数量: {len(sorted_mappings)} 个")
            self.logger.info(f"   🎬 视频片段: {len(all_video_segments)} 个")
            self.logger.info(f"   ⏱️ 总时长: {total_expected_duration:.1f}s")
            self.logger.info(f"   📊 覆盖率: {coverage_rate:.1%}")
            self.logger.info(f"   🧠 语义连贯性: {avg_semantic_coherence:.2f}")
            
            if timeline_gaps:
                self.logger.warning(f"   ⚠️ 时间轴间隙: {len(timeline_gaps)} 个")
            
            return composition_plan
            
        except Exception as e:
            self.logger.error(f"创建多片段合成方案失败: {e}")
            return {}
    

    
    def _process_video_for_timeline(self, video_path: str, output_path: str, target_duration: float) -> bool:
        """
        为时间轴处理视频：消音 + 调速以匹配目标时长
        
        Args:
            video_path: 输入视频路径
            output_path: 输出视频路径
            target_duration: 目标时长（秒）
            
        Returns:
            处理是否成功
        """
        try:
            # 获取原视频信息
            video_info = self.get_video_info(video_path)
            if not video_info or 'format' not in video_info:
                self.logger.error(f"无法获取视频信息: {video_path}")
                return False
            
            original_duration = float(video_info['format'].get('duration', 0))
            if original_duration <= 0:
                self.logger.error(f"视频时长无效: {original_duration}")
                return False
            
            # 计算调速因子
            speed_factor = original_duration / target_duration
            
            # 构建FFmpeg命令：消音 + 调速
            cmd = [
                "ffmpeg", "-y",
                "-i", video_path,
                "-an",  # 移除音频
                "-c:v", "libx264",  # 重新编码视频（调速需要）
                "-preset", "medium",
                "-crf", "23"
            ]
            
            # 添加调速滤镜
            if abs(speed_factor - 1.0) > 0.05:  # 5%容差，超过才调速
                cmd.extend(["-filter:v", f"setpts={speed_factor}*PTS"])
                self.logger.info(f"📏 应用调速: {speed_factor:.2f}x (目标: {target_duration:.1f}s)")
            else:
                self.logger.info(f"📏 无需调速 (时长匹配: {original_duration:.1f}s ≈ {target_duration:.1f}s)")
            
            cmd.append(output_path)
            
            # 执行命令
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=180
            )
            
            if result.returncode == 0:
                # 验证输出文件
                output_file = Path(output_path)
                if output_file.exists() and output_file.stat().st_size > 0:
                    # 验证输出时长
                    output_info = self.get_video_info(output_path)
                    if output_info and 'format' in output_info:
                        actual_duration = float(output_info['format'].get('duration', 0))
                        duration_diff = abs(actual_duration - target_duration)
                        
                        if duration_diff < 0.5:  # 500ms容差
                            self.logger.info(f"✅ 视频处理成功: {actual_duration:.1f}s (目标: {target_duration:.1f}s)")
                            return True
                        else:
                            self.logger.warning(f"⚠️ 时长偏差较大: {actual_duration:.1f}s vs {target_duration:.1f}s")
                            return True  # 仍然接受，可能是编码误差
                    
                    return True
            
            self.logger.error(f"FFmpeg视频处理失败: {result.stderr}")
            return False
            
        except Exception as e:
            self.logger.error(f"视频处理异常: {e}")
            return False
    
    def _calculate_multi_segment_quality(self, module_mappings: List[ModuleVideoMapping], 
                                        timeline_gaps: List[Dict]) -> Dict:
        """计算多片段合成质量"""
        try:
            if not module_mappings:
                return {
                    'overall_score': 0.0,
                    'quality_level': '无',
                    'issues': ['没有视频片段'],
                    'recommendations': ['添加视频片段']
                }
            
            # 1. 时长覆盖质量
            coverage_scores = [mapping.duration_coverage for mapping in module_mappings]
            avg_coverage_quality = sum(coverage_scores) / len(coverage_scores)
            
            # 2. 语义连贯性质量
            coherence_scores = [mapping.semantic_coherence for mapping in module_mappings]
            avg_coherence_quality = sum(coherence_scores) / len(coherence_scores)
            
            # 3. 时间轴连续性质量
            timeline_quality = 1.0
            if timeline_gaps:
                gap_penalty = min(0.5, len(timeline_gaps) * 0.15)  # 多片段对间隙更敏感
                timeline_quality = max(0.3, 1.0 - gap_penalty)
            
            # 4. 片段分布质量（避免过度分割或集中）
            segment_counts = [len(mapping.video_segments) for mapping in module_mappings]
            avg_segments_per_module = sum(segment_counts) / len(segment_counts)
            
            # 理想的片段数是1-3个，超过3个可能过度分割
            if avg_segments_per_module <= 3:
                segmentation_quality = 1.0
            elif avg_segments_per_module <= 5:
                segmentation_quality = 0.8
            else:
                segmentation_quality = 0.6
            
            # 5. 综合质量计算（调整权重以反映多片段特点）
            overall_score = (
                avg_coverage_quality * 0.3 +     # 时长覆盖 30%
                avg_coherence_quality * 0.3 +    # 语义连贯性 30%
                timeline_quality * 0.25 +        # 时间轴连续性 25%
                segmentation_quality * 0.15      # 片段分布 15%
            )
            
            # 6. 质量等级
            if overall_score >= 0.85:
                quality_level = '优秀'
            elif overall_score >= 0.70:
                quality_level = '良好'
            elif overall_score >= 0.50:
                quality_level = '一般'
            else:
                quality_level = '较差'
            
            # 7. 问题识别和建议
            issues = []
            recommendations = []
            
            # 时长覆盖问题
            low_coverage_modules = [m for m in module_mappings if m.duration_coverage < 0.8]
            if low_coverage_modules:
                issues.append(f'{len(low_coverage_modules)} 个模块时长覆盖不足')
                recommendations.append('为时长覆盖不足的模块选择更多切片')
            
            # 语义连贯性问题
            low_coherence_modules = [m for m in module_mappings if m.semantic_coherence < 0.6]
            if low_coherence_modules:
                issues.append(f'{len(low_coherence_modules)} 个模块语义连贯性较差')
                recommendations.append('选择语义更相似的切片进行拼接')
            
            # 时间轴间隙问题
            if timeline_gaps:
                issues.append(f'时间轴存在 {len(timeline_gaps)} 个间隙')
                recommendations.append('补充缺失时间段的视频片段')
            
            # 过度分割问题
            over_segmented = [m for m in module_mappings if len(m.video_segments) > 4]
            if over_segmented:
                issues.append(f'{len(over_segmented)} 个模块过度分割（>4片段）')
                recommendations.append('选择更长的切片减少分割数量')
            
            # 欠分割问题（时长覆盖不足但只有1个片段）
            under_segmented = [m for m in module_mappings if len(m.video_segments) == 1 and m.duration_coverage < 0.7]
            if under_segmented:
                issues.append(f'{len(under_segmented)} 个模块需要更多片段')
                recommendations.append('为时长不足的模块添加更多切片')
            
            return {
                'overall_score': overall_score,
                'quality_level': quality_level,
                'component_scores': {
                    'coverage_quality': avg_coverage_quality,
                    'coherence_quality': avg_coherence_quality,
                    'timeline_continuity': timeline_quality,
                    'segmentation_quality': segmentation_quality
                },
                'statistics': {
                    'total_modules': len(module_mappings),
                    'total_segments': sum(segment_counts),
                    'avg_segments_per_module': avg_segments_per_module,
                    'timeline_gaps': len(timeline_gaps),
                    'avg_coverage_rate': avg_coverage_quality,
                    'avg_semantic_coherence': avg_coherence_quality,
                    'low_coverage_modules': len(low_coverage_modules),
                    'low_coherence_modules': len(low_coherence_modules)
                },
                'issues': issues,
                'recommendations': recommendations
            }
            
        except Exception as e:
            self.logger.error(f"计算多片段合成质量失败: {e}")
            return {
                'overall_score': 0.0,
                'quality_level': '未知',
                'issues': [f'质量计算失败: {str(e)}'],
                'recommendations': ['检查系统配置']
            }
    
    def _calculate_composition_quality(self, video_mappings: List[VideoMapping], 
                                     timeline_gaps: List[Dict]) -> Dict:
        """计算整体合成质量"""
        try:
            if not video_mappings:
                return {
                    'overall_score': 0.0,
                    'quality_level': '无',
                    'issues': ['没有视频片段'],
                    'recommendations': ['添加视频片段']
                }
            
            # 1. 时长匹配质量
            duration_scores = []
            for mapping in video_mappings:
                target_duration = mapping.target_end_time - mapping.target_start_time
                scaling_factor = mapping.scaling_factor
                
                # 调速程度影响质量
                if abs(scaling_factor - 1.0) < 0.1:
                    duration_score = 1.0  # 无需调速
                elif abs(scaling_factor - 1.0) < 0.3:
                    duration_score = 0.8  # 轻微调速
                elif abs(scaling_factor - 1.0) < 0.5:
                    duration_score = 0.6  # 中等调速
                else:
                    duration_score = 0.3  # 大幅调速
                
                duration_scores.append(duration_score)
            
            avg_duration_quality = sum(duration_scores) / len(duration_scores)
            
            # 2. 时间轴连续性质量
            timeline_quality = 1.0
            if timeline_gaps:
                gap_penalty = min(0.5, len(timeline_gaps) * 0.1)
                timeline_quality = max(0.5, 1.0 - gap_penalty)
            
            # 3. 覆盖率质量
            total_video_duration = sum(
                mapping.target_end_time - mapping.target_start_time 
                for mapping in video_mappings
            )
            total_timeline = video_mappings[-1].target_end_time if video_mappings else 0
            coverage_rate = total_video_duration / total_timeline if total_timeline > 0 else 0
            
            coverage_quality = coverage_rate  # 覆盖率直接作为质量分数
            
            # 4. 综合质量计算
            overall_score = (
                avg_duration_quality * 0.4 +  # 时长匹配 40%
                timeline_quality * 0.3 +      # 时间轴连续性 30%
                coverage_quality * 0.3        # 覆盖率 30%
            )
            
            # 5. 质量等级
            if overall_score >= 0.8:
                quality_level = '优秀'
            elif overall_score >= 0.6:
                quality_level = '良好'
            elif overall_score >= 0.4:
                quality_level = '一般'
            else:
                quality_level = '较差'
            
            # 6. 问题识别和建议
            issues = []
            recommendations = []
            
            if avg_duration_quality < 0.7:
                issues.append('多个视频片段需要大幅调速')
                recommendations.append('选择时长更匹配的切片视频')
            
            if timeline_gaps:
                issues.append(f'时间轴存在 {len(timeline_gaps)} 个间隙')
                recommendations.append('补充缺失时间段的视频片段')
            
            if coverage_rate < 0.9:
                issues.append(f'时间轴覆盖率较低 ({coverage_rate:.1%})')
                recommendations.append('确保所有模块都有对应的视频片段')
            
            # 检查调速极端情况
            extreme_scaling = [m for m in video_mappings if abs(m.scaling_factor - 1.0) > 0.5]
            if extreme_scaling:
                issues.append(f'{len(extreme_scaling)} 个片段需要极端调速')
                recommendations.append('重新选择时长更适合的视频片段')
            
            return {
                'overall_score': overall_score,
                'quality_level': quality_level,
                'component_scores': {
                    'duration_matching': avg_duration_quality,
                    'timeline_continuity': timeline_quality,
                    'coverage_rate': coverage_quality
                },
                'statistics': {
                    'total_segments': len(video_mappings),
                    'timeline_gaps': len(timeline_gaps),
                    'coverage_rate': coverage_rate,
                    'avg_scaling_factor': sum(abs(m.scaling_factor - 1.0) for m in video_mappings) / len(video_mappings),
                    'extreme_scaling_count': len(extreme_scaling)
                },
                'issues': issues,
                'recommendations': recommendations
            }
            
        except Exception as e:
            self.logger.error(f"计算合成质量失败: {e}")
            return {
                'overall_score': 0.0,
                'quality_level': '未知',
                'issues': [f'质量计算失败: {str(e)}'],
                'recommendations': ['检查系统配置']
            }
    
    def adjust_video_speed(self, video_mapping: VideoMapping, 
                         target_duration: float, output_path: str) -> bool:
        """调整视频播放速度以匹配目标时长"""
        try:
            scaling_factor = video_mapping.source_duration / target_duration
            
            # FFmpeg调速命令
            cmd = [
                "ffmpeg", "-y",
                "-i", video_mapping.processed_video_path,
                "-filter:v", f"setpts={scaling_factor}*PTS",
                "-c:v", "libx264",
                "-preset", "medium",
                "-crf", "23",
                output_path
            ]
            
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=180
            )
            
            if result.returncode == 0:
                output_file = Path(output_path)
                if output_file.exists() and output_file.stat().st_size > 0:
                    self.logger.info(f"视频调速成功: {scaling_factor:.2f}x -> {output_path}")
                    return True
            
            self.logger.error(f"FFmpeg调速失败: {result.stderr}")
            return False
            
        except Exception as e:
            self.logger.error(f"视频调速异常: {e}")
            return False
    
    def get_video_info(self, video_path: str) -> Dict:
        """获取视频信息"""
        try:
            cmd = [
                "ffprobe", "-v", "quiet", "-print_format", "json",
                "-show_format", "-show_streams", video_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                return json.loads(result.stdout)
            else:
                self.logger.error(f"FFprobe获取视频信息失败: {result.stderr}")
                return {}
                
        except Exception as e:
            self.logger.error(f"获取视频信息异常: {e}")
            return {}
    
    def validate_audio_video_sync(self, audio_path: str, video_path: str) -> Dict:
        """验证音视频同步性"""
        try:
            # 获取音频信息
            audio_info = self.get_video_info(audio_path)
            video_info = self.get_video_info(video_path)
            
            audio_duration = 0
            video_duration = 0
            
            # 解析时长
            if 'format' in audio_info:
                audio_duration = float(audio_info['format'].get('duration', 0))
            
            if 'format' in video_info:
                video_duration = float(video_info['format'].get('duration', 0))
            
            # 计算同步质量
            duration_diff = abs(audio_duration - video_duration)
            sync_quality = max(0, 1.0 - duration_diff * 0.5)
            
            return {
                'audio_duration': audio_duration,
                'video_duration': video_duration,
                'duration_diff': duration_diff,
                'sync_quality': sync_quality,
                'is_synced': duration_diff < 0.1  # 100ms容差
            }
            
        except Exception as e:
            self.logger.error(f"同步验证异常: {e}")
            return {}
    
    def cleanup_temp_files(self):
        """清理临时文件"""
        if not self.config.generation_config.temp_cleanup:
            return
            
        self.logger.info("🗑️ 清理临时文件")
        
        for temp_file in self.temp_files:
            try:
                Path(temp_file).unlink(missing_ok=True)
            except Exception as e:
                self.logger.warning(f"清理临时文件失败 {temp_file}: {e}")
        
        self.temp_files.clear()
    
    def __del__(self):
        """析构函数：自动清理临时文件"""
        self.cleanup_temp_files() 