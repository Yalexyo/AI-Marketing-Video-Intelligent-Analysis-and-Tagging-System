#!/usr/bin/env python3
"""
🎬 Video Assembler - 视频合成模块
自动视频合成：保留参考音频 + 智能匹配切片画面
"""

from .video_composer import VideoComposer
from .audio_video_matcher import AudioVideoMatcher
from .segment_selector import SegmentSelector
from .composition_config import CompositionConfig

__all__ = [
    'VideoComposer',
    'AudioVideoMatcher', 
    'SegmentSelector',
    'CompositionConfig'
] 