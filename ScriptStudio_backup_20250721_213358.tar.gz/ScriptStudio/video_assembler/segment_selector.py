#!/usr/bin/env python3
"""
🎯 片段选择器 - Segment Selector  
智能选择匹配的视频切片，支持多种策略和随机化
"""

import logging
import random
import math
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass
from pathlib import Path

from .composition_config import CompositionConfig, MatchingStrategy
from ..material_engine.similarity_matcher import MatchCandidate
from ..srt_analyzer.timeline_parser import ModuleSegment

logger = logging.getLogger(__name__)

@dataclass
class SelectionResult:
    """片段选择结果"""
    selected_candidate: MatchCandidate
    selection_score: float
    selection_reason: str
    alternatives_count: int
    diversity_bonus: float = 0.0
    random_factor: float = 0.0

@dataclass
class SelectionSummary:
    """选择总结"""
    total_segments: int
    selected_segments: int
    average_score: float
    strategy_used: str
    video_source_distribution: Dict[str, int]  # 视频源分布
    quality_distribution: Dict[str, int]       # 质量分布
    duration_coverage: float                   # 时长覆盖率
    warnings: List[str]

class SegmentSelector:
    """片段选择器"""
    
    def __init__(self, config: CompositionConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.used_candidates: Set[str] = set()  # 已使用的候选ID
        self.video_usage_count: Dict[str, int] = {}  # 视频使用计数
        
    def select_segments_for_composition(self, 
                                      module_candidates: Dict[str, List[MatchCandidate]],
                                      module_segments: List[ModuleSegment]) -> Dict[str, SelectionResult]:
        """
        为视频合成选择片段
        
        Args:
            module_candidates: 模块候选切片字典 {module_type: [candidates]}
            module_segments: 模块时间轴信息
            
        Returns:
            选择结果字典 {module_type: SelectionResult}
        """
        try:
            self.logger.info(f"🎯 开始片段选择 - 策略: {self.config.matching_strategy.value}")
            
            # 重置状态
            self.used_candidates.clear()
            self.video_usage_count.clear()
            
            selection_results = {}
            
            # 为每个模块选择最佳片段
            for module in module_segments:
                module_type = module.module_type
                candidates = module_candidates.get(module_type, [])
                
                if not candidates:
                    self.logger.warning(f"模块 {module_type} 没有候选切片")
                    continue
                
                # 执行选择
                result = self._select_single_segment(
                    module_type, candidates, module.duration
                )
                
                if result:
                    selection_results[module_type] = result
                    self.logger.info(f"✅ {module_type}: {result.selection_reason} (分数: {result.selection_score:.3f})")
                else:
                    self.logger.error(f"❌ {module_type}: 选择失败")
            
            # 生成选择总结
            summary = self._generate_selection_summary(selection_results, module_segments)
            self.logger.info(f"📊 选择完成: {summary.selected_segments}/{summary.total_segments} 个模块")
            
            return selection_results
            
        except Exception as e:
            self.logger.error(f"片段选择失败: {e}")
            return {}
    
    def _select_single_segment(self, module_type: str, candidates: List[MatchCandidate], 
                             target_duration: float) -> Optional[SelectionResult]:
        """选择单个模块的片段"""
        if not candidates:
            return None
            
        # 过滤已使用的候选
        available_candidates = self._filter_available_candidates(candidates)
        
        if not available_candidates:
            self.logger.warning(f"{module_type}: 所有候选都已使用，启用重复使用模式")
            available_candidates = candidates  # 允许重复使用
        
        # 根据策略选择
        if self.config.matching_strategy == MatchingStrategy.SEMANTIC_PRIORITY:
            return self._select_by_semantic(module_type, available_candidates, target_duration)
        elif self.config.matching_strategy == MatchingStrategy.DURATION_PRIORITY:
            return self._select_by_duration(module_type, available_candidates, target_duration)
        elif self.config.matching_strategy == MatchingStrategy.QUALITY_PRIORITY:
            return self._select_by_quality(module_type, available_candidates, target_duration)
        elif self.config.matching_strategy == MatchingStrategy.RANDOM_WEIGHTED:
            return self._select_by_weighted_random(module_type, available_candidates, target_duration)
        else:  # BALANCED
            return self._select_by_balanced(module_type, available_candidates, target_duration)
    
    def _filter_available_candidates(self, candidates: List[MatchCandidate]) -> List[MatchCandidate]:
        """过滤可用的候选切片"""
        if not self.config.matching_params.avoid_repetition:
            return candidates
            
        available = []
        max_same_video = self.config.matching_params.max_same_video_ratio
        
        for candidate in candidates:
            candidate_id = f"{candidate.slice_info.video_name}_{candidate.slice_info.slice_name}"
            video_name = candidate.slice_info.video_name
            
            # 检查是否已使用
            if candidate_id in self.used_candidates:
                continue
                
            # 检查同一视频使用比例
            video_usage = self.video_usage_count.get(video_name, 0)
            total_selections = len(self.used_candidates)
            
            if total_selections > 0:
                usage_ratio = video_usage / total_selections
                if usage_ratio >= max_same_video:
                    continue
            
            available.append(candidate)
        
        return available
    
    def _calculate_selection_score(self, candidate: MatchCandidate, target_duration: float) -> Tuple[float, Dict]:
        """计算选择分数"""
        params = self.config.matching_params
        details = {}
        
        # 1. 语义分数 (基于原有的匹配分数)
        semantic_score = candidate.match_score
        details['semantic'] = semantic_score
        
        # 2. 时长匹配分数
        duration_ratio = candidate.slice_info.duration / target_duration if target_duration > 0 else 1.0
        if params.min_duration_ratio <= duration_ratio <= params.max_duration_ratio:
            duration_score = 1.0 - abs(duration_ratio - 1.0) * 0.5  # 越接近1.0分数越高
        else:
            duration_score = max(0.1, 1.0 - abs(duration_ratio - 1.0))  # 超出范围但不完全为0
        details['duration'] = duration_score
        
        # 3. 质量分数 (基于置信度)
        quality_score = candidate.slice_info.confidence
        details['quality'] = quality_score
        
        # 4. 多样性分数
        video_name = candidate.slice_info.video_name
        video_usage = self.video_usage_count.get(video_name, 0)
        diversity_score = max(0.1, 1.0 - (video_usage * 0.3))  # 使用越多分数越低
        details['diversity'] = diversity_score
        
        # 5. 加权计算总分
        total_score = (
            semantic_score * params.semantic_weight +
            duration_score * params.duration_weight +
            quality_score * params.quality_weight +
            diversity_score * params.diversity_weight
        )
        
        details['total'] = total_score
        return total_score, details
    
    def _select_by_semantic(self, module_type: str, candidates: List[MatchCandidate], 
                          target_duration: float) -> Optional[SelectionResult]:
        """语义优先选择"""
        # 按语义分数排序
        scored_candidates = [
            (candidate, self._calculate_selection_score(candidate, target_duration))
            for candidate in candidates
        ]
        
        # 语义优先：主要按match_score排序，其他作为次要因素
        scored_candidates.sort(key=lambda x: (x[1][0], x[0].match_score), reverse=True)
        
        best_candidate, (score, details) = scored_candidates[0]
        
        # 记录使用
        self._record_usage(best_candidate)
        
        return SelectionResult(
            selected_candidate=best_candidate,
            selection_score=score,
            selection_reason=f"语义优先 (语义分数: {best_candidate.match_score:.3f})",
            alternatives_count=len(candidates) - 1
        )
    
    def _select_by_duration(self, module_type: str, candidates: List[MatchCandidate], 
                          target_duration: float) -> Optional[SelectionResult]:
        """时长优先选择"""
        # 按时长匹配度排序
        duration_scored = []
        for candidate in candidates:
            duration_diff = abs(candidate.slice_info.duration - target_duration)
            duration_score = 1.0 / (1.0 + duration_diff)  # 时长差越小分数越高
            total_score, details = self._calculate_selection_score(candidate, target_duration)
            
            duration_scored.append((candidate, duration_score, total_score, details))
        
        # 按时长匹配度排序
        duration_scored.sort(key=lambda x: x[1], reverse=True)
        
        best_candidate, duration_score, total_score, details = duration_scored[0]
        
        # 记录使用
        self._record_usage(best_candidate)
        
        return SelectionResult(
            selected_candidate=best_candidate,
            selection_score=total_score,
            selection_reason=f"时长优先 (时长匹配: {duration_score:.3f})",
            alternatives_count=len(candidates) - 1
        )
    
    def _select_by_quality(self, module_type: str, candidates: List[MatchCandidate], 
                         target_duration: float) -> Optional[SelectionResult]:
        """质量优先选择"""
        # 按质量分数排序
        quality_scored = [
            (candidate, candidate.slice_info.confidence, self._calculate_selection_score(candidate, target_duration))
            for candidate in candidates
        ]
        
        quality_scored.sort(key=lambda x: x[1], reverse=True)
        
        best_candidate, quality_score, (total_score, details) = quality_scored[0]
        
        # 记录使用
        self._record_usage(best_candidate)
        
        return SelectionResult(
            selected_candidate=best_candidate,
            selection_score=total_score,
            selection_reason=f"质量优先 (质量分数: {quality_score:.3f})",
            alternatives_count=len(candidates) - 1
        )
    
    def _select_by_weighted_random(self, module_type: str, candidates: List[MatchCandidate], 
                                 target_duration: float) -> Optional[SelectionResult]:
        """加权随机选择"""
        # 计算所有候选的分数
        scored_candidates = []
        for candidate in candidates:
            total_score, details = self._calculate_selection_score(candidate, target_duration)
            scored_candidates.append((candidate, total_score, details))
        
        # 过滤高质量候选（分数 > 最低阈值）
        min_score = self.config.matching_params.min_match_score
        qualified_candidates = [
            (candidate, score, details) for candidate, score, details in scored_candidates
            if score >= min_score
        ]
        
        if not qualified_candidates:
            # 如果没有合格的，选择最好的
            qualified_candidates = [max(scored_candidates, key=lambda x: x[1])]
        
        # 加权随机选择
        weights = [score for _, score, _ in qualified_candidates]
        selected_idx = random.choices(range(len(qualified_candidates)), weights=weights)[0]
        
        best_candidate, total_score, details = qualified_candidates[selected_idx]
        
        # 记录使用
        self._record_usage(best_candidate)
        
        random_factor = self.config.matching_params.randomness_factor
        
        return SelectionResult(
            selected_candidate=best_candidate,
            selection_score=total_score,
            selection_reason=f"加权随机 (权重: {total_score:.3f}, 随机因子: {random_factor:.1f})",
            alternatives_count=len(candidates) - 1,
            random_factor=random_factor
        )
    
    def _select_by_balanced(self, module_type: str, candidates: List[MatchCandidate], 
                          target_duration: float) -> Optional[SelectionResult]:
        """平衡模式选择"""
        # 计算综合分数
        scored_candidates = []
        for candidate in candidates:
            total_score, details = self._calculate_selection_score(candidate, target_duration)
            scored_candidates.append((candidate, total_score, details))
        
        # 添加随机因子
        randomness = self.config.matching_params.randomness_factor
        if randomness > 0:
            for i, (candidate, score, details) in enumerate(scored_candidates):
                random_bonus = random.uniform(-randomness, randomness)
                adjusted_score = max(0, score + random_bonus)
                scored_candidates[i] = (candidate, adjusted_score, details)
        
        # 按综合分数排序
        scored_candidates.sort(key=lambda x: x[1], reverse=True)
        
        best_candidate, total_score, details = scored_candidates[0]
        
        # 记录使用
        self._record_usage(best_candidate)
        
        return SelectionResult(
            selected_candidate=best_candidate,
            selection_score=total_score,
            selection_reason=f"平衡模式 (综合分数: {total_score:.3f})",
            alternatives_count=len(candidates) - 1
        )
    
    def _record_usage(self, candidate: MatchCandidate):
        """记录候选使用情况"""
        candidate_id = f"{candidate.slice_info.video_name}_{candidate.slice_info.slice_name}"
        self.used_candidates.add(candidate_id)
        
        video_name = candidate.slice_info.video_name
        self.video_usage_count[video_name] = self.video_usage_count.get(video_name, 0) + 1
    
    def _generate_selection_summary(self, selection_results: Dict[str, SelectionResult], 
                                  module_segments: List[ModuleSegment]) -> SelectionSummary:
        """生成选择总结"""
        total_segments = len(module_segments)
        selected_segments = len(selection_results)
        
        if selected_segments == 0:
            return SelectionSummary(
                total_segments=total_segments,
                selected_segments=0,
                average_score=0.0,
                strategy_used=self.config.matching_strategy.value,
                video_source_distribution={},
                quality_distribution={},
                duration_coverage=0.0,
                warnings=["没有成功选择任何片段"]
            )
        
        # 计算平均分数
        average_score = sum(result.selection_score for result in selection_results.values()) / selected_segments
        
        # 视频源分布
        video_distribution = {}
        for result in selection_results.values():
            video_name = result.selected_candidate.slice_info.video_name
            video_distribution[video_name] = video_distribution.get(video_name, 0) + 1
        
        # 质量分布
        quality_distribution = {"高": 0, "中": 0, "低": 0}
        for result in selection_results.values():
            confidence = result.selected_candidate.slice_info.confidence
            if confidence >= 0.8:
                quality_distribution["高"] += 1
            elif confidence >= 0.5:
                quality_distribution["中"] += 1
            else:
                quality_distribution["低"] += 1
        
        # 时长覆盖率
        total_target_duration = sum(module.duration for module in module_segments)
        total_selected_duration = sum(
            result.selected_candidate.slice_info.duration 
            for result in selection_results.values()
        )
        duration_coverage = total_selected_duration / total_target_duration if total_target_duration > 0 else 0
        
        # 生成警告
        warnings = []
        if selected_segments < total_segments:
            warnings.append(f"有 {total_segments - selected_segments} 个模块未选择到合适片段")
        
        if duration_coverage < 0.8:
            warnings.append(f"时长覆盖率较低 ({duration_coverage:.1%})")
            
        if quality_distribution["低"] > selected_segments * 0.3:
            warnings.append("低质量片段比例较高")
        
        return SelectionSummary(
            total_segments=total_segments,
            selected_segments=selected_segments,
            average_score=average_score,
            strategy_used=self.config.matching_strategy.value,
            video_source_distribution=video_distribution,
            quality_distribution=quality_distribution,
            duration_coverage=duration_coverage,
            warnings=warnings
        )

    def generate_multiple_variations(self, 
                                   module_candidates: Dict[str, List[MatchCandidate]],
                                   module_segments: List[ModuleSegment],
                                   num_variations: int = None) -> List[Dict[str, SelectionResult]]:
        """
        生成多个选择变体
        
        Args:
            module_candidates: 模块候选切片
            module_segments: 模块时间轴
            num_variations: 变体数量，None使用配置默认值
            
        Returns:
            变体选择结果列表
        """
        if num_variations is None:
            num_variations = self.config.generation_config.num_variations
        
        self.logger.info(f"🎲 生成 {num_variations} 个选择变体")
        
        variations = []
        original_randomness = self.config.matching_params.randomness_factor
        
        for i in range(num_variations):
            # 为每个变体调整随机因子
            if num_variations > 1:
                variation_randomness = original_randomness * (0.5 + i * 0.5 / (num_variations - 1))
                self.config.matching_params.randomness_factor = variation_randomness
            
            # 重置使用状态以生成不同变体
            self.used_candidates.clear()
            self.video_usage_count.clear()
            
            # 生成变体
            variation_result = self.select_segments_for_composition(module_candidates, module_segments)
            variations.append(variation_result)
            
            self.logger.info(f"✅ 变体 {i+1}: {len(variation_result)} 个模块选择完成")
        
        # 恢复原始配置
        self.config.matching_params.randomness_factor = original_randomness
        
        return variations 