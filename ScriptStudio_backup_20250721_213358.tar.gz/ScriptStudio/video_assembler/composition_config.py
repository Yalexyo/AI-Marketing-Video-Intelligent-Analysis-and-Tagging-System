#!/usr/bin/env python3
"""
🎛️ 视频合成配置 - Composition Config
定义视频合成的参数、策略和质量设置
"""

import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

class MatchingStrategy(Enum):
    """匹配策略枚举"""
    SEMANTIC_PRIORITY = "semantic_priority"      # 语义优先
    DURATION_PRIORITY = "duration_priority"      # 时长优先
    QUALITY_PRIORITY = "quality_priority"        # 质量优先
    BALANCED = "balanced"                        # 平衡模式
    RANDOM_WEIGHTED = "random_weighted"          # 加权随机

class VideoQuality(Enum):
    """视频质量设置"""
    ULTRA = "ultra"    # 超高清 (CRF 18)
    HIGH = "high"      # 高清 (CRF 23)
    MEDIUM = "medium"  # 中等 (CRF 28)
    LOW = "low"        # 低质量 (CRF 32)

@dataclass
class MatchingParameters:
    """匹配参数配置"""
    # 核心匹配参数
    semantic_weight: float = 0.4        # 语义相似度权重
    duration_weight: float = 0.3        # 时长匹配权重  
    quality_weight: float = 0.2         # 质量评分权重
    diversity_weight: float = 0.1       # 多样性权重
    
    # 阈值设置
    min_match_score: float = 0.3        # 最低匹配分数
    preferred_score: float = 0.6        # 偏好分数阈值
    excellent_score: float = 0.8        # 优秀分数阈值
    
    # 时长容差
    duration_tolerance: float = 0.3     # 时长容差比例 (30%)
    min_duration_ratio: float = 0.7     # 最小时长比例
    max_duration_ratio: float = 1.5     # 最大时长比例
    
    # 随机性控制
    randomness_factor: float = 0.2      # 随机因子 (20%的随机性)
    avoid_repetition: bool = True       # 避免重复使用同一切片
    max_same_video_ratio: float = 0.4   # 同一原视频最大使用比例

@dataclass 
class VideoGenerationConfig:
    """视频生成配置"""
    # 生成数量
    num_variations: int = 3             # 生成变体数量
    enable_ab_testing: bool = True      # 启用A/B测试版本
    
    # 视频质量
    video_quality: VideoQuality = VideoQuality.HIGH
    audio_quality: str = "192k"         # 音频码率
    frame_rate: int = 30               # 帧率
    
    # 文件设置
    output_format: str = "mp4"         # 输出格式
    enable_preview: bool = True        # 生成预览版本
    preview_duration: float = 15.0     # 预览时长
    
    # 处理设置
    parallel_workers: int = 2          # 并行生成数量
    temp_cleanup: bool = True          # 自动清理临时文件

@dataclass
class CompositionConfig:
    """完整的视频合成配置"""
    
    # 核心策略
    matching_strategy: MatchingStrategy = MatchingStrategy.BALANCED
    matching_params: MatchingParameters = field(default_factory=MatchingParameters)
    generation_config: VideoGenerationConfig = field(default_factory=VideoGenerationConfig)
    
    # 音频处理
    preserve_original_audio: bool = True    # 保留原始音频
    audio_fade_duration: float = 0.1        # 音频淡入淡出时长
    audio_normalization: bool = True        # 音频标准化
    
    # 视频处理  
    remove_slice_audio: bool = True         # 移除切片音频
    video_transition_type: str = "cut"      # 转场类型 (cut/fade/dissolve)
    transition_duration: float = 0.0       # 转场时长
    
    # 高级选项
    enable_smart_cropping: bool = False     # 智能裁剪
    enable_color_matching: bool = False     # 颜色匹配
    enable_stabilization: bool = False      # 视频稳定
    
    # 输出控制
    output_naming_pattern: str = "{video_name}_composed_v{version}_{strategy}"
    include_metadata: bool = True           # 包含元数据
    generate_report: bool = True            # 生成合成报告

    def get_ffmpeg_video_params(self) -> List[str]:
        """获取FFmpeg视频参数"""
        quality_map = {
            VideoQuality.ULTRA: "18",
            VideoQuality.HIGH: "23", 
            VideoQuality.MEDIUM: "28",
            VideoQuality.LOW: "32"
        }
        
        crf = quality_map[self.generation_config.video_quality]
        
        return [
            "-c:v", "libx264",
            "-crf", crf,
            "-preset", "medium",
            "-r", str(self.generation_config.frame_rate)
        ]
    
    def get_ffmpeg_audio_params(self) -> List[str]:
        """获取FFmpeg音频参数"""
        params = ["-c:a", "aac", "-b:a", self.generation_config.audio_quality]
        
        if self.audio_normalization:
            params.extend(["-af", "loudnorm"])
            
        return params
    
    def validate_config(self) -> List[str]:
        """验证配置有效性"""
        errors = []
        
        # 验证权重总和
        params = self.matching_params
        total_weight = (params.semantic_weight + params.duration_weight + 
                       params.quality_weight + params.diversity_weight)
        
        if abs(total_weight - 1.0) > 0.01:
            errors.append(f"匹配权重总和应为1.0，当前为{total_weight:.3f}")
        
        # 验证阈值范围
        if not (0 <= params.min_match_score <= 1):
            errors.append("最低匹配分数应在0-1之间")
            
        if params.min_match_score >= params.preferred_score:
            errors.append("最低匹配分数应小于偏好分数")
            
        # 验证生成数量
        if self.generation_config.num_variations < 1:
            errors.append("生成变体数量至少为1")
            
        if self.generation_config.num_variations > 10:
            errors.append("生成变体数量不应超过10（性能考虑）")
        
        return errors
    
    def get_strategy_description(self) -> str:
        """获取策略描述"""
        descriptions = {
            MatchingStrategy.SEMANTIC_PRIORITY: "语义优先：重点匹配内容相关性",
            MatchingStrategy.DURATION_PRIORITY: "时长优先：重点匹配时间长度",
            MatchingStrategy.QUALITY_PRIORITY: "质量优先：重点选择高质量切片", 
            MatchingStrategy.BALANCED: "平衡模式：综合考虑多个因素",
            MatchingStrategy.RANDOM_WEIGHTED: "加权随机：在高质量候选中随机选择"
        }
        return descriptions.get(self.matching_strategy, "未知策略")

    @classmethod
    def create_preset(cls, preset_name: str) -> 'CompositionConfig':
        """创建预设配置"""
        if preset_name == "conservative":
            # 保守策略：高质量、低随机性
            return cls(
                matching_strategy=MatchingStrategy.QUALITY_PRIORITY,
                matching_params=MatchingParameters(
                    semantic_weight=0.3, duration_weight=0.4, 
                    quality_weight=0.3, diversity_weight=0.0,
                    min_match_score=0.5, randomness_factor=0.1
                ),
                generation_config=VideoGenerationConfig(num_variations=2)
            )
        elif preset_name == "creative":
            # 创意策略：高随机性、多样性
            return cls(
                matching_strategy=MatchingStrategy.RANDOM_WEIGHTED,
                matching_params=MatchingParameters(
                    semantic_weight=0.2, duration_weight=0.2,
                    quality_weight=0.2, diversity_weight=0.4,
                    min_match_score=0.3, randomness_factor=0.4
                ),
                generation_config=VideoGenerationConfig(num_variations=5)
            )
        elif preset_name == "fast":
            # 快速策略：性能优先
            return cls(
                matching_strategy=MatchingStrategy.DURATION_PRIORITY,
                generation_config=VideoGenerationConfig(
                    num_variations=1, video_quality=VideoQuality.MEDIUM,
                    parallel_workers=1
                )
            )
        else:
            # 默认平衡策略
            return cls()

    def to_dict(self) -> Dict:
        """转换为字典格式（用于保存配置）"""
        return {
            "matching_strategy": self.matching_strategy.value,
            "matching_params": {
                "semantic_weight": self.matching_params.semantic_weight,
                "duration_weight": self.matching_params.duration_weight,
                "quality_weight": self.matching_params.quality_weight,
                "diversity_weight": self.matching_params.diversity_weight,
                "min_match_score": self.matching_params.min_match_score,
                "randomness_factor": self.matching_params.randomness_factor
            },
            "generation_config": {
                "num_variations": self.generation_config.num_variations,
                "video_quality": self.generation_config.video_quality.value,
                "enable_ab_testing": self.generation_config.enable_ab_testing
            },
            "audio_video_settings": {
                "preserve_original_audio": self.preserve_original_audio,
                "remove_slice_audio": self.remove_slice_audio,
                "audio_normalization": self.audio_normalization
            }
        } 