#!/usr/bin/env python3
"""
🎬 视频合成器 - Video Composer
核心视频合成器：协调所有组件生成最终的合成视频
"""

import logging
import subprocess
import tempfile
import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime

from .composition_config import CompositionConfig, MatchingStrategy
from .segment_selector import SegmentSelector, SelectionResult
from .audio_video_matcher import AudioVideoMatcher
from ..material_engine.similarity_matcher import MatchCandidate
from ..srt_analyzer.timeline_parser import ModuleSegment

logger = logging.getLogger(__name__)

@dataclass
class CompositionResult:
    """视频合成结果"""
    success: bool
    output_video_path: str = ""
    composition_report: Dict = None
    processing_time: float = 0.0
    error_message: str = ""
    temp_files: List[str] = None
    
    def __post_init__(self):
        if self.temp_files is None:
            self.temp_files = []

@dataclass
class CompositionJob:
    """合成任务"""
    job_id: str
    ref_video_path: str
    module_candidates: Dict[str, List[MatchCandidate]]
    module_segments: List[ModuleSegment]
    output_dir: str
    config: CompositionConfig
    variation_index: int = 0

class VideoComposer:
    """视频合成器"""
    
    def __init__(self, config: CompositionConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # 初始化子组件
        self.segment_selector = SegmentSelector(config)
        self.audio_video_matcher = AudioVideoMatcher(config)
        
        self.temp_dirs: List[str] = []
        self.composition_stats = {
            'total_jobs': 0,
            'successful_jobs': 0,
            'failed_jobs': 0,
            'total_processing_time': 0.0
        }
    
    def compose_single_video(self, job: CompositionJob) -> CompositionResult:
        """
        合成单个视频
        
        Args:
            job: 合成任务
            
        Returns:
            合成结果
        """
        start_time = time.time()
        self.composition_stats['total_jobs'] += 1
        
        try:
            self.logger.info(f"🎬 开始视频合成 - 任务ID: {job.job_id}")
            self.logger.info(f"   参考视频: {Path(job.ref_video_path).name}")
            self.logger.info(f"   策略: {job.config.get_strategy_description()}")
            self.logger.info(f"   变体: {job.variation_index + 1}")
            
            # 1. 片段选择
            self.logger.info("📊 阶段1: 智能片段选择")
            selection_results = self.segment_selector.select_segments_for_composition(
                job.module_candidates, job.module_segments
            )
            
            if not selection_results:
                raise Exception("片段选择失败，没有合适的候选")
            
            # 2. 完整音频提取
            self.logger.info("🔊 阶段2: 提取参考视频完整音频")
            temp_dir = tempfile.mkdtemp(prefix=f"compose_{job.job_id}_")
            self.temp_dirs.append(temp_dir)
            
            reference_audio_path = self.audio_video_matcher.extract_complete_reference_audio(
                job.ref_video_path, temp_dir
            )
            
            if not reference_audio_path:
                raise Exception("参考音频提取失败")
            
            # 3. 时间轴视频准备 (消音+调速)
            self.logger.info("🎥 阶段3: 根据时间轴准备切片视频")
            video_mappings = self.audio_video_matcher.prepare_timeline_video_segments(
                selection_results, job.module_segments, job.module_candidates, temp_dir
            )
            
            if not video_mappings:
                raise Exception("时间轴视频准备失败")
            
            # 4. 创建合成方案
            self.logger.info("🔗 阶段4: 创建时间轴合成方案")
            composition_plan = self.audio_video_matcher.create_timeline_composition_plan(
                reference_audio_path, video_mappings
            )
            
            if not composition_plan:
                raise Exception("合成方案创建失败")
            
            # 5. 时间轴视频合成
            self.logger.info("⚙️ 阶段5: 时间轴视频合成")
            output_path = self._generate_output_path(job)
            
            composition_success = self._compose_timeline_video(composition_plan, output_path)
            
            if not composition_success:
                raise Exception("时间轴视频合成失败")
            
            # 6. 生成报告
            report = self._generate_composition_report(
                job, selection_results, composition_plan, output_path
            )
            
            processing_time = time.time() - start_time
            self.composition_stats['successful_jobs'] += 1
            self.composition_stats['total_processing_time'] += processing_time
            
            self.logger.info(f"✅ 视频合成成功: {output_path}")
            self.logger.info(f"⏱️ 处理时间: {processing_time:.1f}秒")
            
            return CompositionResult(
                success=True,
                output_video_path=output_path,
                composition_report=report,
                processing_time=processing_time,
                temp_files=[temp_dir]
            )
            
        except Exception as e:
            processing_time = time.time() - start_time
            self.composition_stats['failed_jobs'] += 1
            self.composition_stats['total_processing_time'] += processing_time
            
            error_msg = f"视频合成失败: {str(e)}"
            self.logger.error(error_msg)
            
            return CompositionResult(
                success=False,
                error_message=error_msg,
                processing_time=processing_time
            )
    
    def compose_multiple_variations(self, ref_video_path: str,
                                  module_candidates: Dict[str, List[MatchCandidate]],
                                  module_segments: List[ModuleSegment],
                                  output_dir: str) -> List[CompositionResult]:
        """
        生成多个合成变体
        
        Args:
            ref_video_path: 参考视频路径
            module_candidates: 模块候选切片
            module_segments: 模块时间轴
            output_dir: 输出目录
            
        Returns:
            合成结果列表
        """
        try:
            num_variations = self.config.generation_config.num_variations
            self.logger.info(f"🎲 开始生成 {num_variations} 个视频变体")
            
            # 为每个变体生成选择方案
            variations = self.segment_selector.generate_multiple_variations(
                module_candidates, module_segments, num_variations
            )
            
            # 并行或串行合成视频
            results = []
            
            if self.config.generation_config.parallel_workers > 1:
                # 并行合成 (简化版，实际可以用线程池)
                results = self._compose_variations_parallel(
                    ref_video_path, variations, module_segments, output_dir
                )
            else:
                # 串行合成
                results = self._compose_variations_sequential(
                    ref_video_path, variations, module_segments, output_dir
                )
            
            # 生成批次总结
            self._generate_batch_summary(results, output_dir)
            
            return results
            
        except Exception as e:
            self.logger.error(f"多变体合成失败: {e}")
            return []
    
    def _compose_variations_sequential(self, ref_video_path: str,
                                     variations: List[Dict[str, SelectionResult]],
                                     module_segments: List[ModuleSegment],
                                     output_dir: str) -> List[CompositionResult]:
        """串行合成变体"""
        results = []
        
        for i, selection_results in enumerate(variations):
            # 将SelectionResult转换为MatchCandidate字典
            module_candidates = {}
            for module_type, selection_result in selection_results.items():
                module_candidates[module_type] = [selection_result.selected_candidate]
            
            job = CompositionJob(
                job_id=f"variation_{i+1}",
                ref_video_path=ref_video_path,
                module_candidates=module_candidates,
                module_segments=module_segments,
                output_dir=output_dir,
                config=self.config,
                variation_index=i
            )
            
            result = self.compose_single_video(job)
            results.append(result)
            
            if result.success:
                self.logger.info(f"✅ 变体 {i+1} 合成成功")
            else:
                self.logger.error(f"❌ 变体 {i+1} 合成失败: {result.error_message}")
        
        return results
    
    def _compose_variations_parallel(self, ref_video_path: str,
                                   variations: List[Dict[str, SelectionResult]],
                                   module_segments: List[ModuleSegment],
                                   output_dir: str) -> List[CompositionResult]:
        """并行合成变体 (简化实现)"""
        # 这里可以实现真正的并行处理
        # 目前先用串行代替
        return self._compose_variations_sequential(ref_video_path, variations, module_segments, output_dir)
    
    def _compose_timeline_video(self, composition_plan: Dict, output_path: str) -> bool:
        """
        根据时间轴合成方案合成最终视频
        
        Args:
            composition_plan: 时间轴合成方案
            output_path: 输出视频路径
            
        Returns:
            是否合成成功
        """
        try:
            reference_audio = composition_plan['reference_audio']
            video_segments = composition_plan['video_segments']
            timeline_info = composition_plan['timeline_info']
            
            self.logger.info(f"🎬 开始合成时间轴视频:")
            self.logger.info(f"   📊 视频片段: {len(video_segments)} 个")
            self.logger.info(f"   ⏱️ 总时长: {timeline_info['total_duration']:.1f}s")
            self.logger.info(f"   📈 覆盖率: {timeline_info['coverage_rate']:.1%}")
            
            if not video_segments:
                self.logger.error("没有视频片段可供合成")
                return False
            
            # 1. 按时间轴顺序排序视频片段
            sorted_segments = sorted(video_segments, key=lambda x: x['start_time'])
            
            # 2. 构建FFmpeg命令
            cmd = ["ffmpeg", "-y"]
            
            # 添加参考音频作为输入
            cmd.extend(["-i", reference_audio])
            
            # 添加所有视频片段作为输入
            for i, segment in enumerate(sorted_segments):
                cmd.extend(["-i", segment['video_file']])
                self.logger.info(f"   📹 片段{i+1}: {segment['module_type']} ({segment['start_time']:.1f}s-{segment['end_time']:.1f}s)")
            
            # 3. 构建filter_complex滤镜
            video_count = len(sorted_segments)
            
            # 视频拼接滤镜
            video_filter = ""
            for i in range(video_count):
                video_filter += f"[{i+1}:v]"
            video_filter += f"concat=n={video_count}:v=1:a=0[outv]"
            
            cmd.extend([
                "-filter_complex", video_filter,
                "-map", "[outv]",  # 使用拼接的视频
                "-map", "0:a",     # 使用参考音频
                "-c:v", "libx264", # 视频编码
                "-preset", "medium",
                "-crf", "23",
                "-c:a", "aac",     # 音频编码
                "-b:a", "128k",
                output_path
            ])
            
            self.logger.info("🔧 执行FFmpeg合成命令...")
            
            # 4. 执行FFmpeg命令
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=300
            )
            
            if result.returncode == 0:
                # 验证输出文件
                output_file = Path(output_path)
                if output_file.exists() and output_file.stat().st_size > 0:
                    
                    # 验证输出视频信息
                    output_info = self.audio_video_matcher.get_video_info(output_path)
                    if output_info and 'format' in output_info:
                        actual_duration = float(output_info['format'].get('duration', 0))
                        expected_duration = timeline_info['total_duration']
                        duration_diff = abs(actual_duration - expected_duration)
                        
                        self.logger.info(f"✅ 时间轴视频合成成功!")
                        self.logger.info(f"   📁 输出文件: {output_file.name}")
                        self.logger.info(f"   ⏱️ 实际时长: {actual_duration:.1f}s (预期: {expected_duration:.1f}s)")
                        self.logger.info(f"   📏 时长偏差: {duration_diff:.1f}s")
                        
                        if duration_diff > 1.0:
                            self.logger.warning(f"⚠️ 时长偏差较大，可能存在同步问题")
                        
                        return True
                    
                    return True
            
            self.logger.error(f"❌ FFmpeg合成失败:")
            self.logger.error(f"   返回码: {result.returncode}")
            self.logger.error(f"   错误信息: {result.stderr}")
            return False
            
        except Exception as e:
            self.logger.error(f"时间轴视频合成异常: {e}")
            return False
    

    
    def _generate_output_path(self, job: CompositionJob) -> str:
        """生成输出文件路径"""
        # 从参考视频路径提取视频名
        ref_name = Path(job.ref_video_path).stem
        
        # 应用命名模式
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        strategy = job.config.matching_strategy.value
        
        filename = job.config.output_naming_pattern.format(
            video_name=ref_name,
            version=job.variation_index + 1,
            strategy=strategy,
            timestamp=timestamp
        )
        
        output_dir = Path(job.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        return str(output_dir / f"{filename}.{job.config.generation_config.output_format}")
    
    def _generate_composition_report(self, job: CompositionJob,
                                   selection_results: Dict[str, SelectionResult],
                                   composition_plan: Dict,
                                   output_path: str) -> Dict:
        """生成合成报告"""
        try:
            # 从composition_plan提取信息
            timeline_info = composition_plan.get('timeline_info', {})
            video_segments = composition_plan.get('video_segments', [])
            composition_quality = composition_plan.get('composition_quality', {})
            
            # 计算统计信息
            total_modules = len(job.module_segments)
            successful_selections = len(selection_results)
            successful_compositions = len(video_segments)
            
            # 质量统计
            avg_selection_score = sum(r.selection_score for r in selection_results.values()) / len(selection_results) if selection_results else 0
            overall_composition_quality = composition_quality.get('overall_score', 0)
            
            # 视频源分布
            video_sources = {}
            for result in selection_results.values():
                video_name = result.selected_candidate.slice_info.video_name
                video_sources[video_name] = video_sources.get(video_name, 0) + 1
            
            # 调速统计
            speed_adjustments = sum(1 for segment in video_segments if abs(segment.get('scaling_factor', 1.0) - 1.0) > 0.1)
            
            report = {
                'composition_info': {
                    'job_id': job.job_id,
                    'ref_video': Path(job.ref_video_path).name,
                    'strategy': job.config.matching_strategy.value,
                    'variation_index': job.variation_index,
                    'output_path': output_path,
                    'created_at': datetime.now().isoformat()
                },
                'statistics': {
                    'total_modules': total_modules,
                    'successful_selections': successful_selections,
                    'successful_compositions': successful_compositions,
                    'selection_success_rate': successful_selections / total_modules if total_modules > 0 else 0,
                    'composition_success_rate': successful_compositions / total_modules if total_modules > 0 else 0,
                    'avg_selection_score': avg_selection_score,
                    'overall_composition_quality': overall_composition_quality,
                    'speed_adjustments': speed_adjustments
                },
                'timeline_quality': {
                    'total_duration': timeline_info.get('total_duration', 0),
                    'coverage_rate': timeline_info.get('coverage_rate', 0),
                    'timeline_gaps': len(timeline_info.get('timeline_gaps', [])),
                    'quality_level': composition_quality.get('quality_level', '未知'),
                    'issues': composition_quality.get('issues', []),
                    'recommendations': composition_quality.get('recommendations', [])
                },
                'video_sources': video_sources,
                'module_details': [
                    {
                        'module_type': module_type,
                        'video_source': result.selected_candidate.slice_info.video_name,
                        'slice_name': result.selected_candidate.slice_info.slice_name,
                        'selection_score': result.selection_score,
                        'selection_reason': result.selection_reason,
                        'original_duration': result.selected_candidate.slice_info.duration,
                        'target_duration': next(
                            (m.duration for m in job.module_segments if m.module_type == module_type), 0
                        ),
                        'scaling_factor': next(
                            (s.get('scaling_factor', 1.0) for s in video_segments if s.get('module_type') == module_type), 1.0
                        )
                    }
                    for module_type, result in selection_results.items()
                ],
                'config_snapshot': job.config.to_dict()
            }
            
            return report
            
        except Exception as e:
            self.logger.error(f"生成合成报告失败: {e}")
            return {}
    
    def _generate_batch_summary(self, results: List[CompositionResult], output_dir: str):
        """生成批次总结"""
        try:
            successful = [r for r in results if r.success]
            failed = [r for r in results if not r.success]
            
            summary = {
                'batch_info': {
                    'total_variations': len(results),
                    'successful_count': len(successful),
                    'failed_count': len(failed),
                    'success_rate': len(successful) / len(results) if results else 0,
                    'created_at': datetime.now().isoformat()
                },
                'performance': {
                    'total_processing_time': sum(r.processing_time for r in results),
                    'avg_processing_time': sum(r.processing_time for r in results) / len(results),
                    'fastest_composition': min(r.processing_time for r in successful) if successful else 0,
                    'slowest_composition': max(r.processing_time for r in successful) if successful else 0
                },
                'successful_videos': [
                    {
                        'output_path': r.output_video_path,
                        'processing_time': r.processing_time,
                        'report_summary': r.composition_report.get('statistics', {}) if r.composition_report else {}
                    }
                    for r in successful
                ],
                'failed_videos': [
                    {
                        'error_message': r.error_message,
                        'processing_time': r.processing_time
                    }
                    for r in failed
                ]
            }
            
            # 保存总结报告
            summary_file = Path(output_dir) / f"batch_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(summary_file, 'w', encoding='utf-8') as f:
                json.dump(summary, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"📊 批次总结已保存: {summary_file}")
            
        except Exception as e:
            self.logger.error(f"生成批次总结失败: {e}")
    
    def cleanup_all_temp_files(self):
        """清理所有临时文件"""
        self.logger.info("🗑️ 清理所有临时文件")
        
        # 清理临时目录
        for temp_dir in self.temp_dirs:
            try:
                import shutil
                shutil.rmtree(temp_dir, ignore_errors=True)
            except Exception as e:
                self.logger.warning(f"清理临时目录失败 {temp_dir}: {e}")
        
        # 清理音视频匹配器的临时文件
        self.audio_video_matcher.cleanup_temp_files()
        
        self.temp_dirs.clear()
    
    def get_composition_stats(self) -> Dict:
        """获取合成统计信息"""
        return {
            **self.composition_stats,
            'avg_processing_time': (
                self.composition_stats['total_processing_time'] / 
                self.composition_stats['total_jobs'] 
                if self.composition_stats['total_jobs'] > 0 else 0
            )
        }
    
    def __del__(self):
        """析构函数：自动清理临时文件"""
        if self.config.generation_config.temp_cleanup:
            self.cleanup_all_temp_files() 