#!/usr/bin/env python3
"""
🎬 Script Studio V2.0 - 快速启动脚本
人机协作的智能视频脚本生成系统 (Claude 4)
"""

import sys
import subprocess
from pathlib import Path

# 导入ScriptStudioV2以便扫描ref目录
sys.path.append(str(Path(__file__).parent))
from main import ScriptStudioV2

def main():
    """快速启动入口"""
    print("🎬 Script Studio V2.0 - 智能视频脚本生成系统 (Claude 4)")
    print("=" * 60)
    
    if len(sys.argv) == 1:
        show_quick_menu()
    else:
        # 直接传递参数到main.py
        cmd = [sys.executable, "main.py"] + sys.argv[1:]
        subprocess.run(cmd)

def scan_and_show_ref_videos():
    """扫描并显示ref目录中的视频选项"""
    try:
        # 初始化ScriptStudio来扫描ref目录
        studio = ScriptStudioV2()
        ref_files = studio.scan_ref_directory()
        
        if not ref_files:
            print("❌ ref目录中没有找到完整的参考文件对（视频+字幕）")
            print("📁 请确保ref目录下有.mp4/.avi/.mov/.mkv视频文件和对应的.srt字幕文件")
            return None
        
        print(f"\n📂 找到 {len(ref_files)} 个可用的参考视频:")
        print("-" * 60)
        
        for i, ref_file in enumerate(ref_files, 1):
            video_size_mb = ref_file['video_size'] / (1024 * 1024)
            srt_lines = ref_file['srt_lines']
            print(f"{i}. {ref_file['video_name']}")
            print(f"   📹 视频: {video_size_mb:.1f}MB | 📄 字幕: {srt_lines}行")
            print()
        
        while True:
            try:
                choice = input(f"请选择视频编号 (1-{len(ref_files)}) 或输入 0 返回主菜单: ").strip()
                
                if choice == "0":
                    return None
                
                video_index = int(choice) - 1
                if 0 <= video_index < len(ref_files):
                    selected_video = ref_files[video_index]
                    print(f"\n✅ 已选择: {selected_video['video_name']}")
                    return selected_video['video_name']
                else:
                    print(f"❌ 请输入 1-{len(ref_files)} 之间的数字")
                    
            except ValueError:
                print("❌ 请输入有效的数字")
                
    except Exception as e:
        print(f"❌ 扫描ref目录失败: {e}")
        return None

def handle_video_composition():
    """处理视频合成选项"""
    print("\n🎬 视频合成生成")
    print("=" * 40)
    print("📖 功能说明：")
    print("   • 保留参考视频的原始音频")
    print("   • 根据时间轴智能匹配切片画面")
    print("   • 自动消音处理切片视频")
    print("   • 生成多个变体供选择")
    print()
    
    # 1. 选择参考视频
    video_name = scan_and_show_ref_videos()
    if not video_name:
        return
    
    # 2. 选择合成策略
    print("\n🎯 选择合成策略:")
    print("1. balanced - 平衡模式（推荐）")
    print("2. quality - 质量优先")
    print("3. creative - 创意模式（高随机性）")
    print("4. fast - 快速模式")
    
    strategy_map = {"1": "balanced", "2": "quality", "3": "creative", "4": "fast"}
    
    while True:
        strategy_choice = input("请选择策略 (1-4, 默认1): ").strip() or "1"
        if strategy_choice in strategy_map:
            strategy = strategy_map[strategy_choice]
            break
        print("❌ 请输入 1-4")
    
    # 3. 选择变体数量
    while True:
        try:
            num_variations = input("请输入生成变体数量 (1-5, 默认3): ").strip() or "3"
            num_variations = int(num_variations)
            if 1 <= num_variations <= 5:
                break
            print("❌ 请输入 1-5 之间的数字")
        except ValueError:
            print("❌ 请输入有效的数字")
    
    # 4. 确认并执行
    print(f"\n📋 合成配置确认:")
    print(f"   📹 参考视频: {video_name}")
    print(f"   🎯 合成策略: {strategy}")
    print(f"   🎲 变体数量: {num_variations}")
    
    confirm = input("\n确认开始合成？(y/N): ").strip().lower()
    if confirm in ['y', 'yes']:
        print("\n🚀 开始视频合成...")
        print("⚠️  注意：此功能需要先通过Method 1或2生成候选切片")
        print("💡 建议：先运行Method 1生成候选，然后基于结果进行视频合成")
        
        # 这里可以扩展为实际调用method3的代码
        # 目前先显示提示信息
        print("\n🔧 功能开发中...")
        print("📝 当前需要手动调用：")
        print(f"   python main.py --method 3 --video {video_name} --strategy {strategy} --variations {num_variations}")
    else:
        print("❌ 已取消")

def show_quick_menu():
    """显示快速菜单"""
    print("\n🚀 快速选项:")
    print("1. 字幕映射生成（多候选模式）")
    print("2. 创意脚本生成（智能聚类）")
    print("3. 视频合成生成（保留音频+智能匹配画面）")
    print("4. 查看帮助")
    print("5. 退出")
    
    while True:
        choice = input("\n请选择 (1-5): ").strip()
        
        if choice == "1":
            # 扫描并选择ref视频
            video_name = scan_and_show_ref_videos()
            if video_name:
                print("🚀 使用Claude 4分析器进行字幕映射...")
                cmd = [sys.executable, "main.py", "--method", "1", "--video", video_name, 
                       "--multi-candidates", "--threshold", "0.3", "--max-candidates", "15"]
                subprocess.run(cmd)
            break
        elif choice == "2":
            product = input("请输入产品名称 (如: 启赋蕴淳): ").strip()
            goal = input("请输入营销目标 (转化/认知/品牌): ").strip()
            if product and goal:
                print("🚀 使用Claude 4分析器进行创意脚本生成...")
                cmd = [sys.executable, "main.py", "--method", "2", "--product", product, 
                       "--goal", goal, "--clustering", "--threshold", "0.4"]
                subprocess.run(cmd)
            break
        elif choice == "3":
            handle_video_composition()
            break
        elif choice == "4":
            subprocess.run([sys.executable, "main.py", "--help"])
            break
        elif choice == "5":
            print("👋 再见！")
            break
        else:
            print("❌ 无效选择，请输入 1-5")

if __name__ == "__main__":
    main() 