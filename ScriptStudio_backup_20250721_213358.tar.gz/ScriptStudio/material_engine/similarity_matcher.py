#!/usr/bin/env python3
"""
相似度匹配器 - Similarity Matcher
实现切片素材的智能匹配算法，基于多维度相似度计算
支持多候选切片选择和人工筛选辅助
"""

import logging
import json
import math
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass
from datetime import datetime
import re

from .slice_scanner import SliceInfo, ScanResult
from srt_analyzer.semantic_matcher import SemanticMatcher, MatchResult

logger = logging.getLogger(__name__)

@dataclass
class MatchCandidate:
    """匹配候选数据结构"""
    slice_info: SliceInfo      # 切片信息
    match_score: float         # 匹配得分 (0.0-1.0)
    match_details: Dict        # 匹配详情
    semantic_result: MatchResult  # 语义匹配结果
    duration_fitness: float    # 时长适配度
    quality_score: float       # 质量评分
    confidence_level: str      # 置信度等级 (高/中/低)
    human_readable_score: str  # 人工判断辅助信息

@dataclass
class MatchRequest:
    """匹配请求数据结构"""
    module_type: str          # 模块类型
    target_duration: float    # 目标时长
    subtitle_content: str     # 字幕内容
    required_tags: Dict       # 必需标签
    preferred_tags: Dict      # 偏好标签
    brand_elements: List[str] # 品牌元素
    emotion_preference: str   # 情绪偏好
    quality_threshold: float  # 质量阈值 (降低默认值)
    max_candidates: int       # 最大候选数量
    include_all_above_threshold: bool  # 是否包含所有超过阈值的候选

class SimilarityMatcher:
    """相似度匹配器"""
    
    # 模块特征权重配置
    MODULE_WEIGHTS = {
        '🪝钩子': {
            'main_tag': 0.35,      # 主标签权重最高
            'emotion': 0.25,       
            'semantic': 0.20,
            'brand': 0.10,
            'duration': 0.08,
            'quality': 0.02
        },
        '🍼产品介绍': {
            'main_tag': 0.30,      # 主标签权重很高
            'brand': 0.30,         # 品牌也很重要
            'semantic': 0.20,
            'emotion': 0.10,
            'duration': 0.08,
            'quality': 0.02
        },
        '🌟使用效果': {
            'main_tag': 0.35,      # 主标签权重最高
            'semantic': 0.25,
            'emotion': 0.20,
            'brand': 0.10,
            'duration': 0.08,
            'quality': 0.02
        },
        '🎁促销机制': {
            'main_tag': 0.35,      # 主标签权重最高
            'semantic': 0.25,
            'emotion': 0.20,
            'brand': 0.10,
            'duration': 0.08,
            'quality': 0.02
        }
    }
    
    # 主标签匹配映射
    MAIN_TAG_MAPPINGS = {
        '🪝钩子': ['🪝 钩子', '钩子'],
        '🍼产品介绍': ['🍼 产品介绍', '产品介绍'],
        '🌟使用效果': ['🌟 使用效果', '使用效果'],
        '🎁促销机制': ['🎁 促销机制', '促销机制']
    }
    
    # 情绪相似度矩阵
    EMOTION_SIMILARITY = {
        ('好奇', '疑问'): 0.9,
        ('好奇', '惊讶'): 0.8,
        ('温馨', '关爱'): 0.9,
        ('温馨', '幸福'): 0.8,
        ('专业', '严肃'): 0.9,
        ('专业', '可信'): 0.8,
        ('开心', '满意'): 0.9,
        ('开心', '愉快'): 0.8,
        ('关爱', '保护'): 0.9,
        ('惊讶', '意外'): 0.8
    }
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.semantic_matcher = SemanticMatcher()
        
        # 降低匹配严格度的参数配置
        self.FLEXIBLE_MATCHING_CONFIG = {
            'semantic_weight': 0.3,      # 降低语义匹配权重
            'duration_weight': 0.2,      # 降低时长匹配权重
            'emotion_weight': 0.2,       # 降低情绪匹配权重
            'quality_weight': 0.2,       # 降低质量匹配权重
            'brand_weight': 0.1,         # 降低品牌匹配权重
            'duration_tolerance': 3.0,   # 增加时长容忍度
            'min_semantic_score': 0.2,   # 降低最低语义分数
            'flexible_emotion_match': True  # 启用灵活情绪匹配
        }
        
        # 情绪相似度映射（更宽松）
        self.EMOTION_SIMILARITY = {
            ('温馨', '开心'): 0.8,
            ('专业', '温馨'): 0.7,
            ('好奇', '开心'): 0.8,
            ('惊喜', '开心'): 0.9,
            ('安心', '温馨'): 0.9,
            ('专业', '好奇'): 0.6,
            ('温馨', '安心'): 0.9,
            ('开心', '惊喜'): 0.8,
            # 添加更多宽松的情绪匹配
            ('专业', '开心'): 0.5,
            ('好奇', '温馨'): 0.6,
            ('惊喜', '温馨'): 0.7,
            ('安心', '开心'): 0.7
        }
        
        # 置信度等级映射
        self.CONFIDENCE_LEVELS = {
            (0.8, 1.0): "高置信度",
            (0.6, 0.8): "中等置信度", 
            (0.4, 0.6): "低置信度",
            (0.0, 0.4): "需人工验证"
        }
    
    def find_best_matches(self, scan_result: ScanResult, match_request: MatchRequest,
                         max_results: int = 10) -> List[MatchCandidate]:
        """
        寻找最佳匹配的切片
        
        Args:
            scan_result: 扫描结果
            match_request: 匹配请求
            max_results: 最大返回结果数
            
        Returns:
            匹配候选列表，按得分排序
        """
        try:
            self.logger.info(f"开始匹配 {match_request.module_type} 模块")
            self.logger.info(f"  目标时长: {match_request.target_duration:.1f}秒")
            self.logger.info(f"  字幕内容: {match_request.subtitle_content[:50]}...")
            
            candidates = []
            
            # 预过滤：基本条件筛选
            filtered_slices = self._pre_filter_slices(scan_result, match_request)
            self.logger.info(f"  预过滤后剩余: {len(filtered_slices)} 个切片")
            
            # 逐个计算匹配得分
            for slice_info in filtered_slices:
                candidate = self._calculate_match_score(slice_info, match_request)
                if candidate and candidate.match_score >= match_request.quality_threshold:
                    candidates.append(candidate)
            
            # 按得分排序
            candidates.sort(key=lambda x: x.match_score, reverse=True)
            
            # 限制返回数量
            best_matches = candidates[:max_results]
            
            self.logger.info(f"找到 {len(best_matches)} 个高质量匹配")
            if best_matches:
                self.logger.info(f"  最佳匹配得分: {best_matches[0].match_score:.3f}")
                self.logger.info(f"  最低匹配得分: {best_matches[-1].match_score:.3f}")
            
            return best_matches
            
        except Exception as e:
            self.logger.error(f"匹配失败: {e}")
            return []
    
    def find_candidate_slices(self, scan_result: ScanResult, match_request: MatchRequest) -> List[MatchCandidate]:
        """
        找到所有符合条件的候选切片（支持多候选模式）
        
        Args:
            scan_result: 扫描结果
            match_request: 匹配请求
            
        Returns:
            所有符合阈值的匹配候选列表，按得分排序
        """
        try:
            self.logger.info(f"🔍 开始多候选切片匹配 - {match_request.module_type}")
            self.logger.info(f"  阈值设置: {match_request.quality_threshold}")
            self.logger.info(f"  最大候选数: {match_request.max_candidates}")
            self.logger.info(f"  包含所有超阈值: {match_request.include_all_above_threshold}")
            
            candidates = []
            
            # 预过滤：基本条件筛选（更宽松）
            filtered_slices = self._flexible_pre_filter(scan_result, match_request)
            self.logger.info(f"  灵活预过滤后: {len(filtered_slices)} 个切片")
            
            # 逐个计算匹配得分
            for slice_info in filtered_slices:
                candidate = self._calculate_flexible_match_score(slice_info, match_request)
                if candidate:
                    # 添加人工判断辅助信息
                    candidate.human_readable_score = self._generate_human_readable_score(candidate)
                    candidate.confidence_level = self._determine_confidence_level(candidate.match_score)
                    
                    # 根据策略决定是否包含
                    if match_request.include_all_above_threshold:
                        # 包含所有超过阈值的候选
                        if candidate.match_score >= match_request.quality_threshold:
                            candidates.append(candidate)
                    else:
                        # 传统方式：只包含高质量候选
                        if candidate.match_score >= match_request.quality_threshold:
                            candidates.append(candidate)
            
            # 按得分排序
            candidates.sort(key=lambda x: x.match_score, reverse=True)
            
            # 限制候选数量
            if match_request.max_candidates > 0:
                candidates = candidates[:match_request.max_candidates]
            
            self.logger.info(f"✅ 找到 {len(candidates)} 个候选切片")
            if candidates:
                self.logger.info(f"  得分范围: {candidates[0].match_score:.3f} - {candidates[-1].match_score:.3f}")
                self.logger.info(f"  置信度分布: {self._analyze_confidence_distribution(candidates)}")
            
            return candidates
            
        except Exception as e:
            self.logger.error(f"候选切片匹配失败: {e}")
            return []
    
    def _pre_filter_slices(self, scan_result: ScanResult, match_request: MatchRequest) -> List[SliceInfo]:
        """预过滤切片"""
        filtered = []
        
        for slice_info in scan_result.slice_infos:
            # 基本质量检查
            if slice_info.confidence < 0.3:
                continue
            
            # 时长范围检查（允许一定弹性）
            duration_ratio = slice_info.duration / match_request.target_duration
            if duration_ratio < 0.2 or duration_ratio > 5.0:
                continue
            
            # 必需标签检查
            if match_request.required_tags:
                if not self._check_required_tags(slice_info, match_request.required_tags):
                    continue
            
            # 品牌元素检查
            if match_request.brand_elements:
                if not self._check_brand_elements(slice_info, match_request.brand_elements):
                    continue
            
            filtered.append(slice_info)
        
        return filtered
    
    def _flexible_pre_filter(self, scan_result: ScanResult, match_request: MatchRequest) -> List[SliceInfo]:
        """灵活预过滤切片（降低严格度）"""
        filtered = []
        
        for slice_info in scan_result.slice_infos:
            # 降低质量检查标准
            if slice_info.confidence < 0.1:  # 从0.3降低到0.1
                continue
            
            # 放宽时长范围检查
            duration_ratio = slice_info.duration / match_request.target_duration
            if duration_ratio < 0.1 or duration_ratio > 10.0:  # 从0.2-5.0放宽到0.1-10.0
                continue
            
            # 可选标签检查（不是必需的）
            if match_request.required_tags:
                if not self._flexible_check_tags(slice_info, match_request.required_tags):
                    continue
            
            # 灵活品牌元素检查
            if match_request.brand_elements:
                if not self._flexible_check_brand_elements(slice_info, match_request.brand_elements):
                    continue
            
            filtered.append(slice_info)
        
        return filtered
    
    def _calculate_match_score(self, slice_info: SliceInfo, match_request: MatchRequest) -> Optional[MatchCandidate]:
        """计算匹配得分"""
        try:
            # 1. 语义匹配
            semantic_result = self.semantic_matcher.match_content_with_subtitle(
                slice_info.tags, match_request.subtitle_content, match_request.module_type
            )
            
            # 2. 主标签匹配 (新增!)
            main_tag_score = self._calculate_main_tag_match(slice_info, match_request)
            
            # 3. 情绪匹配
            emotion_score = self._calculate_emotion_match(slice_info, match_request)
            
            # 4. 品牌匹配
            brand_score = self._calculate_brand_match(slice_info, match_request)
            
            # 5. 时长适配度
            duration_fitness = self._calculate_duration_fitness(slice_info, match_request)
            
            # 6. 质量评分
            quality_score = self._calculate_quality_score(slice_info)
            
            # 7. 综合得分计算 (更新权重配置)
            weights = self.MODULE_WEIGHTS.get(match_request.module_type, {
                'semantic': 0.25, 'main_tag': 0.25, 'emotion': 0.15, 'brand': 0.15, 'duration': 0.15, 'quality': 0.05
            })
            
            final_score = (
                semantic_result.final_score * weights.get('semantic', 0.25) +
                main_tag_score * weights.get('main_tag', 0.25) +
                emotion_score * weights.get('emotion', 0.15) +
                brand_score * weights.get('brand', 0.15) +
                duration_fitness * weights.get('duration', 0.15) +
                quality_score * weights.get('quality', 0.05)
            )
            
            # 8. 生成匹配详情
            match_details = {
                'semantic_score': semantic_result.final_score,
                'main_tag_score': main_tag_score,
                'emotion_score': emotion_score,
                'brand_score': brand_score,
                'duration_fitness': duration_fitness,
                'quality_score': quality_score,
                'weight_distribution': weights,
                'slice_tags': slice_info.tags,
                'slice_main_tag': slice_info.tags.get('main_tag', ''),
                'target_module': match_request.module_type,
                'duration_ratio': slice_info.duration / match_request.target_duration
            }
            
            return MatchCandidate(
                slice_info=slice_info,
                match_score=final_score,
                match_details=match_details,
                semantic_result=semantic_result,
                duration_fitness=duration_fitness,
                quality_score=quality_score,
                confidence_level="",  # 稍后填充
                human_readable_score=""  # 稍后填充
            )
            
        except Exception as e:
            self.logger.warning(f"计算匹配得分失败 {slice_info.slice_name}: {e}")
            return None
    
    def _calculate_flexible_match_score(self, slice_info: SliceInfo, match_request: MatchRequest) -> Optional[MatchCandidate]:
        """计算灵活匹配得分"""
        try:
            config = self.FLEXIBLE_MATCHING_CONFIG
            
            # 1. 语义匹配得分（权重降低）
            semantic_result = self.semantic_matcher.match_content_with_subtitle(
                slice_info.tags, match_request.subtitle_content
            )
            semantic_score = max(semantic_result.final_score, config['min_semantic_score'])
            
            # 2. 主标签匹配得分 (新增!)
            main_tag_score = self._calculate_main_tag_match(slice_info, match_request)
            
            # 3. 时长适配度（更宽松）
            duration_fitness = self._calculate_flexible_duration_fitness(
                slice_info.duration, match_request.target_duration
            )
            
            # 4. 情绪匹配得分（灵活匹配）
            emotion_score = self._calculate_flexible_emotion_match(slice_info, match_request)
            
            # 5. 质量得分
            quality_score = self._calculate_quality_score(slice_info)
            
            # 6. 品牌匹配得分
            brand_score = self._calculate_flexible_brand_match(slice_info, match_request)
            
            # 7. 灵活权重配置（更重视主标签）
            flexible_weights = {
                'main_tag': 0.35,       # 主标签权重最高
                'semantic': 0.20,       # 语义权重适中
                'duration': 0.15,       # 时长权重降低
                'emotion': 0.15,        # 情绪权重降低
                'brand': 0.10,          # 品牌权重降低
                'quality': 0.05         # 质量权重最低
            }
            
            # 8. 综合得分计算
            final_score = (
                main_tag_score * flexible_weights['main_tag'] +
                semantic_score * flexible_weights['semantic'] +
                duration_fitness * flexible_weights['duration'] +
                emotion_score * flexible_weights['emotion'] +
                brand_score * flexible_weights['brand'] +
                quality_score * flexible_weights['quality']
            )
            
            # 9. 生成匹配详情
            match_details = {
                'main_tag_score': main_tag_score,
                'semantic_score': semantic_score,
                'duration_fitness': duration_fitness,
                'emotion_score': emotion_score,
                'brand_score': brand_score,
                'quality_score': quality_score,
                'weight_distribution': flexible_weights,
                'slice_main_tag': slice_info.tags.get('main_tag', ''),
                'target_module': match_request.module_type,
                'duration_ratio': slice_info.duration / match_request.target_duration,
                'matching_mode': 'flexible'
            }
            
            return MatchCandidate(
                slice_info=slice_info,
                match_score=final_score,
                match_details=match_details,
                semantic_result=semantic_result,
                duration_fitness=duration_fitness,
                quality_score=quality_score,
                confidence_level="",
                human_readable_score=""
            )
            
        except Exception as e:
            self.logger.warning(f"灵活匹配计算失败 {slice_info.slice_name}: {e}")
            return None
    
    def _calculate_emotion_match(self, slice_info: SliceInfo, match_request: MatchRequest) -> float:
        """计算情绪匹配得分"""
        slice_emotion = slice_info.tags.get('emotion', '')
        target_emotion = match_request.emotion_preference
        
        if not slice_emotion:
            return 0.5  # 无情绪标签时的默认得分
        
        if not target_emotion:
            return 0.7  # 无目标情绪时的默认得分
        
        # 完全匹配
        if slice_emotion == target_emotion:
            return 1.0
        
        # 相似情绪匹配
        for (emotion1, emotion2), similarity in self.EMOTION_SIMILARITY.items():
            if (slice_emotion, target_emotion) == (emotion1, emotion2) or \
               (slice_emotion, target_emotion) == (emotion2, emotion1):
                return similarity
        
        # 情绪类别匹配
        category_score = self._calculate_emotion_category_match(slice_emotion, target_emotion)
        
        return category_score
    
    def _calculate_flexible_emotion_match(self, slice_info: SliceInfo, match_request: MatchRequest) -> float:
        """计算灵活情绪匹配得分"""
        slice_emotion = slice_info.tags.get('emotion', '')
        target_emotion = match_request.emotion_preference
        
        if not slice_emotion or not target_emotion:
            return 0.6  # 提高默认得分
        
        # 完全匹配
        if slice_emotion == target_emotion:
            return 1.0
        
        # 相似情绪匹配
        for (emotion1, emotion2), similarity in self.EMOTION_SIMILARITY.items():
            if (slice_emotion, target_emotion) == (emotion1, emotion2) or \
               (slice_emotion, target_emotion) == (emotion2, emotion1):
                return similarity
        
        # 灵活匹配：任何积极情绪都可以互相匹配
        positive_emotions = ['开心', '温馨', '惊喜', '安心']
        if slice_emotion in positive_emotions and target_emotion in positive_emotions:
            return 0.5
        
        return 0.3  # 最低得分
    
    def _calculate_emotion_category_match(self, slice_emotion: str, target_emotion: str) -> float:
        """计算情绪类别匹配"""
        # 情绪类别定义
        emotion_categories = {
            'positive': ['开心', '满意', '温馨', '幸福', '愉快'],
            'curious': ['好奇', '疑问', '惊讶', '意外'],
            'professional': ['专业', '严肃', '可信', '权威'],
            'caring': ['关爱', '保护', '温暖', '呵护']
        }
        
        slice_category = None
        target_category = None
        
        # 查找情绪类别
        for category, emotions in emotion_categories.items():
            if slice_emotion in emotions:
                slice_category = category
            if target_emotion in emotions:
                target_category = category
        
        # 同类别情绪
        if slice_category and target_category and slice_category == target_category:
            return 0.7
        
        # 相关类别情绪
        related_categories = {
            'positive': ['caring'],
            'curious': ['professional'],
            'professional': ['caring'],
            'caring': ['positive']
        }
        
        if slice_category and target_category:
            if target_category in related_categories.get(slice_category, []):
                return 0.4
        
        return 0.2  # 不相关情绪
    
    def _calculate_brand_match(self, slice_info: SliceInfo, match_request: MatchRequest) -> float:
        """计算品牌匹配得分"""
        slice_brand = slice_info.tags.get('brand_elements', '')
        target_brands = match_request.brand_elements
        
        if not target_brands:
            return 1.0  # 无品牌要求时满分
        
        if not slice_brand:
            return 0.3  # 无品牌元素时的基础分
        
        # 计算品牌匹配率
        matched_count = 0
        for brand in target_brands:
            if brand in slice_brand:
                matched_count += 1
        
        if matched_count == 0:
            return 0.3
        
        match_rate = matched_count / len(target_brands)
        
        # 考虑品牌重要性
        important_brands = ['启赋', 'HMO', 'A2']
        importance_bonus = 0.0
        
        for brand in target_brands:
            if brand in important_brands and brand in slice_brand:
                importance_bonus += 0.2
        
        final_score = min(match_rate + importance_bonus, 1.0)
        return final_score
    
    def _calculate_flexible_brand_match(self, slice_info: SliceInfo, match_request: MatchRequest) -> float:
        """计算灵活品牌匹配得分"""
        if not match_request.brand_elements:
            return 0.8  # 无品牌要求时给高分
        
        slice_brand = slice_info.tags.get('brand_elements', '').lower()
        if not slice_brand:
            return 0.7  # 无品牌信息时给中等分
        
        match_count = 0
        for brand in match_request.brand_elements:
            if brand.lower() in slice_brand:
                match_count += 1
        
        # 灵活品牌匹配得分
        if match_count == 0:
            return 0.5  # 无匹配但不完全排除
        elif match_count == 1:
            return 0.8
        else:
            return 1.0
    
    def _calculate_duration_fitness(self, slice_info: SliceInfo, match_request: MatchRequest) -> float:
        """计算时长适配度"""
        slice_duration = slice_info.duration
        target_duration = match_request.target_duration
        
        if target_duration <= 0:
            return 1.0
        
        duration_ratio = slice_duration / target_duration
        
        # 理想范围：0.8-1.2倍
        if 0.8 <= duration_ratio <= 1.2:
            return 1.0
        
        # 可接受范围：0.5-2.0倍
        elif 0.5 <= duration_ratio <= 2.0:
            # 使用高斯函数计算适配度
            deviation = abs(duration_ratio - 1.0)
            fitness = math.exp(-deviation * deviation / 0.5)
            return max(fitness, 0.3)
        
        # 不可接受范围
        else:
            return 0.1
    
    def _calculate_flexible_duration_fitness(self, slice_duration: float, target_duration: float) -> float:
        """计算灵活时长适配度"""
        if target_duration <= 0:
            return 0.5
        
        ratio = slice_duration / target_duration
        tolerance = self.FLEXIBLE_MATCHING_CONFIG['duration_tolerance']
        
        # 更宽松的时长适配度计算
        if 0.5 <= ratio <= 2.0:  # 理想范围
            return 1.0
        elif 0.2 <= ratio <= 3.0:  # 可接受范围
            return 0.8
        elif 0.1 <= ratio <= 5.0:  # 勉强可用范围
            return 0.6
        else:  # 差距较大但仍可考虑
            return 0.3
    
    def _calculate_quality_score(self, slice_info: SliceInfo) -> float:
        """计算质量评分"""
        score = 0.0
        
        # 1. 分析置信度
        confidence_score = slice_info.confidence
        score += confidence_score * 0.4
        
        # 2. 文件大小（间接反映质量）
        size_score = min(slice_info.file_size_mb / 10.0, 1.0)  # 10MB为满分
        score += size_score * 0.2
        
        # 3. 标签完整性
        tags_completeness = 0.0
        required_tags = ['object', 'scene', 'emotion']
        
        for tag in required_tags:
            if slice_info.tags.get(tag, ''):
                tags_completeness += 1.0 / len(required_tags)
        
        score += tags_completeness * 0.3
        
        # 4. 字幕内容（如果有）
        if slice_info.has_subtitle:
            subtitle_score = min(len(slice_info.subtitle_content) / 100.0, 1.0)
            score += subtitle_score * 0.1
        
        return min(score, 1.0)
    
    def _check_required_tags(self, slice_info: SliceInfo, required_tags: Dict) -> bool:
        """检查必需标签"""
        for tag_key, tag_value in required_tags.items():
            if tag_key not in slice_info.tags:
                return False
            if tag_value and tag_value not in slice_info.tags[tag_key]:
                return False
        return True
    
    def _flexible_check_tags(self, slice_info: SliceInfo, required_tags: Dict) -> bool:
        """灵活标签检查"""
        # 不要求严格匹配，只要有部分匹配即可
        match_count = 0
        total_tags = len(required_tags)
        
        for tag_key, tag_value in required_tags.items():
            if tag_key in slice_info.tags:
                if not tag_value or tag_value in slice_info.tags[tag_key]:
                    match_count += 1
        
        # 只要匹配一半以上即可
        return match_count >= max(1, total_tags // 2)
    
    def _check_brand_elements(self, slice_info: SliceInfo, brand_elements: List[str]) -> bool:
        """检查品牌元素"""
        slice_brand = slice_info.tags.get('brand_elements', '')
        
        # 至少包含一个品牌元素
        return any(brand in slice_brand for brand in brand_elements)
    
    def _flexible_check_brand_elements(self, slice_info: SliceInfo, brand_elements: List[str]) -> bool:
        """灵活品牌元素检查"""
        if not brand_elements:
            return True
        
        slice_brand = slice_info.tags.get('brand_elements', '')
        if not slice_brand:
            return True  # 没有品牌信息时也通过
        
        # 只要包含任一品牌元素即可
        return any(brand.lower() in slice_brand.lower() for brand in brand_elements)
    
    def optimize_combination(self, candidates: List[MatchCandidate], 
                           target_duration: float, max_slices: int = 3) -> List[MatchCandidate]:
        """
        优化切片组合，确保总时长符合要求
        
        Args:
            candidates: 候选切片列表
            target_duration: 目标总时长
            max_slices: 最大切片数量
            
        Returns:
            优化后的切片组合
        """
        if not candidates:
            return []
        
        # 单个切片直接返回
        if len(candidates) == 1:
            return candidates[:1]
        
        # 动态规划寻找最优组合
        best_combination = self._find_optimal_combination(candidates, target_duration, max_slices)
        
        return best_combination
    
    def _find_optimal_combination(self, candidates: List[MatchCandidate], 
                                target_duration: float, max_slices: int) -> List[MatchCandidate]:
        """使用动态规划找到最优组合"""
        n = len(candidates)
        
        # 简化版本：贪心算法
        selected = []
        remaining_duration = target_duration
        used_candidates = set()
        
        # 按匹配得分排序
        sorted_candidates = sorted(candidates, key=lambda x: x.match_score, reverse=True)
        
        for candidate in sorted_candidates:
            if len(selected) >= max_slices:
                break
            
            if candidate.slice_info.slice_name in used_candidates:
                continue
            
            slice_duration = candidate.slice_info.duration
            
            # 检查是否适合剩余时长
            if slice_duration <= remaining_duration * 1.5:  # 允许一定的超出
                selected.append(candidate)
                remaining_duration -= slice_duration
                used_candidates.add(candidate.slice_info.slice_name)
                
                if remaining_duration <= 0:
                    break
        
        return selected
    
    def generate_match_report(self, candidates: List[MatchCandidate], 
                            match_request: MatchRequest) -> Dict:
        """生成匹配报告"""
        if not candidates:
            return {'error': 'No candidates found'}
        
        report = {
            'match_request': {
                'module_type': match_request.module_type,
                'target_duration': match_request.target_duration,
                'subtitle_preview': match_request.subtitle_content[:100],
                'required_tags': match_request.required_tags,
                'brand_elements': match_request.brand_elements,
                'emotion_preference': match_request.emotion_preference
            },
            'summary': {
                'total_candidates': len(candidates),
                'avg_match_score': sum(c.match_score for c in candidates) / len(candidates),
                'best_score': candidates[0].match_score if candidates else 0,
                'total_duration': sum(c.slice_info.duration for c in candidates)
            },
            'candidates': [
                {
                    'slice_name': c.slice_info.slice_name,
                    'video_name': c.slice_info.video_name,
                    'match_score': c.match_score,
                    'duration': c.slice_info.duration,
                    'tags': c.slice_info.tags,
                    'match_details': c.match_details
                }
                for c in candidates
            ],
            'analysis': {
                'duration_distribution': self._analyze_duration_distribution(candidates),
                'emotion_distribution': self._analyze_emotion_distribution(candidates),
                'brand_coverage': self._analyze_brand_coverage(candidates),
                'quality_statistics': self._analyze_quality_statistics(candidates)
            }
        }
        
        return report
    
    def _analyze_duration_distribution(self, candidates: List[MatchCandidate]) -> Dict:
        """分析时长分布"""
        durations = [c.slice_info.duration for c in candidates]
        
        return {
            'min_duration': min(durations) if durations else 0,
            'max_duration': max(durations) if durations else 0,
            'avg_duration': sum(durations) / len(durations) if durations else 0,
            'total_duration': sum(durations)
        }
    
    def _analyze_emotion_distribution(self, candidates: List[MatchCandidate]) -> Dict:
        """分析情绪分布"""
        emotions = [c.slice_info.tags.get('emotion', '') for c in candidates]
        emotion_counts = {}
        
        for emotion in emotions:
            if emotion:
                emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
        
        return emotion_counts
    
    def _analyze_brand_coverage(self, candidates: List[MatchCandidate]) -> Dict:
        """分析品牌覆盖"""
        brands = set()
        
        for candidate in candidates:
            brand_elements = candidate.slice_info.tags.get('brand_elements', '')
            if brand_elements:
                brands.update(brand_elements.split())
        
        return {
            'covered_brands': list(brands),
            'brand_count': len(brands)
        }
    
    def _analyze_quality_statistics(self, candidates: List[MatchCandidate]) -> Dict:
        """分析质量统计"""
        scores = [c.match_score for c in candidates]
        quality_scores = [c.quality_score for c in candidates]
        
        return {
            'avg_match_score': sum(scores) / len(scores) if scores else 0,
            'min_match_score': min(scores) if scores else 0,
            'max_match_score': max(scores) if scores else 0,
            'avg_quality_score': sum(quality_scores) / len(quality_scores) if quality_scores else 0,
            'high_quality_count': sum(1 for s in scores if s >= 0.8)
        } 
    
    def _generate_human_readable_score(self, candidate: MatchCandidate) -> str:
        """生成人工判断辅助信息"""
        details = candidate.match_details
        
        # 生成可读的评分解释
        components = []
        
        if details['semantic_score'] >= 0.7:
            components.append(f"语义:{details['semantic_score']:.2f}(优)")
        elif details['semantic_score'] >= 0.5:
            components.append(f"语义:{details['semantic_score']:.2f}(良)")
        else:
            components.append(f"语义:{details['semantic_score']:.2f}(差)")
        
        if details['duration_fitness'] >= 0.8:
            components.append(f"时长:{details['duration_fitness']:.2f}(适)")
        elif details['duration_fitness'] >= 0.6:
            components.append(f"时长:{details['duration_fitness']:.2f}(可)")
        else:
            components.append(f"时长:{details['duration_fitness']:.2f}(差)")
        
        if details['emotion_score'] >= 0.7:
            components.append(f"情绪:{details['emotion_score']:.2f}(符)")
        else:
            components.append(f"情绪:{details['emotion_score']:.2f}(异)")
        
        return " | ".join(components)
    
    def _determine_confidence_level(self, score: float) -> str:
        """确定置信度等级"""
        for (min_score, max_score), level in self.CONFIDENCE_LEVELS.items():
            if min_score <= score < max_score:
                return level
        return "需人工验证"
    
    def _analyze_confidence_distribution(self, candidates: List[MatchCandidate]) -> str:
        """分析置信度分布"""
        if not candidates:
            return "无候选"
        
        distribution = {}
        for candidate in candidates:
            level = candidate.confidence_level
            distribution[level] = distribution.get(level, 0) + 1
        
        return ", ".join([f"{level}:{count}" for level, count in distribution.items()])
    
    def generate_scored_filenames(self, candidates: List[MatchCandidate], output_dir: Path) -> Dict[str, str]:
        """
        生成包含评分信息的文件名，便于人工筛选
        
        Args:
            candidates: 候选切片列表
            output_dir: 输出目录
            
        Returns:
            原文件名到评分文件名的映射
        """
        filename_mapping = {}
        
        for i, candidate in enumerate(candidates):
            slice_info = candidate.slice_info
            original_name = Path(slice_info.file_path).stem
            
            # 生成评分文件名
            scored_filename = (
                f"{original_name}_"
                f"score{candidate.match_score:.3f}_"
                f"{candidate.confidence_level}_"
                f"rank{i+1:02d}"
            )
            
            filename_mapping[slice_info.file_path] = scored_filename
        
        return filename_mapping 

    def _calculate_main_tag_match(self, slice_info: SliceInfo, match_request: MatchRequest) -> float:
        """
        计算主标签匹配得分
        
        Args:
            slice_info: 切片信息
            match_request: 匹配请求
            
        Returns:
            主标签匹配得分 (0.0-1.0)
        """
        slice_main_tag = slice_info.tags.get('main_tag', '').strip()
        target_module = match_request.module_type.strip()
        
        # 如果切片没有主标签，给予中等分数
        if not slice_main_tag:
            return 0.5
        
        # 完全匹配 - 最高分
        if slice_main_tag == target_module:
            return 1.0
        
        # 映射匹配检查
        target_mappings = self.MAIN_TAG_MAPPINGS.get(target_module, [])
        if slice_main_tag in target_mappings:
            return 1.0
        
        # 核心模块名称匹配 (去除emoji)
        slice_core = slice_main_tag.replace('🪝', '').replace('🍼', '').replace('🌟', '').replace('🎁', '').strip()
        target_core = target_module.replace('🪝', '').replace('🍼', '').replace('🌟', '').replace('🎁', '').strip()
        
        if slice_core == target_core:
            return 0.95
        
        # 交叉模块匹配逻辑
        cross_module_score = self._calculate_cross_module_compatibility(slice_main_tag, target_module)
        if cross_module_score > 0:
            return cross_module_score
        
        # 完全不匹配
        return 0.1
    
    def _calculate_cross_module_compatibility(self, slice_main_tag: str, target_module: str) -> float:
        """
        计算跨模块兼容性得分
        某些模块的切片可能适用于其他模块
        
        Returns:
            兼容性得分 (0.0-0.8)
        """
        # 兼容性矩阵
        compatibility_matrix = {
            # 产品介绍的切片可以用于使用效果和促销机制
            ('🍼 产品介绍', '🌟 使用效果'): 0.6,
            ('🍼 产品介绍', '🎁 促销机制'): 0.5,
            
            # 使用效果的切片可以用于促销机制
            ('🌟 使用效果', '🎁 促销机制'): 0.7,
            ('🌟 使用效果', '🍼 产品介绍'): 0.4,
            
            # 促销机制的切片可以用于产品介绍
            ('🎁 促销机制', '🍼 产品介绍'): 0.4,
            
            # 钩子切片相对独立，但可以适配其他模块
            ('🪝 钩子', '🍼 产品介绍'): 0.3,
            ('🪝 钩子', '🌟 使用效果'): 0.3,
            ('🪝 钩子', '🎁 促销机制'): 0.3,
        }
        
        # 检查直接匹配
        key = (slice_main_tag, target_module)
        if key in compatibility_matrix:
            return compatibility_matrix[key]
        
        # 检查反向匹配
        reverse_key = (target_module, slice_main_tag)
        if reverse_key in compatibility_matrix:
            return compatibility_matrix[reverse_key] * 0.8  # 反向匹配稍微降低得分
        
        return 0.0 