#!/usr/bin/env python3
"""
切片扫描器 - Slice Scanner
扫描🎬Slice目录下的所有切片文件和对应的标签分析JSON文件
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import os

logger = logging.getLogger(__name__)

@dataclass
class SliceInfo:
    """切片信息数据结构"""
    file_path: str            # 切片文件路径
    video_name: str           # 源视频名称
    slice_name: str           # 切片名称
    duration: float           # 切片时长(秒)
    file_size_mb: float       # 文件大小(MB)
    slice_type: str           # 切片类型: slices/product
    tags: Dict                # 标签信息 {object, scene, emotion, brand_elements}
    analysis_file: str        # 对应的分析文件路径
    confidence: float         # 分析置信度
    has_subtitle: bool        # 是否有对应字幕
    subtitle_content: str     # 字幕内容

@dataclass 
class ScanResult:
    """扫描结果数据结构"""
    total_slices: int                    # 总切片数
    slice_infos: List[SliceInfo]         # 切片信息列表
    video_distribution: Dict[str, int]   # 按视频分布统计
    type_distribution: Dict[str, int]    # 按类型分布统计
    scan_metadata: Dict                  # 扫描元数据

class SliceScanner:
    """切片扫描器"""
    
    # 支持的视频格式
    VIDEO_EXTENSIONS = {'.mp4', '.mov', '.avi', '.mkv', '.webm', '.wmv', '.flv'}
    
    # 支持的字幕格式  
    SUBTITLE_EXTENSIONS = {'.srt', '.vtt', '.ass'}
    
    def __init__(self, slice_base_dir: str = None):
        self.logger = logging.getLogger(__name__)
        
        # 设置切片根目录
        if slice_base_dir:
            self.slice_dir = Path(slice_base_dir)
        else:
            # 默认使用相对路径
            self.slice_dir = Path(__file__).parent.parent.parent / "🎬Slice"
        
        if not self.slice_dir.exists():
            self.logger.warning(f"切片目录不存在: {self.slice_dir}")
    
    def scan_all_slices(self, video_names: List[str] = None) -> Optional[ScanResult]:
        """
        扫描所有切片文件
        
        Args:
            video_names: 指定要扫描的视频名称列表，None表示扫描所有
            
        Returns:
            ScanResult对象，失败返回None
        """
        try:
            self.logger.info(f"开始扫描切片目录: {self.slice_dir}")
            
            slice_infos = []
            video_distribution = {}
            type_distribution = {}
            
            # 获取要扫描的视频目录
            video_dirs = self._get_video_directories(video_names)
            
            for video_dir in video_dirs:
                video_name = video_dir.name
                self.logger.info(f"  扫描视频: {video_name}")
                
                # 扫描语义切片
                slices_dir = video_dir / "slices"
                if slices_dir.exists():
                    slice_count = self._scan_slice_directory(slices_dir, "slices", slice_infos)
                    type_distribution["slices"] = type_distribution.get("slices", 0) + slice_count
                
                # 扫描产品切片
                product_dir = video_dir / "product"
                if product_dir.exists():
                    product_count = self._scan_slice_directory(product_dir, "product", slice_infos)
                    type_distribution["product"] = type_distribution.get("product", 0) + product_count
                
                # 统计视频分布
                video_slice_count = sum(1 for si in slice_infos if si.video_name == video_name)
                if video_slice_count > 0:
                    video_distribution[video_name] = video_slice_count
            
            # 生成扫描结果
            scan_result = ScanResult(
                total_slices=len(slice_infos),
                slice_infos=slice_infos,
                video_distribution=video_distribution,
                type_distribution=type_distribution,
                scan_metadata=self._generate_scan_metadata(video_dirs)
            )
            
            self._log_scan_results(scan_result)
            
            return scan_result
            
        except Exception as e:
            self.logger.error(f"扫描切片失败: {e}")
            return None
    
    def scan_semantic_slices_only(self, video_names: List[str] = None) -> Optional[ScanResult]:
        """
        仅扫描语义切片文件 (slices/ 目录) - 适用于Method 1
        
        Args:
            video_names: 指定要扫描的视频名称列表，None表示扫描所有
            
        Returns:
            ScanResult对象，失败返回None
        """
        try:
            self.logger.info(f"🎯 Method 1 模式：仅扫描语义切片目录")
            
            slice_infos = []
            video_distribution = {}
            type_distribution = {}
            
            # 获取要扫描的视频目录
            video_dirs = self._get_video_directories(video_names)
            
            for video_dir in video_dirs:
                video_name = video_dir.name
                self.logger.info(f"  扫描视频: {video_name}")
                
                # 仅扫描语义切片
                slices_dir = video_dir / "slices"
                if slices_dir.exists():
                    slice_count = self._scan_slice_directory(slices_dir, "slices", slice_infos)
                    type_distribution["slices"] = type_distribution.get("slices", 0) + slice_count
                    self.logger.info(f"    语义切片: {slice_count} 个")
                
                # 统计视频分布
                video_slice_count = sum(1 for si in slice_infos if si.video_name == video_name)
                if video_slice_count > 0:
                    video_distribution[video_name] = video_slice_count
            
            # 生成扫描结果
            scan_result = ScanResult(
                total_slices=len(slice_infos),
                slice_infos=slice_infos,
                video_distribution=video_distribution,
                type_distribution=type_distribution,
                scan_metadata=self._generate_scan_metadata_with_mode(video_dirs, "semantic_only")
            )
            
            self.logger.info(f"✅ Method 1 扫描完成：共 {len(slice_infos)} 个语义切片")
            return scan_result
            
        except Exception as e:
            self.logger.error(f"语义切片扫描失败: {e}")
            return None
    
    def scan_product_slices_only(self, video_names: List[str] = None) -> Optional[ScanResult]:
        """
        仅扫描产品切片文件 (product/ 目录) - 适用于Method 2的产品介绍模块
        
        Args:
            video_names: 指定要扫描的视频名称列表，None表示扫描所有
            
        Returns:
            ScanResult对象，失败返回None
        """
        try:
            self.logger.info(f"🍼 Method 2 产品模块：仅扫描产品切片目录")
            
            slice_infos = []
            video_distribution = {}
            type_distribution = {}
            
            # 获取要扫描的视频目录
            video_dirs = self._get_video_directories(video_names)
            
            for video_dir in video_dirs:
                video_name = video_dir.name
                self.logger.info(f"  扫描视频: {video_name}")
                
                # 仅扫描产品切片
                product_dir = video_dir / "product"
                if product_dir.exists():
                    product_count = self._scan_slice_directory(product_dir, "product", slice_infos)
                    type_distribution["product"] = type_distribution.get("product", 0) + product_count
                    self.logger.info(f"    产品切片: {product_count} 个")
                
                # 统计视频分布
                video_slice_count = sum(1 for si in slice_infos if si.video_name == video_name)
                if video_slice_count > 0:
                    video_distribution[video_name] = video_slice_count
            
            # 生成扫描结果
            scan_result = ScanResult(
                total_slices=len(slice_infos),
                slice_infos=slice_infos,
                video_distribution=video_distribution,
                type_distribution=type_distribution,
                scan_metadata=self._generate_scan_metadata_with_mode(video_dirs, "product_only")
            )
            
            self.logger.info(f"✅ Method 2 产品扫描完成：共 {len(slice_infos)} 个产品切片")
            return scan_result
            
        except Exception as e:
            self.logger.error(f"产品切片扫描失败: {e}")
            return None
    
    def scan_dedicated_product_library(self) -> Optional[ScanResult]:
        """
        扫描专门的产品介绍素材库 (/Users/sshlijy/Desktop/demo/🎬Slice/🍼 产品介绍/)
        适用于Method 2的🍼 产品介绍模块
        
        Returns:
            ScanResult对象，失败返回None
        """
        try:
            self.logger.info(f"🎁 Method 2 专用：扫描产品介绍素材库")
            
            # 专门的产品介绍目录
            product_library_dir = self.slice_dir / "🍼 产品介绍"
            
            if not product_library_dir.exists():
                self.logger.warning(f"产品介绍素材库不存在: {product_library_dir}")
                return None
            
            slice_infos = []
            video_distribution = {}
            type_distribution = {}
            
            # 直接扫描产品介绍目录
            self.logger.info(f"  扫描产品素材库: {product_library_dir}")
            product_count = self._scan_dedicated_product_directory(product_library_dir, slice_infos)
            
            if product_count > 0:
                type_distribution["dedicated_product"] = product_count
                video_distribution["产品介绍素材库"] = product_count
            
            # 生成扫描结果
            scan_result = ScanResult(
                total_slices=len(slice_infos),
                slice_infos=slice_infos,
                video_distribution=video_distribution,
                type_distribution=type_distribution,
                scan_metadata=self._generate_scan_metadata_with_mode([product_library_dir], "dedicated_product_library")
            )
            
            self.logger.info(f"✅ 产品素材库扫描完成：共 {len(slice_infos)} 个专业产品素材")
            return scan_result
            
        except Exception as e:
            self.logger.error(f"产品素材库扫描失败: {e}")
            return None
    
    def _get_video_directories(self, video_names: List[str] = None) -> List[Path]:
        """获取要扫描的视频目录"""
        if not self.slice_dir.exists():
            return []
        
        all_dirs = [d for d in self.slice_dir.iterdir() if d.is_dir()]
        
        if video_names:
            # 过滤指定的视频名称
            target_dirs = []
            for video_name in video_names:
                video_dir = self.slice_dir / video_name
                if video_dir.exists():
                    target_dirs.append(video_dir)
                else:
                    self.logger.warning(f"指定的视频目录不存在: {video_name}")
            return target_dirs
        else:
            return all_dirs
    
    def _scan_slice_directory(self, slice_dir: Path, slice_type: str, slice_infos: List[SliceInfo]) -> int:
        """扫描单个切片目录"""
        count = 0
        
        try:
            # 获取所有视频文件
            video_files = []
            for ext in self.VIDEO_EXTENSIONS:
                video_files.extend(slice_dir.glob(f"*{ext}"))
            
            for video_file in video_files:
                slice_info = self._create_slice_info(video_file, slice_type)
                if slice_info:
                    slice_infos.append(slice_info)
                    count += 1
            
            self.logger.debug(f"    {slice_type}: 发现 {count} 个切片")
            
        except Exception as e:
            self.logger.warning(f"扫描目录失败 {slice_dir}: {e}")
        
        return count
    
    def _create_slice_info(self, video_file: Path, slice_type: str) -> Optional[SliceInfo]:
        """创建切片信息对象"""
        try:
            # 解析文件信息
            video_name = self._extract_video_name(video_file.name)
            slice_name = video_file.stem
            
            # 获取文件大小
            file_size_mb = video_file.stat().st_size / (1024 * 1024)
            
            # 查找对应的分析JSON文件
            analysis_file = video_file.parent / f"{slice_name}_analysis.json"
            tags = {}
            confidence = 0.0
            
            if analysis_file.exists():
                tags, confidence = self._load_analysis_tags(analysis_file)
            else:
                self.logger.debug(f"    未找到分析文件: {analysis_file.name}")
            
            # 查找对应的字幕文件
            subtitle_content, has_subtitle = self._load_subtitle_content(video_file)
            
            # 估算视频时长（简化版本）
            duration = self._estimate_video_duration(video_file, tags)
            
            return SliceInfo(
                file_path=str(video_file),
                video_name=video_name,
                slice_name=slice_name,
                duration=duration,
                file_size_mb=round(file_size_mb, 2),
                slice_type=slice_type,
                tags=tags,
                analysis_file=str(analysis_file) if analysis_file.exists() else "",
                confidence=confidence,
                has_subtitle=has_subtitle,
                subtitle_content=subtitle_content
            )
            
        except Exception as e:
            self.logger.warning(f"创建切片信息失败 {video_file}: {e}")
            return None
    
    def _extract_video_name(self, filename: str) -> str:
        """从文件名提取视频名称"""
        # 例如: video_1_semantic_seg_8_镜头8.mp4 -> video_1
        parts = filename.split('_')
        if len(parts) >= 2:
            return f"{parts[0]}_{parts[1]}"
        return parts[0] if parts else filename
    
    def _load_analysis_tags(self, analysis_file: Path) -> Tuple[Dict, float]:
        """加载分析标签"""
        try:
            with open(analysis_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            tags = {
                'object': data.get('object', ''),
                'scene': data.get('scene', ''),
                'emotion': data.get('emotion', ''),
                'brand_elements': data.get('brand_elements', '')
            }
            
            confidence = data.get('confidence', 0.0)
            
            return tags, confidence
            
        except Exception as e:
            self.logger.warning(f"加载分析标签失败 {analysis_file}: {e}")
            return {}, 0.0
    
    def _load_subtitle_content(self, video_file: Path) -> Tuple[str, bool]:
        """加载对应的字幕内容"""
        # 对于产品切片，查找对应的SRT文件
        if "product" in str(video_file):
            srt_file = video_file.parent / f"{video_file.stem}.srt"
            if srt_file.exists():
                try:
                    with open(srt_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # 提取纯文本内容
                    text_content = self._extract_subtitle_text(content)
                    return text_content, True
                    
                except Exception as e:
                    self.logger.warning(f"读取字幕文件失败 {srt_file}: {e}")
        
        return "", False
    
    def _extract_subtitle_text(self, srt_content: str) -> str:
        """从SRT内容中提取纯文本"""
        lines = srt_content.split('\n')
        text_lines = []
        
        for line in lines:
            line = line.strip()
            # 跳过序号行、时间戳行、空行和注释行
            if (line and 
                not line.isdigit() and 
                '-->' not in line and 
                not line.startswith('#')):
                text_lines.append(line)
        
        return ' '.join(text_lines)
    
    def _estimate_video_duration(self, video_file: Path, tags: Dict) -> float:
        """估算视频时长"""
        # 简化版本：基于文件大小估算
        file_size_mb = video_file.stat().st_size / (1024 * 1024)
        
        # 假设每MB约等于10-15秒（取决于质量）
        estimated_duration = file_size_mb * 12
        
        # 限制在合理范围内 (1-60秒)
        return max(1.0, min(estimated_duration, 60.0))
    
    def _generate_scan_metadata(self, video_dirs: List[Path]) -> Dict:
        """生成扫描元数据"""
        return {
            'scanned_at': datetime.now().isoformat(),
            'slice_base_dir': str(self.slice_dir),
            'scanned_videos': [d.name for d in video_dirs],
            'scan_method': 'slice_scanner_v2',
            'supported_formats': list(self.VIDEO_EXTENSIONS)
        }
    
    def _log_scan_results(self, scan_result: ScanResult):
        """记录扫描结果"""
        self.logger.info(f"扫描完成，共发现 {scan_result.total_slices} 个切片")
        
        self.logger.info("按视频分布:")
        for video_name, count in scan_result.video_distribution.items():
            self.logger.info(f"  {video_name}: {count} 个")
        
        self.logger.info("按类型分布:")
        for slice_type, count in scan_result.type_distribution.items():
            self.logger.info(f"  {slice_type}: {count} 个")
    
    def filter_slices_by_criteria(self, scan_result: ScanResult, 
                                  criteria: Dict) -> List[SliceInfo]:
        """根据条件过滤切片"""
        filtered_slices = []
        
        for slice_info in scan_result.slice_infos:
            if self._match_criteria(slice_info, criteria):
                filtered_slices.append(slice_info)
        
        self.logger.info(f"过滤条件匹配 {len(filtered_slices)} 个切片")
        return filtered_slices
    
    def _match_criteria(self, slice_info: SliceInfo, criteria: Dict) -> bool:
        """检查切片是否匹配条件"""
        # 视频名称过滤
        if 'video_names' in criteria:
            if slice_info.video_name not in criteria['video_names']:
                return False
        
        # 切片类型过滤
        if 'slice_types' in criteria:
            if slice_info.slice_type not in criteria['slice_types']:
                return False
        
        # 时长范围过滤
        if 'duration_range' in criteria:
            min_duration, max_duration = criteria['duration_range']
            if not (min_duration <= slice_info.duration <= max_duration):
                return False
        
        # 置信度过滤
        if 'min_confidence' in criteria:
            if slice_info.confidence < criteria['min_confidence']:
                return False
        
        # 标签过滤
        if 'required_tags' in criteria:
            for tag_key, tag_value in criteria['required_tags'].items():
                if tag_key not in slice_info.tags:
                    return False
                if tag_value and tag_value not in slice_info.tags[tag_key]:
                    return False
        
        # 品牌元素过滤
        if 'brand_elements' in criteria:
            brand_elements = slice_info.tags.get('brand_elements', '')
            required_brands = criteria['brand_elements']
            if not any(brand in brand_elements for brand in required_brands):
                return False
        
        return True
    
    def get_slice_by_path(self, scan_result: ScanResult, file_path: str) -> Optional[SliceInfo]:
        """根据文件路径获取切片信息"""
        for slice_info in scan_result.slice_infos:
            if slice_info.file_path == file_path:
                return slice_info
        return None
    
    def export_scan_result(self, scan_result: ScanResult, export_path: Path) -> bool:
        """导出扫描结果到JSON文件"""
        try:
            # 转换为可序列化的格式
            export_data = {
                'metadata': scan_result.scan_metadata,
                'summary': {
                    'total_slices': scan_result.total_slices,
                    'video_distribution': scan_result.video_distribution,
                    'type_distribution': scan_result.type_distribution
                },
                'slices': [
                    {
                        'file_path': slice_info.file_path,
                        'video_name': slice_info.video_name,
                        'slice_name': slice_info.slice_name,
                        'duration': slice_info.duration,
                        'file_size_mb': slice_info.file_size_mb,
                        'slice_type': slice_info.slice_type,
                        'tags': slice_info.tags,
                        'confidence': slice_info.confidence,
                        'has_subtitle': slice_info.has_subtitle,
                        'subtitle_preview': slice_info.subtitle_content[:100] + '...' if len(slice_info.subtitle_content) > 100 else slice_info.subtitle_content
                    }
                    for slice_info in scan_result.slice_infos
                ]
            }
            
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"成功导出扫描结果到: {export_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"导出扫描结果失败: {e}")
            return False 

    def _scan_dedicated_product_directory(self, product_dir: Path, slice_infos: List[SliceInfo]) -> int:
        """扫描专门的产品介绍目录"""
        count = 0
        
        try:
            # 获取所有视频文件
            video_files = []
            for ext in self.VIDEO_EXTENSIONS:
                video_files.extend(product_dir.glob(f"*{ext}"))
            
            for video_file in video_files:
                slice_info = self._create_dedicated_product_slice_info(video_file)
                if slice_info:
                    slice_infos.append(slice_info)
                    count += 1
            
            self.logger.info(f"    专业产品素材: 发现 {count} 个")
            
        except Exception as e:
            self.logger.warning(f"扫描专业产品目录失败 {product_dir}: {e}")
        
        return count
    
    def _create_dedicated_product_slice_info(self, video_file: Path) -> Optional[SliceInfo]:
        """创建专门产品素材的切片信息对象"""
        try:
            # 解析文件信息
            slice_name = video_file.stem
            
            # 从文件名提取产品信息
            if "启赋水奶" in slice_name:
                video_name = "启赋水奶"
                product_type = "便携产品介绍"
            elif "启赋蕴淳" in slice_name:
                video_name = "启赋蕴淳"
                product_type = "核心配方介绍"
            else:
                video_name = "通用产品"
                product_type = "产品介绍"
            
            # 获取文件大小
            file_size_mb = video_file.stat().st_size / (1024 * 1024)
            
            # 查找对应的JSON分析文件
            json_file = video_file.parent / f"{slice_name}.json"
            tags = {}
            confidence = 0.9  # 专业素材给予高置信度
            
            if json_file.exists():
                tags = self._load_dedicated_product_tags(json_file)
            else:
                # 基于文件名生成基础标签
                tags = {
                    'object': f'{video_name}产品展示',
                    'scene': '产品介绍',
                    'emotion': '专业',
                    'brand_elements': video_name,
                    'main_tag': '🍼 产品介绍'
                }
            
            # 查找对应的字幕文件
            subtitle_content, has_subtitle = self._load_subtitle_content(video_file)
            
            # 估算视频时长
            duration = self._estimate_video_duration(video_file, tags)
            
            return SliceInfo(
                file_path=str(video_file),
                video_name=video_name,
                slice_name=slice_name,
                duration=duration,
                file_size_mb=round(file_size_mb, 2),
                slice_type="dedicated_product",
                tags=tags,
                analysis_file=str(json_file) if json_file.exists() else "",
                confidence=confidence,
                has_subtitle=has_subtitle,
                subtitle_content=subtitle_content
            )
            
        except Exception as e:
            self.logger.warning(f"创建专业产品切片信息失败 {video_file}: {e}")
            return None
    
    def _load_dedicated_product_tags(self, json_file: Path) -> Dict:
        """加载专门产品素材的标签"""
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 从产品分析数据中提取标签
            product_analysis = data.get('product_analysis', {})
            
            tags = {
                'object': f"{product_analysis.get('product_brand_type', '产品')}展示",
                'scene': '产品介绍',
                'emotion': '专业',
                'brand_elements': ', '.join(product_analysis.get('brand_mentions', [])),
                'main_tag': '🍼 产品介绍'
            }
            
            return tags
            
        except Exception as e:
            self.logger.warning(f"加载专业产品标签失败 {json_file}: {e}")
            return {}
    
    def _generate_scan_metadata_with_mode(self, video_dirs: List[Path], scan_mode: str) -> Dict:
        """生成扫描元数据（带模式）"""
        return {
            'scanned_at': datetime.now().isoformat(),
            'slice_base_dir': str(self.slice_dir),
            'scanned_videos': [d.name for d in video_dirs],
            'scan_method': 'slice_scanner_v2',
            'scan_mode': scan_mode,
            'supported_formats': list(self.VIDEO_EXTENSIONS)
        } 