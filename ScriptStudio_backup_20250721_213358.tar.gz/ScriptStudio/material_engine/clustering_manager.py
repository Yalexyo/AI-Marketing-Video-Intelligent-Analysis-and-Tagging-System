#!/usr/bin/env python3
"""
聚类管理器 - Clustering Manager
实现方式2的内容聚类功能，自动按主题分组切片并生成聚类文件夹
"""

import logging
import json
import shutil
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
from collections import defaultdict
import os

from .slice_scanner import SliceInfo, ScanResult
from .similarity_matcher import MatchCandidate, SimilarityMatcher

logger = logging.getLogger(__name__)

@dataclass
class ClusterInfo:
    """聚类信息数据结构"""
    cluster_id: str           # 聚类ID
    cluster_name: str         # 聚类名称
    theme: str               # 主题描述
    slice_count: int         # 切片数量
    total_duration: float    # 总时长
    avg_confidence: float    # 平均置信度
    dominant_emotion: str    # 主导情绪
    representative_tags: List[str]  # 代表性标签
    folder_path: str         # 文件夹路径

@dataclass
class ClusterResult:
    """聚类结果"""
    clusters: List[ClusterInfo]      # 聚类信息列表
    cluster_mapping: Dict[str, str]  # 切片到聚类的映射
    unclustered_slices: List[SliceInfo]  # 未聚类的切片
    metadata: Dict               # 聚类元数据

class ClusteringManager:
    """聚类管理器"""
    
    def __init__(self, workspace_dir: str = None):
        self.logger = logging.getLogger(__name__)
        
        # 设置工作目录
        if workspace_dir:
            self.workspace = Path(workspace_dir)
        else:
            self.workspace = Path(__file__).parent.parent.parent
        
        # 初始化相似度匹配器
        self.similarity_matcher = SimilarityMatcher()
        
        # 预定义主题聚类规则
        self.THEME_CLUSTERING_RULES = {
            '产品展示': {
                'keywords': ['产品', '奶粉', '启赋', '配方', '包装', '展示'],
                'emotions': ['专业', '温馨'],
                'scenes': ['产品', '展示', '包装'],
                'folder_name': '01_产品展示'
            },
            '妈妈场景': {
                'keywords': ['妈妈', '母亲', '喂养', '哺乳', '育儿'],
                'emotions': ['温馨', '安心', '关爱'],
                'scenes': ['家庭', '室内', '育儿'],
                'folder_name': '02_妈妈场景'
            },
            '宝宝成长': {
                'keywords': ['宝宝', '婴儿', '成长', '健康', '发育'],
                'emotions': ['开心', '温馨', '惊喜'],
                'scenes': ['宝宝', '成长', '健康'],
                'folder_name': '03_宝宝成长'
            },
            '专业认证': {
                'keywords': ['专业', '认证', '权威', '医生', '专家', '研究'],
                'emotions': ['专业', '权威'],
                'scenes': ['专业', '医疗', '研究'],
                'folder_name': '04_专业认证'
            },
            '营养科学': {
                'keywords': ['营养', '科学', 'HMO', 'A2', '成分', '配方'],
                'emotions': ['专业', '好奇'],
                'scenes': ['科学', '营养', '实验'],
                'folder_name': '05_营养科学'
            },
            '使用场景': {
                'keywords': ['使用', '冲泡', '喂养', '日常', '生活'],
                'emotions': ['温馨', '自然'],
                'scenes': ['日常', '使用', '生活'],
                'folder_name': '06_使用场景'
            },
            '情感表达': {
                'keywords': ['爱', '关怀', '呵护', '陪伴', '情感'],
                'emotions': ['温馨', '感动', '关爱'],
                'scenes': ['情感', '关怀', '陪伴'],
                'folder_name': '07_情感表达'
            },
            '推荐引导': {
                'keywords': ['推荐', '选择', '优惠', '购买', '行动'],
                'emotions': ['开心', '积极', '引导'],
                'scenes': ['推荐', '选择', '购买'],
                'folder_name': '08_推荐引导'
            }
        }
        
        self.logger.info("聚类管理器初始化完成")
    
    def cluster_slices_by_theme(self, scan_result: ScanResult, 
                               output_dir: Path = None) -> ClusterResult:
        """
        按主题对切片进行聚类
        
        Args:
            scan_result: 扫描结果
            output_dir: 输出目录
            
        Returns:
            聚类结果
        """
        try:
            self.logger.info(f"🎯 开始按主题聚类切片，共 {len(scan_result.slice_infos)} 个切片")
            
            if not output_dir:
                output_dir = self.workspace / "📁聚类结果" / datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # 创建输出目录
            output_dir.mkdir(parents=True, exist_ok=True)
            
            # 1. 初始化聚类结果
            cluster_mapping = {}
            clusters = []
            unclustered_slices = []
            
            # 2. 为每个主题创建聚类
            for theme_name, theme_rules in self.THEME_CLUSTERING_RULES.items():
                theme_slices = self._find_theme_slices(scan_result.slice_infos, theme_rules)
                
                if theme_slices:
                    cluster_info = self._create_cluster(
                        theme_name, theme_rules, theme_slices, output_dir
                    )
                    clusters.append(cluster_info)
                    
                    # 记录切片到聚类的映射
                    for slice_info in theme_slices:
                        cluster_mapping[slice_info.file_path] = cluster_info.cluster_id
                    
                    self.logger.info(f"  ✅ {theme_name}: {len(theme_slices)} 个切片")
                else:
                    self.logger.info(f"  ❌ {theme_name}: 0 个切片")
            
            # 3. 处理未聚类的切片
            clustered_paths = set(cluster_mapping.keys())
            for slice_info in scan_result.slice_infos:
                if slice_info.file_path not in clustered_paths:
                    unclustered_slices.append(slice_info)
            
            # 4. 创建混合聚类（未分类的切片）
            if unclustered_slices:
                misc_cluster = self._create_misc_cluster(unclustered_slices, output_dir)
                clusters.append(misc_cluster)
                
                for slice_info in unclustered_slices:
                    cluster_mapping[slice_info.file_path] = misc_cluster.cluster_id
                
                self.logger.info(f"  📦 混合聚类: {len(unclustered_slices)} 个切片")
            
            # 5. 生成聚类报告
            cluster_result = ClusterResult(
                clusters=clusters,
                cluster_mapping=cluster_mapping,
                unclustered_slices=[],  # 所有切片都已聚类
                metadata=self._generate_cluster_metadata(clusters, output_dir)
            )
            
            # 6. 导出聚类报告
            self._export_cluster_report(cluster_result, output_dir)
            
            self.logger.info(f"✅ 聚类完成，共生成 {len(clusters)} 个聚类")
            return cluster_result
            
        except Exception as e:
            self.logger.error(f"聚类失败: {e}")
            return ClusterResult([], {}, [], {})
    
    def _find_theme_slices(self, all_slices: List[SliceInfo], theme_rules: Dict) -> List[SliceInfo]:
        """根据主题规则找到匹配的切片"""
        theme_slices = []
        
        for slice_info in all_slices:
            if self._match_theme_rules(slice_info, theme_rules):
                theme_slices.append(slice_info)
        
        return theme_slices
    
    def _match_theme_rules(self, slice_info: SliceInfo, theme_rules: Dict) -> bool:
        """检查切片是否匹配主题规则"""
        score = 0
        max_score = 0
        
        # 1. 关键词匹配
        keywords = theme_rules.get('keywords', [])
        if keywords:
            max_score += 3
            object_desc = slice_info.tags.get('object', '').lower()
            scene_desc = slice_info.tags.get('scene', '').lower()
            
            for keyword in keywords:
                if keyword.lower() in object_desc or keyword.lower() in scene_desc:
                    score += 3
                    break
        
        # 2. 情绪匹配
        emotions = theme_rules.get('emotions', [])
        if emotions:
            max_score += 2
            slice_emotion = slice_info.tags.get('emotion', '')
            if slice_emotion in emotions:
                score += 2
        
        # 3. 场景匹配
        scenes = theme_rules.get('scenes', [])
        if scenes:
            max_score += 2
            slice_scene = slice_info.tags.get('scene', '').lower()
            for scene in scenes:
                if scene.lower() in slice_scene:
                    score += 2
                    break
        
        # 4. 品牌元素匹配（额外加分）
        brand_elements = slice_info.tags.get('brand_elements', '')
        if brand_elements:
            score += 1
        
        # 匹配阈值：至少达到60%的匹配度
        threshold = max(max_score * 0.6, 1) if max_score > 0 else 1
        return score >= threshold
    
    def _create_cluster(self, theme_name: str, theme_rules: Dict, 
                       theme_slices: List[SliceInfo], output_dir: Path) -> ClusterInfo:
        """创建聚类并生成文件夹"""
        cluster_id = f"cluster_{theme_name.replace(' ', '_')}"
        folder_name = theme_rules['folder_name']
        
        # 创建聚类文件夹
        cluster_folder = output_dir / folder_name
        cluster_folder.mkdir(parents=True, exist_ok=True)
        
        # 复制切片文件到聚类文件夹（创建带评分的符号链接）
        self._organize_cluster_files(theme_slices, cluster_folder, theme_name)
        
        # 计算聚类统计信息
        total_duration = sum(slice_info.duration for slice_info in theme_slices)
        avg_confidence = sum(slice_info.confidence for slice_info in theme_slices) / len(theme_slices)
        
        # 统计主导情绪
        emotions = [slice_info.tags.get('emotion', '') for slice_info in theme_slices]
        emotion_counts = defaultdict(int)
        for emotion in emotions:
            if emotion:
                emotion_counts[emotion] += 1
        dominant_emotion = max(emotion_counts.items(), key=lambda x: x[1])[0] if emotion_counts else ''
        
        # 提取代表性标签
        representative_tags = self._extract_representative_tags(theme_slices)
        
        return ClusterInfo(
            cluster_id=cluster_id,
            cluster_name=theme_name,
            theme=theme_rules.get('description', theme_name),
            slice_count=len(theme_slices),
            total_duration=total_duration,
            avg_confidence=avg_confidence,
            dominant_emotion=dominant_emotion,
            representative_tags=representative_tags,
            folder_path=str(cluster_folder)
        )
    
    def _create_misc_cluster(self, unclustered_slices: List[SliceInfo], output_dir: Path) -> ClusterInfo:
        """创建混合聚类（未分类的切片）"""
        cluster_id = "cluster_miscellaneous"
        folder_name = "99_混合聚类"
        
        # 创建聚类文件夹
        cluster_folder = output_dir / folder_name
        cluster_folder.mkdir(parents=True, exist_ok=True)
        
        # 复制切片文件
        self._organize_cluster_files(unclustered_slices, cluster_folder, "混合聚类")
        
        # 计算统计信息
        total_duration = sum(slice_info.duration for slice_info in unclustered_slices)
        avg_confidence = sum(slice_info.confidence for slice_info in unclustered_slices) / len(unclustered_slices)
        
        # 统计主导情绪
        emotions = [slice_info.tags.get('emotion', '') for slice_info in unclustered_slices]
        emotion_counts = defaultdict(int)
        for emotion in emotions:
            if emotion:
                emotion_counts[emotion] += 1
        dominant_emotion = max(emotion_counts.items(), key=lambda x: x[1])[0] if emotion_counts else ''
        
        # 提取代表性标签
        representative_tags = self._extract_representative_tags(unclustered_slices)
        
        return ClusterInfo(
            cluster_id=cluster_id,
            cluster_name="混合聚类",
            theme="未明确分类的切片内容",
            slice_count=len(unclustered_slices),
            total_duration=total_duration,
            avg_confidence=avg_confidence,
            dominant_emotion=dominant_emotion,
            representative_tags=representative_tags,
            folder_path=str(cluster_folder)
        )
    
    def _organize_cluster_files(self, slices: List[SliceInfo], cluster_folder: Path, theme_name: str):
        """组织聚类文件（创建符号链接并包含评分信息）"""
        # 创建子文件夹
        video_folder = cluster_folder / "视频文件"
        analysis_folder = cluster_folder / "分析文件"
        video_folder.mkdir(exist_ok=True)
        analysis_folder.mkdir(exist_ok=True)
        
        # 按置信度排序
        sorted_slices = sorted(slices, key=lambda x: x.confidence, reverse=True)
        
        for i, slice_info in enumerate(sorted_slices):
            # 生成带评分的文件名
            original_name = Path(slice_info.file_path).stem
            extension = Path(slice_info.file_path).suffix
            
            scored_name = (
                f"{original_name}_"
                f"conf{slice_info.confidence:.3f}_"
                f"dur{slice_info.duration:.1f}s_"
                f"rank{i+1:02d}"
            )
            
            # 创建视频文件符号链接
            video_link = video_folder / f"{scored_name}{extension}"
            if not video_link.exists():
                try:
                    video_link.symlink_to(slice_info.file_path)
                except OSError:
                    # 如果符号链接失败，复制文件
                    shutil.copy2(slice_info.file_path, video_link)
            
            # 创建分析文件符号链接
            analysis_file = Path(slice_info.analysis_file)
            if analysis_file.exists():
                analysis_link = analysis_folder / f"{scored_name}_analysis.json"
                if not analysis_link.exists():
                    try:
                        analysis_link.symlink_to(slice_info.analysis_file)
                    except OSError:
                        shutil.copy2(slice_info.analysis_file, analysis_link)
        
        # 生成聚类概览文件
        self._generate_cluster_overview(slices, cluster_folder, theme_name)
    
    def _generate_cluster_overview(self, slices: List[SliceInfo], cluster_folder: Path, theme_name: str):
        """生成聚类概览文件"""
        overview_file = cluster_folder / "聚类概览.json"
        
        overview_data = {
            'cluster_name': theme_name,
            'slice_count': len(slices),
            'total_duration': sum(s.duration for s in slices),
            'avg_confidence': sum(s.confidence for s in slices) / len(slices),
            'created_at': datetime.now().isoformat(),
            'slices': [
                {
                    'slice_name': s.slice_name,
                    'video_name': s.video_name,
                    'duration': s.duration,
                    'confidence': s.confidence,
                    'tags': s.tags,
                    'file_path': s.file_path
                }
                for s in sorted(slices, key=lambda x: x.confidence, reverse=True)
            ]
        }
        
        with open(overview_file, 'w', encoding='utf-8') as f:
            json.dump(overview_data, f, ensure_ascii=False, indent=2)
    
    def _extract_representative_tags(self, slices: List[SliceInfo]) -> List[str]:
        """提取代表性标签"""
        tag_counts = defaultdict(int)
        
        for slice_info in slices:
            for tag_key, tag_value in slice_info.tags.items():
                if tag_value and tag_key != 'brand_elements':
                    tag_counts[f"{tag_key}:{tag_value}"] += 1
        
        # 返回出现频率最高的标签
        sorted_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)
        return [tag for tag, count in sorted_tags[:5]]
    
    def _generate_cluster_metadata(self, clusters: List[ClusterInfo], output_dir: Path) -> Dict:
        """生成聚类元数据"""
        return {
            'clustering_method': 'theme_based',
            'created_at': datetime.now().isoformat(),
            'total_clusters': len(clusters),
            'output_directory': str(output_dir),
            'cluster_summary': {
                'total_slices': sum(c.slice_count for c in clusters),
                'total_duration': sum(c.total_duration for c in clusters),
                'avg_cluster_size': sum(c.slice_count for c in clusters) / len(clusters) if clusters else 0
            }
        }
    
    def _export_cluster_report(self, cluster_result: ClusterResult, output_dir: Path):
        """导出聚类报告"""
        report_file = output_dir / "聚类报告.json"
        
        report_data = {
            'metadata': cluster_result.metadata,
            'clusters': [
                {
                    'cluster_id': c.cluster_id,
                    'cluster_name': c.cluster_name,
                    'theme': c.theme,
                    'slice_count': c.slice_count,
                    'total_duration': c.total_duration,
                    'avg_confidence': c.avg_confidence,
                    'dominant_emotion': c.dominant_emotion,
                    'representative_tags': c.representative_tags,
                    'folder_path': c.folder_path
                }
                for c in cluster_result.clusters
            ],
            'cluster_distribution': {
                c.cluster_name: c.slice_count 
                for c in cluster_result.clusters
            }
        }
        
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)
        
        self.logger.info(f"📊 聚类报告已导出: {report_file}")
    
    def generate_cluster_folders_for_candidates(self, candidates: List[MatchCandidate], 
                                              module_type: str, output_dir: Path) -> Path:
        """
        为候选切片生成聚类文件夹（支持Method标签的多候选选择）
        
        Args:
            candidates: 候选切片列表
            module_type: 模块类型（已包含Method标签，如"🎯Method1_🍼 产品介绍_语义切片"）
            output_dir: 输出目录
            
        Returns:
            创建的文件夹路径
        """
        try:
            # 创建模块专用文件夹（模块类型已包含Method标签）
            module_folder = output_dir / f"📁{module_type}_候选切片"
            module_folder.mkdir(parents=True, exist_ok=True)
            
            # 按置信度等级分组
            confidence_groups = defaultdict(list)
            for candidate in candidates:
                confidence_groups[candidate.confidence_level].append(candidate)
            
            # 为每个置信度等级创建子文件夹
            for confidence_level, group_candidates in confidence_groups.items():
                level_folder = module_folder / confidence_level
                level_folder.mkdir(exist_ok=True)
                
                # 组织候选文件
                self._organize_candidate_files(group_candidates, level_folder)
            
            # 生成候选概览
            self._generate_candidates_overview(candidates, module_folder, module_type)
            
            self.logger.info(f"✅ 候选切片文件夹已创建: {module_folder}")
            return module_folder
            
        except Exception as e:
            self.logger.error(f"创建候选文件夹失败: {e}")
            return output_dir
    
    def _organize_candidate_files(self, candidates: List[MatchCandidate], folder: Path):
        """组织候选文件"""
        for i, candidate in enumerate(candidates):
            slice_info = candidate.slice_info
            
            # 生成详细的评分文件名
            original_name = Path(slice_info.file_path).stem
            extension = Path(slice_info.file_path).suffix
            
            scored_name = (
                f"{original_name}_"
                f"score{candidate.match_score:.3f}_"
                f"conf{slice_info.confidence:.3f}_"
                f"dur{slice_info.duration:.1f}s_"
                f"rank{i+1:02d}"
            )
            
            # 创建符号链接
            link_path = folder / f"{scored_name}{extension}"
            if not link_path.exists():
                try:
                    link_path.symlink_to(slice_info.file_path)
                except OSError:
                    shutil.copy2(slice_info.file_path, link_path)
    
    def _generate_candidates_overview(self, candidates: List[MatchCandidate], 
                                    folder: Path, module_type: str):
        """生成候选概览文件（支持Method标签）"""
        # 清理文件名中的特殊字符，避免文件名过长
        clean_module_name = module_type.replace('/', '_').replace('\\', '_')
        overview_file = folder / f"📋{clean_module_name}_候选概览.json"
        
        overview_data = {
            'module_type': module_type,
            'candidate_count': len(candidates),
            'created_at': datetime.now().isoformat(),
            'score_range': {
                'min': min(c.match_score for c in candidates) if candidates else 0,
                'max': max(c.match_score for c in candidates) if candidates else 0,
                'avg': sum(c.match_score for c in candidates) / len(candidates) if candidates else 0
            },
            'candidates': [
                {
                    'slice_name': c.slice_info.slice_name,
                    'video_name': c.slice_info.video_name,
                    'match_score': c.match_score,
                    'confidence_level': c.confidence_level,
                    'human_readable_score': c.human_readable_score,
                    'duration': c.slice_info.duration,
                    'tags': c.slice_info.tags,
                    'file_path': c.slice_info.file_path
                }
                for c in candidates
            ]
        }
        
        with open(overview_file, 'w', encoding='utf-8') as f:
            json.dump(overview_data, f, ensure_ascii=False, indent=2) 