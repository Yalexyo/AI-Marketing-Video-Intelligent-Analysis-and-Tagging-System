#!/usr/bin/env python3
"""
Script Studio V2.0 - 智能视频脚本生成与组装系统
支持两种脚本生成方式：字幕映射脚本 + 创意脚本生成
支持多候选切片选择和智能聚类功能
"""

import json
import logging
import argparse
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime

# 导入我们创建的模块
from srt_analyzer import TimelineParser, ModuleIdentifier, SemanticMatcher
from material_engine import SliceScanner, SimilarityMatcher, ClusteringManager
from material_engine.similarity_matcher import MatchRequest
from video_assembler import VideoComposer, CompositionConfig, CompositionJob

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ScriptStudioV2:
    """Script Studio V2.0 主控制器"""
    
    def __init__(self, workspace_dir: str = None):
        self.logger = logging.getLogger(__name__)
        
        # 设置工作目录
        if workspace_dir:
            self.workspace = Path(workspace_dir)
        else:
            self.workspace = Path(__file__).parent.parent
        
        # 初始化各个组件 - 只使用Claude 4
        self.timeline_parser = TimelineParser()
        self.module_identifier = ModuleIdentifier()
        self.semantic_matcher = SemanticMatcher()
        self.slice_scanner = SliceScanner()
        self.similarity_matcher = SimilarityMatcher()
        self.clustering_manager = ClusteringManager()
        
        self.logger.info("🚀 Script Studio V2.0 初始化完成 (Claude 4)")
        self.logger.info(f"工作目录: {self.workspace}")
    
    def scan_ref_directory(self) -> List[Dict]:
        """
        扫描 ref 目录，找到所有参考视频和字幕文件对
        
        Returns:
            参考文件列表，每个元素包含 video_path 和 srt_path
        """
        ref_dir = self.workspace / "🍭Origin" / "ref"
        if not ref_dir.exists():
            self.logger.warning(f"参考目录不存在: {ref_dir}")
            return []
        
        ref_files = []
        video_extensions = ['.mp4', '.avi', '.mov', '.mkv']
        
        # 扫描所有视频文件
        for video_file in ref_dir.iterdir():
            if video_file.suffix.lower() in video_extensions:
                # 寻找对应的字幕文件
                srt_file = ref_dir / f"{video_file.stem}.srt"
                if srt_file.exists():
                    ref_files.append({
                        'video_name': video_file.stem,
                        'video_path': str(video_file),
                        'srt_path': str(srt_file),
                        'video_size': video_file.stat().st_size if video_file.exists() else 0,
                        'srt_lines': len(srt_file.read_text(encoding='utf-8').splitlines()) if srt_file.exists() else 0
                    })
                    self.logger.info(f"✅ 找到参考文件对: {video_file.name} + {srt_file.name}")
                else:
                    self.logger.warning(f"⚠️ 视频文件缺少字幕: {video_file.name}")
        
        self.logger.info(f"📂 ref目录扫描完成，找到 {len(ref_files)} 个完整的参考文件对")
        return ref_files
    
    def method1_subtitle_mapping_from_ref(self, ref_file_name: str = None,
                                        enable_multi_candidates: bool = True,
                                        quality_threshold: float = 0.3,
                                        max_candidates: int = 10) -> Dict:
        """
        方式1：从 ref 目录读取参考文件进行字幕映射脚本生成
        
        Args:
            ref_file_name: 参考文件名（不含扩展名），如果为None则使用第一个找到的文件
            enable_multi_candidates: 是否启用多候选选择
            quality_threshold: 质量阈值
            max_candidates: 最大候选数量
            
        Returns:
            脚本生成结果
        """
        try:
            # 1. 扫描 ref 目录
            ref_files = self.scan_ref_directory()
            if not ref_files:
                raise ValueError("ref目录中没有找到完整的参考文件对（视频+字幕）")
            
            # 2. 选择要处理的参考文件
            selected_ref = None
            if ref_file_name:
                # 查找指定的参考文件
                selected_ref = next((rf for rf in ref_files if rf['video_name'] == ref_file_name), None)
                if not selected_ref:
                    raise ValueError(f"未找到指定的参考文件: {ref_file_name}")
            else:
                # 使用第一个找到的文件
                selected_ref = ref_files[0]
                self.logger.info(f"🎯 自动选择参考文件: {selected_ref['video_name']}")
            
            # 3. 调用原有的字幕映射方法
            return self.method1_subtitle_mapping(
                video_name=selected_ref['video_name'],
                srt_path=selected_ref['srt_path'],
                enable_multi_candidates=enable_multi_candidates,
                quality_threshold=quality_threshold,
                max_candidates=max_candidates
            )
            
        except Exception as e:
            self.logger.error(f"从ref目录进行字幕映射失败: {e}")
            return {"error": str(e)}
    
    def method1_subtitle_mapping(self, video_name: str, srt_path: str = None, 
                                enable_multi_candidates: bool = True,
                                quality_threshold: float = 0.3,
                                max_candidates: int = 10) -> Dict:
        """
        方式1：字幕映射脚本生成（支持多候选切片选择）
        从已知视频和字幕分析主标签模块占比，匹配素材
        
        Args:
            video_name: 视频名称 (如: video_1 或 参考文件名)
            srt_path: SRT文件路径 (可选，自动推断)
            enable_multi_candidates: 是否启用多候选选择
            quality_threshold: 质量阈值
            max_candidates: 最大候选数量
            
        Returns:
            脚本生成结果
        """
        try:
            self.logger.info(f"🎬 开始方式1：字幕映射脚本生成 - {video_name}")
            self.logger.info(f"  多候选模式: {enable_multi_candidates}")
            self.logger.info(f"  质量阈值: {quality_threshold}")
            self.logger.info(f"  最大候选数: {max_candidates}")
            
            # 1. 解析SRT文件 - 支持多种路径查找方式
            if not srt_path:
                # 首先尝试 ref 目录
                ref_srt = self.workspace / "🍭Origin" / "ref" / f"{video_name}.srt"
                if ref_srt.exists():
                    srt_path = ref_srt
                    self.logger.info(f"📄 使用ref目录字幕: {srt_path}")
                else:
                    # 回退到传统的 SRT 目录
                srt_path = self.workspace / "📄SRT" / video_name / f"{video_name}_full.srt"
                    self.logger.info(f"📄 使用传统SRT目录: {srt_path}")
            
            srt_file = Path(srt_path)
            if not srt_file.exists():
                raise FileNotFoundError(f"SRT文件不存在: {srt_file}")
            
            timeline_analysis = self.timeline_parser.parse_srt_file(srt_file)
            if not timeline_analysis:
                raise ValueError("SRT解析失败")
            
            # 2. 模块识别分析
            module_analysis = self.module_identifier.analyze_modules(timeline_analysis)
            if not module_analysis:
                raise ValueError("模块识别失败")
            
            # 3. 扫描可用素材 - Method 1 仅使用语义切片
            scan_result = self.slice_scanner.scan_semantic_slices_only()
            if not scan_result or not scan_result.slice_infos:
                raise ValueError("未找到可用的语义切片素材")
            
            self.logger.info(f"🎯 Method 1 专用：扫描到 {scan_result.total_slices} 个语义切片")
            self.logger.info(f"  类型分布: {scan_result.type_distribution}")
            self.logger.info(f"  视频分布: {scan_result.video_distribution}")
            
            # 4. 为每个模块匹配素材（支持多候选）
            module_matches = {}
            candidate_folders = []
            
            for module in module_analysis.module_segments:
                if enable_multi_candidates:
                    # 多候选模式：找到所有符合阈值的候选
                    candidates = self._find_multiple_candidates(module, scan_result, quality_threshold, max_candidates)
                    module_matches[module.module_type] = candidates
                else:
                    # 传统模式：只找最佳匹配
                    matches = self._find_module_matches(module, scan_result)
                    module_matches[module.module_type] = matches
            
            # 7. 创建多候选文件夹（如果启用） - Method 1 语义切片版本
            output_base_dir = None
            if enable_multi_candidates:
                output_base_dir = self.workspace / "📁生成结果" / f"🎯Method1_字幕映射_{video_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                output_base_dir.mkdir(parents=True, exist_ok=True)
                
                for module in module_analysis.module_segments:
                    matches = module_matches.get(module.module_type, [])
                    if matches:
                        candidate_folder = self.clustering_manager.generate_cluster_folders_for_candidates(
                            matches, f"🎯Method1_{module.module_type}_语义切片", output_base_dir
                        )
                        candidate_folders.append(str(candidate_folder))
                        self.logger.info(f"  📁 🎯Method1_{module.module_type} (语义切片): 候选文件夹已创建")
            
            # 5. 生成脚本结构
            output_folder_path = output_base_dir
            script_result = self._generate_enhanced_script_structure(
                video_name, "字幕映射", module_analysis, module_matches, {
                    'multi_candidates_enabled': enable_multi_candidates,
                    'quality_threshold': quality_threshold,
                    'max_candidates': max_candidates,
                    'candidate_folders': candidate_folders,
                    'source_type': 'ref' if 'ref' in str(srt_path) else 'srt',
                    'output_folder': str(output_folder_path) if output_folder_path else None
                }
            )
            
            self.logger.info("✅ 字幕映射脚本生成完成")
            return script_result
            
        except Exception as e:
            self.logger.error(f"字幕映射脚本生成失败: {e}")
            return {"error": str(e)}
    
    def method2_creative_generation(self, product: str, goal: str, duration: float = 30.0,
                                  enable_clustering: bool = True,
                                  quality_threshold: float = 0.4) -> Dict:
        """
        方式2：创意脚本生成（支持智能聚类）
        从产品特征和营销目标生成创意脚本
        
        Args:
            product: 产品名称
            goal: 营销目标
            duration: 目标时长
            enable_clustering: 是否启用智能聚类
            quality_threshold: 质量阈值
            
        Returns:
            脚本生成结果
        """
        try:
            self.logger.info(f"🚀 开始方式2：创意脚本生成 - {product}+{goal}")
            self.logger.info(f"  智能聚类: {enable_clustering}")
            self.logger.info(f"  质量阈值: {quality_threshold}")
            
            # 1. 生成30秒黄金结构
            golden_structure = self._generate_golden_structure(product, goal, duration)
            
            # 2. 扫描素材 - Method 2 智能化扫描
            semantic_scan_result = self.slice_scanner.scan_semantic_slices_only()
            dedicated_product_scan_result = self.slice_scanner.scan_dedicated_product_library()
            
            if not semantic_scan_result or not semantic_scan_result.slice_infos:
                raise ValueError("未找到可用的语义切片素材")
            
            self.logger.info(f"🎯 Method 2 智能扫描完成：")
            self.logger.info(f"  语义切片: {semantic_scan_result.total_slices} 个")
            
            if dedicated_product_scan_result and dedicated_product_scan_result.slice_infos:
                self.logger.info(f"  专业产品素材: {dedicated_product_scan_result.total_slices} 个")
            else:
                self.logger.warning("  专业产品素材库未找到，🍼 产品介绍将使用语义切片")
            
            # 3. 智能聚类处理（如果启用）
            cluster_result = None
            if enable_clustering:
                cluster_result = self.clustering_manager.cluster_slices_by_theme(semantic_scan_result) # 使用语义切片进行聚类
                self.logger.info(f"  📁 聚类完成，共生成 {len(cluster_result.clusters)} 个主题聚类")
            
            # 4. 为每个模块生成创意内容并匹配素材
            module_matches = {}
            for module_type, module_config in golden_structure.items():
                # 生成创意内容
                creative_content = self._generate_creative_content(module_type, module_config, product, goal)
                
                # 匹配素材 - 智能选择素材源
                if module_type == "🍼 产品介绍" and dedicated_product_scan_result and dedicated_product_scan_result.slice_infos:
                    # 🍼 产品介绍模块：优先使用专门的产品素材库
                    matches = self._find_creative_matches(module_type, module_config, creative_content, dedicated_product_scan_result, quality_threshold)
                    self.logger.info(f"  🍼 产品介绍使用专业产品素材库，找到 {len(matches)} 个候选")
                else:
                    # 其他模块：使用语义切片
                    matches = self._find_creative_matches(module_type, module_config, creative_content, semantic_scan_result, quality_threshold)
                    self.logger.info(f"  {module_type}使用语义切片，找到 {len(matches)} 个候选")
                
                module_matches[module_type] = {
                    'content': creative_content,
                    'matches': matches
                }
            
            # 5. 创建候选文件夹 - Method 2 智能素材源版本
            output_base_dir = self.workspace / "📁生成结果" / f"🚀Method2_创意脚本_{product}_{goal}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            output_base_dir.mkdir(parents=True, exist_ok=True)
            
            for module_type, config in golden_structure.items():
                match_data = module_matches.get(module_type, {})
                matches = match_data.get('matches', [])
                
                if matches:
                    # 根据素材源类型添加标识
                    if module_type == "🍼 产品介绍" and dedicated_product_scan_result and dedicated_product_scan_result.slice_infos:
                        folder_suffix = "专业产品素材"
                    else:
                        folder_suffix = "语义切片"
                    
                    candidate_folder = self.clustering_manager.generate_cluster_folders_for_candidates(
                        matches, f"🚀Method2_{module_type}_{folder_suffix}", output_base_dir
                    )
                    self.logger.info(f"  📁 🚀Method2_{module_type} ({folder_suffix}): 候选文件夹已创建")
            
            # 6. 生成脚本结构
            script_result = self._generate_creative_script_structure(
                product, goal, "创意脚本_智能素材", golden_structure, module_matches, {
                    'clustering_enabled': enable_clustering,
                    'cluster_result': cluster_result,
                    'quality_threshold': quality_threshold,
                    'output_folder': str(output_base_dir)
                }
            )
            
            self.logger.info("✅ 创意脚本生成完成")
            return script_result
            
        except Exception as e:
            self.logger.error(f"创意脚本生成失败: {e}")
            return {"error": str(e)}
    
    def method3_video_composition(self, ref_video_path: str,
                                module_candidates: Dict[str, List],
                                module_segments: List,
                                output_dir: str,
                                composition_strategy: str = "balanced",
                                num_variations: int = 3) -> Dict:
        """
        方式3：视频合成
        保留参考音频 + 智能匹配切片画面，生成自动合成视频
        
        Args:
            ref_video_path: 参考视频路径（保留音频）
            module_candidates: 模块候选切片字典
            module_segments: 模块时间轴信息
            output_dir: 输出目录
            composition_strategy: 合成策略 (balanced/quality/creative/fast)
            num_variations: 生成变体数量
            
        Returns:
            合成结果
        """
        try:
            self.logger.info(f"🎬 开始方式3：视频合成")
            self.logger.info(f"  参考视频: {Path(ref_video_path).name}")
            self.logger.info(f"  合成策略: {composition_strategy}")
            self.logger.info(f"  变体数量: {num_variations}")
            
            # 1. 创建合成配置
            config = CompositionConfig.create_preset(composition_strategy)
            config.generation_config.num_variations = num_variations
            
            # 验证配置
            config_errors = config.validate_config()
            if config_errors:
                raise ValueError(f"配置错误: {', '.join(config_errors)}")
            
            # 2. 初始化视频合成器
            composer = VideoComposer(config)
            
            # 3. 转换候选数据格式
            from material_engine.similarity_matcher import MatchCandidate
            from material_engine.slice_scanner import SliceInfo
            
            formatted_candidates = {}
            for module_type, candidates in module_candidates.items():
                formatted_list = []
                for candidate_data in candidates:
                    # 创建SliceInfo对象
                    slice_info = SliceInfo(
                        slice_name=candidate_data['slice_name'],
                        video_name=candidate_data.get('video_name', ''),
                        file_path=candidate_data['file_path'],
                        duration=candidate_data['duration'],
                        confidence=candidate_data.get('confidence', 0.8),
                        tags=candidate_data.get('tags', {}),
                        analysis_file=""
                    )
                    
                    # 创建MatchCandidate对象
                    match_candidate = MatchCandidate(
                        slice_info=slice_info,
                        match_score=candidate_data.get('match_score', 0.7),
                        match_details={},
                        semantic_result=None,
                        duration_fitness=1.0,
                        quality_score=candidate_data.get('confidence', 0.8),
                        confidence_level=candidate_data.get('confidence_level', '中'),
                        human_readable_score=candidate_data.get('human_readable_score', '')
                    )
                    
                    formatted_list.append(match_candidate)
                
                formatted_candidates[module_type] = formatted_list
            
            # 4. 执行多变体视频合成
            results = composer.compose_multiple_variations(
                ref_video_path=ref_video_path,
                module_candidates=formatted_candidates,
                module_segments=module_segments,
                output_dir=output_dir
            )
            
            # 5. 处理结果
            successful_results = [r for r in results if r.success]
            failed_results = [r for r in results if not r.success]
            
            if not successful_results:
                raise Exception("所有视频变体合成都失败了")
            
            self.logger.info(f"✅ 视频合成完成: {len(successful_results)}/{len(results)} 个变体成功")
            
            # 6. 生成合成报告
            composition_report = {
                'method': 'video_composition',
                'ref_video': Path(ref_video_path).name,
                'composition_strategy': composition_strategy,
                'requested_variations': num_variations,
                'successful_variations': len(successful_results),
                'failed_variations': len(failed_results),
                'success_rate': len(successful_results) / len(results),
                'output_videos': [
                    {
                        'video_path': r.output_video_path,
                        'processing_time': r.processing_time,
                        'composition_report': r.composition_report
                    }
                    for r in successful_results
                ],
                'failed_videos': [
                    {
                        'error_message': r.error_message,
                        'processing_time': r.processing_time
                    }
                    for r in failed_results
                ],
                'total_processing_time': sum(r.processing_time for r in results),
                'config_used': config.to_dict()
            }
            
            # 清理临时文件
            composer.cleanup_all_temp_files()
            
            return composition_report
            
        except Exception as e:
            self.logger.error(f"视频合成失败: {e}")
            return {"error": str(e)}
    
    def _find_multiple_candidates(self, module, scan_result, quality_threshold, max_candidates):
        """找到多个候选切片"""
        match_request = MatchRequest(
            module_type=module.module_type,
            target_duration=module.duration,
            subtitle_content=module.content,
            required_tags={},
            preferred_tags={},
            brand_elements=['启赋', 'HMO', 'A2'],
            emotion_preference=self._infer_emotion_from_content(module.content),
            quality_threshold=quality_threshold,
            max_candidates=max_candidates,
            include_all_above_threshold=True  # 包含所有超过阈值的候选
        )
        
        candidates = self.similarity_matcher.find_candidate_slices(scan_result, match_request)
        return candidates
    
    def _find_module_matches(self, module, scan_result):
        """为指定模块找到最佳匹配素材（传统模式）"""
        match_request = MatchRequest(
            module_type=module.module_type,
            target_duration=module.duration,
            subtitle_content=module.content,
            required_tags={},
            preferred_tags={},
            brand_elements=['启赋', 'HMO', 'A2'],
            emotion_preference=self._infer_emotion_from_content(module.content),
            quality_threshold=0.3,
            max_candidates=5,
            include_all_above_threshold=False
        )
        
        candidates = self.similarity_matcher.find_best_matches(
            scan_result, match_request, max_results=5
        )
        
        return candidates
    
    def _find_creative_matches(self, module_type, module_config, creative_content, scan_result, quality_threshold):
        """为创意模块找到最佳匹配素材"""
        match_request = MatchRequest(
            module_type=module_type,
            target_duration=module_config['duration'],
            subtitle_content=creative_content,
            required_tags={},
            preferred_tags={},
            brand_elements=['启赋', 'HMO', 'A2'],
            emotion_preference=module_config.get('preferred_emotion', ''),
            quality_threshold=quality_threshold,
            max_candidates=8,
            include_all_above_threshold=True
        )
        
        candidates = self.similarity_matcher.find_candidate_slices(scan_result, match_request)
        return candidates
    
    def _generate_creative_content(self, module_type: str, module_config: Dict, product: str, goal: str) -> str:
        """生成创意内容"""
        templates = {
            "🪝 钩子": {
                "转化": f"你知道为什么{product}能让宝宝更健康吗？",
                "认知": f"发现{product}的秘密，给宝宝最好的营养",
                "品牌": f"选择{product}，选择专业的营养呵护"
            },
            "🍼 产品介绍": {
                "转化": f"{product}，含有珍贵HMO成分，提升宝宝免疫力",
                "认知": f"了解{product}的科学配方，为宝宝成长护航",
                "品牌": f"{product}专业配方，值得信赖的营养选择"
            },
            "🌟 使用效果": {
                "转化": f"使用{product}后，宝宝更健康，妈妈更安心",
                "认知": f"科学营养配方，助力宝宝健康成长",
                "品牌": f"品质保证，见证宝宝每天的成长变化"
            },
            "🎁 促销机制": {
                "转化": f"现在选择{product}，享受专属优惠，立即行动",
                "认知": f"专业营养师推荐，给宝宝最好的开始",
                "品牌": f"加入{product}家庭，与千万妈妈共同选择"
            }
        }
        
        return templates.get(module_type, {}).get(goal, f"{product}专业营养配方")
    
    def _generate_golden_structure(self, product: str, goal: str, duration: float) -> Dict:
        """生成30秒黄金结构"""
        # 基础结构比例
        base_structure = {
            "🪝 钩子": {"percentage": 0.17, "preferred_emotion": "好奇"},
            "🍼 产品介绍": {"percentage": 0.33, "preferred_emotion": "专业"},
            "🌟 使用效果": {"percentage": 0.33, "preferred_emotion": "温馨"},
            "🎁 促销机制": {"percentage": 0.17, "preferred_emotion": "开心"}
        }
        
        # 根据目标调整结构
        if goal == "转化":
            base_structure["🎁 促销机制"]["percentage"] = 0.25
            base_structure["🌟 使用效果"]["percentage"] = 0.25
        elif goal == "认知":
            base_structure["🍼 产品介绍"]["percentage"] = 0.40
            base_structure["🌟 使用效果"]["percentage"] = 0.30
        
        # 计算具体时长
        for module_type, config in base_structure.items():
            config['duration'] = duration * config['percentage']
        
        return base_structure
    
    def _infer_emotion_from_content(self, content: str) -> str:
        """从内容推断情绪"""
        if any(word in content for word in ['你知道', '发现', '？']):
            return '好奇'
        elif any(word in content for word in ['启赋', '配方', '成分']):
            return '专业'
        elif any(word in content for word in ['宝宝', '健康', '成长']):
            return '温馨'
        elif any(word in content for word in ['推荐', '选择', '优惠']):
            return '开心'
        else:
            return '温馨'
    
    def _generate_enhanced_script_structure(self, video_name: str, method: str, 
                                          module_analysis, module_matches, options: Dict) -> Dict:
        """生成增强的脚本结构（支持多候选）"""
        script_id = f"script_{method}_{video_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        modules = []
        for module in module_analysis.module_segments:
            matches = module_matches.get(module.module_type, [])
            
            # 处理候选信息
            candidate_info = []
            if options.get('multi_candidates_enabled', False):
                # 多候选模式：显示所有候选信息
                for match in matches:
                    candidate_info.append({
                        'slice_name': match.slice_info.slice_name,
                        'file_path': match.slice_info.file_path,
                        'duration': match.slice_info.duration,
                        'match_score': match.match_score,
                        'confidence_level': match.confidence_level,
                        'human_readable_score': match.human_readable_score,
                        'tags': match.slice_info.tags
                    })
            else:
                # 传统模式：只显示前几个最佳匹配
                for match in matches[:3]:
                    candidate_info.append({
                        'slice_name': match.slice_info.slice_name,
                        'file_path': match.slice_info.file_path,
                        'duration': match.slice_info.duration,
                        'match_score': match.match_score,
                        'tags': match.slice_info.tags
                    })
            
            module_data = {
                'module_type': module.module_type,
                'time_range': f"{module.start_time:.1f}-{module.end_time:.1f}s",
                'duration': module.duration,
                'percentage': module.percentage * 100,
                'content': module.content,
                'confidence': module.confidence,
                'candidate_count': len(matches),
                'candidates': candidate_info
            }
            modules.append(module_data)
        
        return {
            'script_id': script_id,
            'generation_method': method,
            'video_name': video_name,
            'total_duration': module_analysis.total_duration,
            'modules': modules,
            'module_distribution': module_analysis.module_distribution,
            'options': {
                'multi_candidates_enabled': options.get('multi_candidates_enabled', False),
                'quality_threshold': options.get('quality_threshold', 0.3),
                'max_candidates': options.get('max_candidates', 10),
                'candidate_folders': options.get('candidate_folders', []),
                'source_type': options.get('source_type', 'srt'),
                'output_folder': options.get('output_folder')
            },
            'created_at': datetime.now().isoformat(),
            'quality_summary': self._generate_quality_summary(modules),
            'human_intervention_guide': self._generate_human_intervention_guide(modules)
        }
    
    def _generate_creative_script_structure(self, product: str, goal: str, method: str,
                                          golden_structure, module_matches, options: Dict) -> Dict:
        """生成创意脚本结构"""
        script_id = f"script_{method}_{product}_{goal}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        modules = []
        total_duration = 0
        
        for module_type, config in golden_structure.items():
            match_data = module_matches.get(module_type, {})
            content = match_data.get('content', '')
            matches = match_data.get('matches', [])
            
            # 候选信息
            candidate_info = []
            for match in matches:
                candidate_info.append({
                    'slice_name': match.slice_info.slice_name,
                    'file_path': match.slice_info.file_path,
                    'duration': match.slice_info.duration,
                    'match_score': match.match_score,
                    'confidence_level': getattr(match, 'confidence_level', ''),
                    'human_readable_score': getattr(match, 'human_readable_score', ''),
                    'tags': match.slice_info.tags
                })
            
            module_data = {
                'module_type': module_type,
                'time_range': f"{total_duration:.1f}-{total_duration + config['duration']:.1f}s",
                'duration': config['duration'],
                'percentage': config['percentage'] * 100,
                'content': content,
                'preferred_emotion': config['preferred_emotion'],
                'candidate_count': len(matches),
                'candidates': candidate_info
            }
            modules.append(module_data)
            total_duration += config['duration']
        
        result = {
            'script_id': script_id,
            'generation_method': method,
            'product': product,
            'marketing_goal': goal,
            'total_duration': total_duration,
            'modules': modules,
            'golden_structure_compliance': self._check_golden_structure_compliance(modules),
            'options': options,
            'created_at': datetime.now().isoformat(),
            'quality_summary': self._generate_quality_summary(modules),
            'human_intervention_guide': self._generate_human_intervention_guide(modules)
        }
        
        # 如果启用了聚类，添加聚类信息
        if options.get('clustering_enabled', False) and options.get('cluster_result'):
            result['cluster_info'] = {
                'total_clusters': len(options['cluster_result'].clusters),
                'cluster_summary': {
                    cluster.cluster_name: {
                        'slice_count': cluster.slice_count,
                        'total_duration': cluster.total_duration,
                        'dominant_emotion': cluster.dominant_emotion,
                        'folder_path': cluster.folder_path
                    }
                    for cluster in options['cluster_result'].clusters
                }
            }
        
        return result
    
    def _generate_quality_summary(self, modules: List[Dict]) -> Dict:
        """生成质量摘要"""
        total_candidates = sum(m.get('candidate_count', 0) for m in modules)
        avg_candidates = total_candidates / len(modules) if modules else 0
        
        # 计算平均匹配分数
        all_scores = []
        for module in modules:
            for candidate in module.get('candidates', []):
                if 'match_score' in candidate:
                    all_scores.append(candidate['match_score'])
        
        avg_score = sum(all_scores) / len(all_scores) if all_scores else 0
        
        # 质量等级
        if avg_score >= 0.8:
            quality_level = "优秀"
        elif avg_score >= 0.6:
            quality_level = "良好"
        elif avg_score >= 0.4:
            quality_level = "一般"
        else:
            quality_level = "需改进"
        
        return {
            'total_candidates': total_candidates,
            'avg_candidates_per_module': avg_candidates,
            'avg_match_score': avg_score,
            'quality_level': quality_level,
            'modules_with_multiple_candidates': sum(1 for m in modules if m.get('candidate_count', 0) > 1)
        }
    
    def _generate_human_intervention_guide(self, modules: List[Dict]) -> Dict:
        """生成人工干预指南"""
        intervention_points = []
        
        for module in modules:
            module_type = module.get('module_type', '')
            candidate_count = module.get('candidate_count', 0)
            
            if candidate_count == 0:
                intervention_points.append({
                    'module': module_type,
                    'issue': '无候选切片',
                    'suggestion': '检查匹配条件或手动添加合适切片',
                    'priority': '高'
                })
            elif candidate_count == 1:
                intervention_points.append({
                    'module': module_type,
                    'issue': '候选切片较少',
                    'suggestion': '可考虑降低阈值或调整匹配条件',
                    'priority': '中'
                })
            elif candidate_count > 10:
                intervention_points.append({
                    'module': module_type,
                    'issue': '候选切片过多',
                    'suggestion': '建议人工筛选或提高质量阈值',
                    'priority': '中'
                })
        
        return {
            'intervention_needed': len(intervention_points) > 0,
            'intervention_points': intervention_points,
            'recommendation': '建议查看候选文件夹，根据评分和人工判断信息进行最终选择'
        }
    
    def _check_golden_structure_compliance(self, modules: List[Dict]) -> Dict:
        """检查30秒黄金结构合规性"""
        # 计算各模块实际比例
        total_duration = sum(m.get('duration', 0) for m in modules)
        actual_percentages = {}
        
        for module in modules:
            module_type = module.get('module_type', '')
            duration = module.get('duration', 0)
            actual_percentages[module_type] = (duration / total_duration * 100) if total_duration > 0 else 0
        
        # 理想比例
        ideal_percentages = {
            "🪝 钩子": 17,
            "🍼 产品介绍": 33,
            "🌟 使用效果": 33,
            "🎁 促销机制": 17
        }
        
        # 计算偏差
        deviations = {}
        for module_type, ideal in ideal_percentages.items():
            actual = actual_percentages.get(module_type, 0)
            deviations[module_type] = abs(actual - ideal)
        
        avg_deviation = sum(deviations.values()) / len(deviations)
        
        # 合规性评级
        if avg_deviation <= 5:
            compliance_level = "完全合规"
        elif avg_deviation <= 10:
            compliance_level = "基本合规"
        elif avg_deviation <= 15:
            compliance_level = "部分合规"
        else:
            compliance_level = "需要调整"
        
        return {
            'compliance_level': compliance_level,
            'avg_deviation': avg_deviation,
            'actual_percentages': actual_percentages,
            'ideal_percentages': ideal_percentages,
            'deviations': deviations
        }

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='Script Studio V2.0 - 智能视频脚本生成系统 (Claude 4)')
    parser.add_argument('--method', choices=['1', '2', '3'], required=True, help='生成方式：1=字幕映射, 2=创意脚本, 3=视频合成')
    
    # 方式1参数
    parser.add_argument('--video', help='视频名称 (方式1必需)')
    parser.add_argument('--srt', help='SRT文件路径 (可选)')
    parser.add_argument('--multi-candidates', action='store_true', help='启用多候选选择')
    parser.add_argument('--threshold', type=float, default=0.3, help='质量阈值')
    parser.add_argument('--max-candidates', type=int, default=10, help='最大候选数量')
    
    # 方式2参数
    parser.add_argument('--product', help='产品名称 (方式2必需)')
    parser.add_argument('--goal', help='营销目标 (方式2必需)')
    parser.add_argument('--duration', type=float, default=30.0, help='目标时长')
    parser.add_argument('--clustering', action='store_true', help='启用智能聚类')
    
    # 方式3参数
    parser.add_argument('--script-file', help='脚本文件路径 (方式3必需)')
    parser.add_argument('--output-video', help='输出视频路径 (方式3必需)')
    
    args = parser.parse_args()
    
    # 初始化系统
    studio = ScriptStudioV2()
    
    try:
        if args.method == '1':
            # 方式1：字幕映射
            if not args.video:
                raise ValueError("方式1需要指定视频名称")
            
            result = studio.method1_subtitle_mapping(
                video_name=args.video,
                srt_path=args.srt,
                enable_multi_candidates=args.multi_candidates,
                quality_threshold=args.threshold,
                max_candidates=args.max_candidates
            )
            
        elif args.method == '2':
            # 方式2：创意脚本
            if not args.product or not args.goal:
                raise ValueError("方式2需要指定产品名称和营销目标")
            
            result = studio.method2_creative_generation(
                product=args.product,
                goal=args.goal,
                duration=args.duration,
                enable_clustering=args.clustering,
                quality_threshold=args.threshold
            )
        
        elif args.method == '3':
            # 方式3：视频合成
            if not args.script_file or not args.output_video:
                raise ValueError("方式3需要指定脚本文件和输出视频路径")
            
            # 读取脚本文件
            with open(args.script_file, 'r', encoding='utf-8') as f:
                script_data = json.load(f)
            
            result = studio.method3_video_composition(script_data, args.output_video)
        
        # 输出结果
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"✅ 结果已保存到: {args.output}")
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))

        # 显示结果概览和Method分类信息
        if result and "error" not in result:
            print("\n" + "="*60)
            print("✅ 脚本生成完成!")
            print("="*60)
            
            # 显示生成方式信息
            generation_method = result.get('generation_method', 'unknown')
            if args.method == '1':
                print(f"🎯 生成方式: Method 1 - 字幕映射 (Claude 4)")
                print(f"📹 分析视频: {args.video}")
            elif args.method == '2':
                print(f"🚀 生成方式: Method 2 - 创意脚本生成 (Claude 4)")
                print(f"📦 产品名称: {args.product}")
                print(f"🎯 营销目标: {args.goal}")
            elif args.method == '3':
                print(f"🎬 生成方式: Method 3 - 视频合成 (Claude 4)")
                print(f"📄 脚本文件: {args.script_file}")
                print(f"📹 输出视频: {args.output_video}")
            
            # 显示基础统计
            modules = result.get('modules', [])
            print(f"📊 生成模块: {len(modules)} 个")
            print(f"⏱️  总时长: {result.get('total_duration', 0):.1f}秒")
            
            # 显示候选文件夹位置（按Method分类）
            output_folder = result.get('options', {}).get('output_folder', '')
            if output_folder:
                print(f"\n📁 候选结果文件夹:")
                print(f"   📂 {output_folder}")
                print(f"   💡 文件夹按Method分类，便于管理和识别")
                print(f"   🔍 查看各模块候选切片，根据评分进行人工筛选")
            
            # 保存结果到文件
            if args.output:
                with open(args.output, 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                print(f"\n💾 详细结果已保存到: {args.output}")
        else:
            # 输出原始JSON（仅用于错误调试）
            print(json.dumps(result, ensure_ascii=False, indent=2))
            
    except Exception as e:
        print(f"❌ 执行失败: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main()) 